#!/usr/bin/env python3
"""
Database Setup Script for AI Climate Resilience System
Creates PostgreSQL database with PostGIS extensions and sample data
"""

import asyncio
import asyncpg
import os
import sys
import logging
from pathlib import Path

# Add backend to path
sys.path.append(str(Path(__file__).parent.parent / "backend"))

from database.models import DatabaseConfig, DatabaseManager

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def create_database():
    """Create the database if it doesn't exist"""
    config = DatabaseConfig()
    
    try:
        # Connect to default postgres database to create our database
        conn = await asyncpg.connect(
            host=config.host,
            port=config.port,
            database="postgres",
            user=config.user,
            password=config.password
        )
        
        # Check if database exists
        exists = await conn.fetchval(
            "SELECT 1 FROM pg_database WHERE datname = $1", 
            config.database
        )
        
        if not exists:
            await conn.execute(f"CREATE DATABASE {config.database}")
            logger.info(f"Database '{config.database}' created successfully")
        else:
            logger.info(f"Database '{config.database}' already exists")
        
        await conn.close()
        
    except Exception as e:
        logger.error(f"Failed to create database: {e}")
        raise

async def setup_database():
    """Complete database setup"""
    try:
        # Create database
        await create_database()
        
        # Initialize database manager
        db_manager = DatabaseManager()
        await db_manager.initialize()
        
        logger.info("Database setup completed successfully!")
        
        # Print sample queries for demo
        print("\n" + "="*50)
        print("DATABASE SETUP COMPLETED!")
        print("="*50)
        print("\nSample queries you can run:")
        print("1. SELECT COUNT(*) FROM predictions;")
        print("2. SELECT disaster_type, AVG(probability) FROM predictions GROUP BY disaster_type;")
        print("3. SELECT * FROM environmental_data LIMIT 5;")
        print("4. SELECT * FROM model_performance;")
        print("\nDemo data includes:")
        print("- 5 cities with 30 days of environmental data")
        print("- Sample predictions for floods, droughts, and cyclones")
        print("- Model performance metrics")
        print("- Geospatial data with PostGIS support")
        
    except Exception as e:
        logger.error(f"Database setup failed: {e}")
        raise

async def reset_database():
    """Reset database (drop and recreate)"""
    config = DatabaseConfig()
    
    try:
        # Connect to postgres database
        conn = await asyncpg.connect(
            host=config.host,
            port=config.port,
            database="postgres",
            user=config.user,
            password=config.password
        )
        
        # Drop database if exists
        await conn.execute(f"DROP DATABASE IF EXISTS {config.database}")
        logger.info(f"Database '{config.database}' dropped")
        
        await conn.close()
        
        # Recreate database
        await setup_database()
        
    except Exception as e:
        logger.error(f"Database reset failed: {e}")
        raise

async def show_database_info():
    """Show database information"""
    config = DatabaseConfig()
    
    try:
        db_manager = DatabaseManager()
        await db_manager.initialize()
        
        async with db_manager.pool.acquire() as conn:
            # Get table counts
            tables = ["users", "environmental_data", "predictions", "alerts", 
                     "model_performance", "data_quality", "system_events"]
            
            print("\n" + "="*50)
            print("DATABASE INFORMATION")
            print("="*50)
            
            for table in tables:
                count = await conn.fetchval(f"SELECT COUNT(*) FROM {table}")
                print(f"{table}: {count} records")
            
            # Get recent predictions
            recent_preds = await conn.fetch("""
                SELECT disaster_type, probability, risk_level, timestamp 
                FROM predictions 
                ORDER BY timestamp DESC 
                LIMIT 5
            """)
            
            print(f"\nRecent Predictions:")
            for pred in recent_preds:
                print(f"- {pred['disaster_type']}: {pred['probability']:.2f} ({pred['risk_level']}) at {pred['timestamp']}")
            
            await db_manager.close()
            
    except Exception as e:
        logger.error(f"Failed to show database info: {e}")

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Database setup for AI Climate Resilience System")
    parser.add_argument("--reset", action="store_true", help="Reset database (drop and recreate)")
    parser.add_argument("--info", action="store_true", help="Show database information")
    
    args = parser.parse_args()
    
    if args.reset:
        asyncio.run(reset_database())
    elif args.info:
        asyncio.run(show_database_info())
    else:
        asyncio.run(setup_database()) 