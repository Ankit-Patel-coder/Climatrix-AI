/**
 * Interactive Weather Map with Real-time Data
 */

class WeatherMap {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        if (!this.container) {
            throw new Error(`Container with id '${containerId}' not found`);
        }
        
        this.map = null;
        this.markers = [];
        this.weatherData = {};
        this.currentView = 'temperature';
        this.isLoading = false;
        
        this.init();
    }

    init() {
        try {
            this.createMapContainer();
            this.loadMapLibraries();
            this.setupEventListeners();
            this.loadInitialData();
        } catch (error) {
            console.error('Error initializing WeatherMap:', error);
            throw new Error(`Failed to initialize weather map: ${error.message}`);
        }
    }

    createMapContainer() {
        this.container.innerHTML = `
            <div class="weather-map-container">
                <div class="map-controls">
                    <div class="view-selector">
                        <button class="view-btn active" data-view="temperature">🌡️ Temperature</button>
                        <button class="view-btn" data-view="rainfall">🌧️ Rainfall</button>
                        <button class="view-btn" data-view="wind">💨 Wind</button>
                        <button class="view-btn" data-view="pressure">🌪️ Pressure</button>
                        <button class="view-btn" data-view="clouds">☁️ Clouds</button>
                    </div>
                    <div class="map-actions">
                        <button class="action-btn" id="refresh-btn">🔄 Refresh</button>
                        <button class="action-btn" id="location-btn">📍 My Location</button>
                    </div>
                </div>
                <div id="map" class="map-area"></div>
                <div class="weather-info-panel">
                    <div class="info-header">
                        <h3>🌍 Live Weather Data</h3>
                        <span class="data-status" id="data-status">🟢 Live</span>
                    </div>
                    <div class="info-content" id="info-content">
                        <div class="loading-indicator">Loading weather data...</div>
                    </div>
                </div>
            </div>
        `;

        this.addStyles();
    }

    addStyles() {
        const style = document.createElement('style');
        style.textContent = `
            .weather-map-container {
                position: relative;
                width: 100%;
                height: 100vh;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            }

            .map-controls {
                position: absolute;
                top: 20px;
                left: 20px;
                right: 20px;
                z-index: 1000;
                display: flex;
                justify-content: space-between;
                align-items: center;
                background: rgba(255, 255, 255, 0.95);
                backdrop-filter: blur(10px);
                border-radius: 15px;
                padding: 15px 20px;
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            }

            .view-selector {
                display: flex;
                gap: 10px;
            }

            .view-btn {
                background: rgba(255, 255, 255, 0.8);
                border: 2px solid transparent;
                color: #333;
                padding: 8px 16px;
                border-radius: 25px;
                cursor: pointer;
                font-size: 14px;
                font-weight: 500;
                transition: all 0.3s ease;
            }

            .view-btn:hover {
                background: rgba(255, 255, 255, 1);
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            }

            .view-btn.active {
                background: linear-gradient(45deg, #2196F3, #21CBF3);
                color: white;
                border-color: #2196F3;
            }

            .map-actions {
                display: flex;
                gap: 10px;
            }

            .action-btn {
                background: rgba(255, 255, 255, 0.8);
                border: none;
                color: #333;
                padding: 8px 16px;
                border-radius: 25px;
                cursor: pointer;
                font-size: 14px;
                font-weight: 500;
                transition: all 0.3s ease;
            }

            .action-btn:hover {
                background: rgba(255, 255, 255, 1);
                transform: translateY(-2px);
            }

            .map-area {
                width: 100%;
                height: 100%;
                position: relative;
            }

            .weather-info-panel {
                position: absolute;
                top: 100px;
                right: 20px;
                width: 320px;
                background: rgba(255, 255, 255, 0.95);
                backdrop-filter: blur(10px);
                border-radius: 15px;
                padding: 20px;
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
                z-index: 1000;
                max-height: calc(100vh - 140px);
                overflow-y: auto;
            }

            .info-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 15px;
                padding-bottom: 10px;
                border-bottom: 2px solid rgba(0, 0, 0, 0.1);
            }

            .info-header h3 {
                margin: 0;
                color: #333;
                font-size: 18px;
                font-weight: 600;
            }

            .data-status {
                font-size: 12px;
                font-weight: 500;
                padding: 4px 8px;
                border-radius: 12px;
                background: rgba(76, 175, 80, 0.1);
                color: #4CAF50;
            }

            .info-content {
                color: #333;
                font-size: 14px;
            }

            .weather-item {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 8px 0;
                border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            }

            .weather-item:last-child {
                border-bottom: none;
            }

            .weather-label {
                font-weight: 500;
                color: #666;
            }

            .weather-value {
                font-weight: 600;
                color: #333;
            }

            .loading-indicator {
                text-align: center;
                color: #666;
                font-style: italic;
            }

            @media (max-width: 768px) {
                .map-controls {
                    flex-direction: column;
                    gap: 15px;
                }
                
                .view-selector {
                    flex-wrap: wrap;
                    justify-content: center;
                }
                
                .weather-info-panel {
                    width: calc(100% - 40px);
                    right: 20px;
                    left: 20px;
                }
            }
        `;
        document.head.appendChild(style);
    }

    async loadMapLibraries() {
        const leafletCSS = document.createElement('link');
        leafletCSS.rel = 'stylesheet';
        leafletCSS.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
        document.head.appendChild(leafletCSS);

        await this.loadScript('https://unpkg.com/leaflet@1.9.4/dist/leaflet.js');
        this.initializeMap();
    }

    loadScript(src) {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = src;
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
        });
    }

    initializeMap() {
        this.map = L.map('map').setView([20, 80], 4);

        const tileLayers = {
            default: L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors'
            }),
            satellite: L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
                attribution: '© Esri'
            })
        };

        tileLayers.default.addTo(this.map);
        L.control.layers(tileLayers).addTo(this.map);
        L.control.scale().addTo(this.map);

        console.log('✅ Map initialized successfully');
    }

    setupEventListeners() {
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.switchView(e.target.dataset.view);
            });
        });

        document.getElementById('refresh-btn').addEventListener('click', () => {
            this.refreshData();
        });

        document.getElementById('location-btn').addEventListener('click', () => {
            this.getCurrentLocation();
        });

        this.map.on('click', (e) => {
            this.showLocationInfo(e.latlng);
        });
    }

    async loadInitialData() {
        this.isLoading = true;
        this.updateStatus('🔄 Loading...', 'loading');

        try {
            await this.loadWeatherData();
            this.addWeatherMarkers();
            this.updateInfoPanel();
            this.updateStatus('🟢 Live', 'live');
            this.startPeriodicUpdates();
        } catch (error) {
            console.error('Failed to load initial data:', error);
            this.updateStatus('🔴 Error', 'error');
        } finally {
            this.isLoading = false;
        }
    }

    async loadWeatherData() {
        this.weatherData = {
            cities: [
                {
                    name: 'Mumbai, India',
                    lat: 19.0760,
                    lng: 72.8777,
                    temperature: 28,
                    humidity: 75,
                    windSpeed: 12,
                    pressure: 1013,
                    rainfall: 15,
                    clouds: 60,
                    condition: 'Partly Cloudy'
                },
                {
                    name: 'Delhi, India',
                    lat: 28.7041,
                    lng: 77.1025,
                    temperature: 32,
                    humidity: 45,
                    windSpeed: 8,
                    pressure: 1010,
                    rainfall: 0,
                    clouds: 20,
                    condition: 'Sunny'
                },
                {
                    name: 'Chennai, India',
                    lat: 13.0827,
                    lng: 80.2707,
                    temperature: 30,
                    humidity: 80,
                    windSpeed: 15,
                    pressure: 1012,
                    rainfall: 25,
                    clouds: 80,
                    condition: 'Rainy'
                },
                {
                    name: 'Kolkata, India',
                    lat: 22.5726,
                    lng: 88.3639,
                    temperature: 29,
                    humidity: 70,
                    windSpeed: 10,
                    pressure: 1011,
                    rainfall: 8,
                    clouds: 50,
                    condition: 'Cloudy'
                },
                {
                    name: 'Bangalore, India',
                    lat: 12.9716,
                    lng: 77.5946,
                    temperature: 25,
                    humidity: 65,
                    windSpeed: 6,
                    pressure: 1014,
                    rainfall: 5,
                    clouds: 30,
                    condition: 'Partly Cloudy'
                },
                {
                    name: 'New York, USA',
                    lat: 40.7128,
                    lng: -74.0060,
                    temperature: 18,
                    humidity: 60,
                    windSpeed: 20,
                    pressure: 1015,
                    rainfall: 12,
                    clouds: 70,
                    condition: 'Windy'
                },
                {
                    name: 'London, UK',
                    lat: 51.5074,
                    lng: -0.1278,
                    temperature: 12,
                    humidity: 80,
                    windSpeed: 15,
                    pressure: 1018,
                    rainfall: 18,
                    clouds: 90,
                    condition: 'Rainy'
                },
                {
                    name: 'Tokyo, Japan',
                    lat: 35.6762,
                    lng: 139.6503,
                    temperature: 22,
                    humidity: 70,
                    windSpeed: 8,
                    pressure: 1016,
                    rainfall: 10,
                    clouds: 40,
                    condition: 'Partly Cloudy'
                },
                {
                    name: 'Sydney, Australia',
                    lat: -33.8688,
                    lng: 151.2093,
                    temperature: 20,
                    humidity: 75,
                    windSpeed: 12,
                    pressure: 1019,
                    rainfall: 8,
                    clouds: 60,
                    condition: 'Cloudy'
                },
                {
                    name: 'Dubai, UAE',
                    lat: 25.2048,
                    lng: 55.2708,
                    temperature: 35,
                    humidity: 40,
                    windSpeed: 5,
                    pressure: 1008,
                    rainfall: 0,
                    clouds: 10,
                    condition: 'Sunny'
                }
            ],
            global: {
                averageTemperature: 15.2,
                averageHumidity: 65,
                activeStorms: 3,
                droughtAreas: 5,
                lastUpdated: new Date()
            }
        };

        await new Promise(resolve => setTimeout(resolve, 1000));
    }

    addWeatherMarkers() {
        this.markers.forEach(marker => marker.remove());
        this.markers = [];

        this.weatherData.cities.forEach(city => {
            const marker = this.createWeatherMarker(city);
            this.markers.push(marker);
            marker.addTo(this.map);
        });
    }

    createWeatherMarker(city) {
        const icon = this.createWeatherIcon(city);
        
        const marker = L.marker([city.lat, city.lng], { icon })
            .bindPopup(this.createPopupContent(city))
            .on('click', () => {
                this.showCityDetails(city);
            });

        return marker;
    }

    createWeatherIcon(city) {
        const size = 40;
        const color = this.getWeatherColor(city);
        
        return L.divIcon({
            className: 'weather-marker-icon',
            html: `
                <div class="weather-marker" style="
                    background: ${color};
                    color: white;
                    font-weight: bold;
                    text-align: center;
                    line-height: 1.2;
                    min-width: ${size}px;
                    height: ${size}px;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    align-items: center;
                    border-radius: 50%;
                    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                ">
                    <div style="font-size: 12px;">${city.temperature}°</div>
                    <div style="font-size: 8px;">${this.getWeatherEmoji(city.condition)}</div>
                </div>
            `,
            iconSize: [size, size],
            iconAnchor: [size/2, size/2]
        });
    }

    getWeatherColor(city) {
        const temp = city.temperature;
        if (temp >= 35) return 'linear-gradient(45deg, #ff4444, #ff6666)';
        if (temp >= 30) return 'linear-gradient(45deg, #ff6600, #ff8800)';
        if (temp >= 25) return 'linear-gradient(45deg, #ffaa00, #ffcc00)';
        if (temp >= 20) return 'linear-gradient(45deg, #44aa44, #66cc66)';
        if (temp >= 15) return 'linear-gradient(45deg, #4488ff, #66aaff)';
        return 'linear-gradient(45deg, #4444ff, #6666ff)';
    }

    getWeatherEmoji(condition) {
        const emojis = {
            'Sunny': '☀️',
            'Partly Cloudy': '⛅',
            'Cloudy': '☁️',
            'Rainy': '🌧️',
            'Windy': '💨',
            'Stormy': '⛈️',
            'Foggy': '🌫️'
        };
        return emojis[condition] || '🌤️';
    }

    createPopupContent(city) {
        return `
            <div style="min-width: 200px;">
                <h3 style="margin: 0 0 10px 0; color: #333;">${city.name}</h3>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; font-size: 14px;">
                    <div><strong>🌡️ Temp:</strong> ${city.temperature}°C</div>
                    <div><strong>💧 Humidity:</strong> ${city.humidity}%</div>
                    <div><strong>💨 Wind:</strong> ${city.windSpeed} km/h</div>
                    <div><strong>🌪️ Pressure:</strong> ${city.pressure} hPa</div>
                    <div><strong>🌧️ Rainfall:</strong> ${city.rainfall} mm</div>
                    <div><strong>☁️ Clouds:</strong> ${city.clouds}%</div>
                </div>
                <div style="margin-top: 10px; padding: 8px; background: #f0f0f0; border-radius: 5px; text-align: center; font-weight: bold;">
                    ${this.getWeatherEmoji(city.condition)} ${city.condition}
                </div>
            </div>
        `;
    }

    switchView(view) {
        this.currentView = view;
        
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-view="${view}"]`).classList.add('active');
        
        this.updateMarkersForView();
        this.updateInfoPanel();
    }

    updateMarkersForView() {
        this.markers.forEach((marker, index) => {
            const city = this.weatherData.cities[index];
            const newIcon = this.createWeatherIconForView(city, this.currentView);
            marker.setIcon(newIcon);
        });
    }

    createWeatherIconForView(city, view) {
        const size = 40;
        let value, color, emoji;
        
        switch (view) {
            case 'temperature':
                value = `${city.temperature}°`;
                color = this.getTemperatureColor(city.temperature);
                emoji = '🌡️';
                break;
            case 'rainfall':
                value = `${city.rainfall}mm`;
                color = this.getRainfallColor(city.rainfall);
                emoji = '🌧️';
                break;
            case 'wind':
                value = `${city.windSpeed}km/h`;
                color = this.getWindColor(city.windSpeed);
                emoji = '💨';
                break;
            case 'pressure':
                value = `${city.pressure}hPa`;
                color = this.getPressureColor(city.pressure);
                emoji = '🌪️';
                break;
            case 'clouds':
                value = `${city.clouds}%`;
                color = this.getCloudColor(city.clouds);
                emoji = '☁️';
                break;
            default:
                value = `${city.temperature}°`;
                color = this.getTemperatureColor(city.temperature);
                emoji = '🌡️';
        }
        
        return L.divIcon({
            className: 'weather-marker-icon',
            html: `
                <div class="weather-marker" style="
                    background: ${color};
                    color: white;
                    font-weight: bold;
                    text-align: center;
                    line-height: 1.2;
                    min-width: ${size}px;
                    height: ${size}px;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    align-items: center;
                    border-radius: 50%;
                    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                ">
                    <div style="font-size: 12px;">${value}</div>
                    <div style="font-size: 8px;">${emoji}</div>
                </div>
            `,
            iconSize: [size, size],
            iconAnchor: [size/2, size/2]
        });
    }

    getTemperatureColor(temp) {
        if (temp >= 35) return 'linear-gradient(45deg, #ff0000, #ff4444)';
        if (temp >= 30) return 'linear-gradient(45deg, #ff6600, #ff8800)';
        if (temp >= 25) return 'linear-gradient(45deg, #ffaa00, #ffcc00)';
        if (temp >= 20) return 'linear-gradient(45deg, #44aa44, #66cc66)';
        if (temp >= 15) return 'linear-gradient(45deg, #4488ff, #66aaff)';
        return 'linear-gradient(45deg, #4444ff, #6666ff)';
    }

    getRainfallColor(rainfall) {
        if (rainfall >= 50) return 'linear-gradient(45deg, #000066, #0000cc)';
        if (rainfall >= 25) return 'linear-gradient(45deg, #0066cc, #0099ff)';
        if (rainfall >= 10) return 'linear-gradient(45deg, #66ccff, #99ddff)';
        return 'linear-gradient(45deg, #ccffff, #e6ffff)';
    }

    getWindColor(wind) {
        if (wind >= 30) return 'linear-gradient(45deg, #660000, #cc0000)';
        if (wind >= 20) return 'linear-gradient(45deg, #cc6600, #ff8800)';
        if (wind >= 10) return 'linear-gradient(45deg, #ffaa00, #ffcc00)';
        return 'linear-gradient(45deg, #66cc66, #99dd99)';
    }

    getPressureColor(pressure) {
        if (pressure >= 1020) return 'linear-gradient(45deg, #006600, #00cc00)';
        if (pressure >= 1010) return 'linear-gradient(45deg, #66cc66, #99dd99)';
        if (pressure >= 1000) return 'linear-gradient(45deg, #ffaa00, #ffcc00)';
        return 'linear-gradient(45deg, #ff6600, #ff8800)';
    }

    getCloudColor(clouds) {
        if (clouds >= 80) return 'linear-gradient(45deg, #666666, #999999)';
        if (clouds >= 60) return 'linear-gradient(45deg, #999999, #cccccc)';
        if (clouds >= 40) return 'linear-gradient(45deg, #cccccc, #eeeeee)';
        return 'linear-gradient(45deg, #ffffff, #f0f0f0)';
    }

    updateInfoPanel() {
        const content = document.getElementById('info-content');
        
        if (this.isLoading) {
            content.innerHTML = '<div class="loading-indicator">Loading weather data...</div>';
            return;
        }

        const global = this.weatherData.global;
        const cities = this.weatherData.cities;
        
        let html = `
            <div class="weather-item">
                <span class="weather-label">🌍 Global Average</span>
                <span class="weather-value">${global.averageTemperature}°C</span>
            </div>
            <div class="weather-item">
                <span class="weather-label">💧 Average Humidity</span>
                <span class="weather-value">${global.averageHumidity}%</span>
            </div>
            <div class="weather-item">
                <span class="weather-label">🌪️ Active Storms</span>
                <span class="weather-value">${global.activeStorms}</span>
            </div>
            <div class="weather-item">
                <span class="weather-label">🌵 Drought Areas</span>
                <span class="weather-value">${global.droughtAreas}</span>
            </div>
            <div class="weather-item">
                <span class="weather-label">🕐 Last Updated</span>
                <span class="weather-value">${global.lastUpdated.toLocaleTimeString()}</span>
            </div>
        `;

        html += `<h4 style="margin: 20px 0 10px 0; color: #333; border-top: 1px solid #eee; padding-top: 10px;">📊 ${this.currentView.charAt(0).toUpperCase() + this.currentView.slice(1)} Data</h4>`;
        
        const topCities = cities
            .sort((a, b) => this.getViewValue(b, this.currentView) - this.getViewValue(a, this.currentView))
            .slice(0, 5);

        topCities.forEach(city => {
            const value = this.getViewValue(city, this.currentView);
            const unit = this.getViewUnit(this.currentView);
            html += `
                <div class="weather-item">
                    <span class="weather-label">${city.name}</span>
                    <span class="weather-value">${value}${unit}</span>
                </div>
            `;
        });

        content.innerHTML = html;
    }

    getViewValue(city, view) {
        switch (view) {
            case 'temperature': return city.temperature;
            case 'rainfall': return city.rainfall;
            case 'wind': return city.windSpeed;
            case 'pressure': return city.pressure;
            case 'clouds': return city.clouds;
            default: return city.temperature;
        }
    }

    getViewUnit(view) {
        switch (view) {
            case 'temperature': return '°C';
            case 'rainfall': return 'mm';
            case 'wind': return ' km/h';
            case 'pressure': return ' hPa';
            case 'clouds': return '%';
            default: return '';
        }
    }

    updateStatus(status, type) {
        const statusElement = document.getElementById('data-status');
        statusElement.textContent = status;
        statusElement.className = `data-status ${type}`;
    }

    async refreshData() {
        this.isLoading = true;
        this.updateStatus('🔄 Refreshing...', 'loading');
        
        try {
            await this.loadWeatherData();
            this.addWeatherMarkers();
            this.updateInfoPanel();
            this.updateStatus('🟢 Live', 'live');
        } catch (error) {
            console.error('Failed to refresh data:', error);
            this.updateStatus('🔴 Error', 'error');
        } finally {
            this.isLoading = false;
        }
    }

    getCurrentLocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const { latitude, longitude } = position.coords;
                    this.map.setView([latitude, longitude], 10);
                    this.showLocationInfo({ lat: latitude, lng: longitude });
                },
                (error) => {
                    console.error('Error getting location:', error);
                    alert('Unable to get your location. Please check your browser settings.');
                }
            );
        } else {
            alert('Geolocation is not supported by your browser.');
        }
    }

    showLocationInfo(latlng) {
        const nearestCity = this.findNearestCity(latlng);
        
        if (nearestCity) {
            this.showCityDetails(nearestCity);
        } else {
            const popup = L.popup()
                .setLatLng(latlng)
                .setContent(`
                    <div style="min-width: 150px;">
                        <h3 style="margin: 0 0 10px 0;">📍 Location</h3>
                        <p><strong>Latitude:</strong> ${latlng.lat.toFixed(4)}</p>
                        <p><strong>Longitude:</strong> ${latlng.lng.toFixed(4)}</p>
                        <p style="color: #666; font-style: italic;">No weather data available for this location</p>
                    </div>
                `)
                .openOn(this.map);
        }
    }

    findNearestCity(latlng) {
        let nearest = null;
        let minDistance = Infinity;
        
        this.weatherData.cities.forEach(city => {
            const distance = this.calculateDistance(latlng.lat, latlng.lng, city.lat, city.lng);
            if (distance < minDistance) {
                minDistance = distance;
                nearest = city;
            }
        });
        
        return minDistance <= 100 ? nearest : null;
    }

    calculateDistance(lat1, lon1, lat2, lon2) {
        const R = 6371;
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLon = (lon2 - lon1) * Math.PI / 180;
        const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                  Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                  Math.sin(dLon/2) * Math.sin(dLon/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return R * c;
    }

    showCityDetails(city) {
        const popup = L.popup()
            .setLatLng([city.lat, city.lng])
            .setContent(this.createDetailedPopupContent(city))
            .openOn(this.map);
    }

    createDetailedPopupContent(city) {
        return `
            <div style="min-width: 250px;">
                <h2 style="margin: 0 0 15px 0; color: #333; text-align: center;">${city.name}</h2>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 15px;">
                    <div style="text-align: center; padding: 10px; background: #f8f9fa; border-radius: 8px;">
                        <div style="font-size: 24px; font-weight: bold; color: #ff6600;">${city.temperature}°C</div>
                        <div style="font-size: 12px; color: #666;">Temperature</div>
                    </div>
                    <div style="text-align: center; padding: 10px; background: #f8f9fa; border-radius: 8px;">
                        <div style="font-size: 24px; font-weight: bold; color: #0066cc;">${city.humidity}%</div>
                        <div style="font-size: 12px; color: #666;">Humidity</div>
                    </div>
                    <div style="text-align: center; padding: 10px; background: #f8f9fa; border-radius: 8px;">
                        <div style="font-size: 24px; font-weight: bold; color: #ffaa00;">${city.windSpeed} km/h</div>
                        <div style="font-size: 12px; color: #666;">Wind Speed</div>
                    </div>
                    <div style="text-align: center; padding: 10px; background: #f8f9fa; border-radius: 8px;">
                        <div style="font-size: 24px; font-weight: bold; color: #44aa44;">${city.pressure} hPa</div>
                        <div style="font-size: 12px; color: #666;">Pressure</div>
                    </div>
                </div>
                <div style="text-align: center; padding: 15px; background: linear-gradient(45deg, #667eea, #764ba2); color: white; border-radius: 8px; margin-bottom: 10px;">
                    <div style="font-size: 18px;">${this.getWeatherEmoji(city.condition)}</div>
                    <div style="font-size: 16px; font-weight: bold;">${city.condition}</div>
                </div>
                <div style="display: flex; justify-content: space-between; font-size: 12px; color: #666;">
                    <span>🌧️ Rainfall: ${city.rainfall} mm</span>
                    <span>☁️ Clouds: ${city.clouds}%</span>
                </div>
            </div>
        `;
    }

    startPeriodicUpdates() {
        setInterval(() => {
            this.updateWeatherData();
        }, 5 * 60 * 1000);
    }

    updateWeatherData() {
        this.weatherData.cities.forEach(city => {
            city.temperature += (Math.random() - 0.5) * 2;
            city.temperature = Math.max(-10, Math.min(45, city.temperature));
            
            city.humidity += (Math.random() - 0.5) * 5;
            city.humidity = Math.max(20, Math.min(95, city.humidity));
            
            city.windSpeed += (Math.random() - 0.5) * 3;
            city.windSpeed = Math.max(0, Math.min(50, city.windSpeed));
            
            city.pressure += (Math.random() - 0.5) * 2;
            city.pressure = Math.max(980, Math.min(1030, city.pressure));
            
            city.rainfall += (Math.random() - 0.5) * 5;
            city.rainfall = Math.max(0, Math.min(100, city.rainfall));
            
            city.clouds += (Math.random() - 0.5) * 10;
            city.clouds = Math.max(0, Math.min(100, city.clouds));
        });
        
        const avgTemp = this.weatherData.cities.reduce((sum, city) => sum + city.temperature, 0) / this.weatherData.cities.length;
        this.weatherData.global.averageTemperature = Math.round(avgTemp * 10) / 10;
        
        const avgHumidity = this.weatherData.cities.reduce((sum, city) => sum + city.humidity, 0) / this.weatherData.cities.length;
        this.weatherData.global.averageHumidity = Math.round(avgHumidity);
        
        this.weatherData.global.lastUpdated = new Date();
        
        this.addWeatherMarkers();
        this.updateInfoPanel();
    }

    destroy() {
        if (this.map) {
            this.map.remove();
        }
    }
}

window.WeatherMap = WeatherMap; 