"""
Drought Prediction Model
Uses advanced ML techniques to predict droughts based on:
- Vegetation indices (NDVI, EVI)
- Soil moisture content
- Precipitation patterns
- Temperature data
- Evapotranspiration rates
- Historical drought patterns
"""

import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import LSTM, Dense, Dropout, Conv1D, MaxPooling1D, Flatten
from tensorflow.keras.optimizers import Adam
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import joblib
import logging
from typing import Tuple, List, Dict, Optional
from datetime import datetime, timedelta
import xarray as xr
import rasterio
from rasterio.mask import mask
import geopandas as gpd

logger = logging.getLogger(__name__)

class DroughtPredictionModel:
    """
    Advanced drought prediction model using multiple data sources and ML techniques
    """
    
    def __init__(self, model_path: str = None):
        self.lstm_model = None
        self.cnn_model = None
        self.ensemble_model = None
        self.scaler = RobustScaler()
        self.feature_scaler = StandardScaler()
        self.is_trained = False
        
        if model_path:
            self.load_models(model_path)
    
    def build_lstm_model(self, input_shape: Tuple[int, int]) -> Sequential:
        """
        Build LSTM model for drought prediction
        """
        model = Sequential([
            LSTM(128, return_sequences=True, input_shape=input_shape),
            Dropout(0.3),
            LSTM(64, return_sequences=True),
            Dropout(0.3),
            LSTM(32, return_sequences=False),
            Dropout(0.2),
            Dense(64, activation='relu'),
            Dense(32, activation='relu'),
            Dense(16, activation='relu'),
            Dense(1, activation='linear')  # Regression output
        ])
        
        model.compile(
            optimizer=Adam(learning_rate=0.001),
            loss='mse',
            metrics=['mae', 'mape']
        )
        
        return model
    
    def build_cnn_model(self, input_shape: Tuple[int, int]) -> Sequential:
        """
        Build 1D CNN model for time series feature extraction
        """
        model = Sequential([
            Conv1D(64, 3, activation='relu', input_shape=input_shape),
            MaxPooling1D(2),
            Conv1D(128, 3, activation='relu'),
            MaxPooling1D(2),
            Conv1D(64, 3, activation='relu'),
            Flatten(),
            Dense(128, activation='relu'),
            Dropout(0.5),
            Dense(64, activation='relu'),
            Dense(32, activation='relu'),
            Dense(1, activation='linear')
        ])
        
        model.compile(
            optimizer=Adam(learning_rate=0.001),
            loss='mse',
            metrics=['mae']
        )
        
        return model
    
    def calculate_vegetation_indices(self, satellite_data: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate various vegetation indices from satellite data
        """
        # NDVI (Normalized Difference Vegetation Index)
        satellite_data['ndvi'] = (satellite_data['nir'] - satellite_data['red']) / (satellite_data['nir'] + satellite_data['red'])
        
        # EVI (Enhanced Vegetation Index)
        satellite_data['evi'] = 2.5 * (satellite_data['nir'] - satellite_data['red']) / (satellite_data['nir'] + 6 * satellite_data['red'] - 7.5 * satellite_data['blue'] + 1)
        
        # NDWI (Normalized Difference Water Index)
        satellite_data['ndwi'] = (satellite_data['green'] - satellite_data['nir']) / (satellite_data['green'] + satellite_data['nir'])
        
        # VCI (Vegetation Condition Index)
        satellite_data['vci'] = (satellite_data['ndvi'] - satellite_data['ndvi'].rolling(window=30).min()) / \
                               (satellite_data['ndvi'].rolling(window=30).max() - satellite_data['ndvi'].rolling(window=30).min())
        
        # TCI (Temperature Condition Index)
        satellite_data['tci'] = (satellite_data['lst'].rolling(window=30).max() - satellite_data['lst']) / \
                               (satellite_data['lst'].rolling(window=30).max() - satellite_data['lst'].rolling(window=30).min())
        
        return satellite_data
    
    def calculate_drought_indices(self, climate_data: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate various drought indices
        """
        # SPI (Standardized Precipitation Index) - 3, 6, 12 month periods
        for period in [3, 6, 12]:
            climate_data[f'spi_{period}m'] = self._calculate_spi(climate_data['precipitation'], period)
        
        # SPEI (Standardized Precipitation Evapotranspiration Index)
        climate_data['spei'] = self._calculate_spei(climate_data['precipitation'], climate_data['temperature'])
        
        # PDSI (Palmer Drought Severity Index)
        climate_data['pdsi'] = self._calculate_pdsi(climate_data)
        
        # VHI (Vegetation Health Index)
        climate_data['vhi'] = 0.5 * climate_data['vci'] + 0.5 * climate_data['tci']
        
        return climate_data
    
    def _calculate_spi(self, precipitation: pd.Series, period: int) -> pd.Series:
        """
        Calculate Standardized Precipitation Index
        """
        # Calculate rolling sum
        rolling_sum = precipitation.rolling(window=period).sum()
        
        # Fit gamma distribution and standardize
        # Simplified implementation - in production, use proper statistical fitting
        mean_val = rolling_sum.mean()
        std_val = rolling_sum.std()
        
        spi = (rolling_sum - mean_val) / std_val
        return spi
    
    def _calculate_spei(self, precipitation: pd.Series, temperature: pd.Series) -> pd.Series:
        """
        Calculate Standardized Precipitation Evapotranspiration Index
        """
        # Calculate potential evapotranspiration (Hargreaves method)
        pet = self._calculate_pet(temperature)
        
        # Calculate water balance
        water_balance = precipitation - pet
        
        # Standardize similar to SPI
        mean_wb = water_balance.mean()
        std_wb = water_balance.std()
        
        spei = (water_balance - mean_wb) / std_wb
        return spei
    
    def _calculate_pet(self, temperature: pd.Series) -> pd.Series:
        """
        Calculate Potential Evapotranspiration using Hargreaves method
        """
        # Simplified Hargreaves equation
        # In production, use more sophisticated methods
        pet = 0.0023 * (temperature + 17.8) * temperature ** 0.5
        return pet
    
    def _calculate_pdsi(self, climate_data: pd.DataFrame) -> pd.Series:
        """
        Calculate Palmer Drought Severity Index (simplified)
        """
        # Simplified PDSI calculation
        # In production, use the full Palmer algorithm
        precipitation = climate_data['precipitation']
        temperature = climate_data['temperature']
        
        # Calculate water balance
        water_balance = precipitation - self._calculate_pet(temperature)
        
        # Normalize to PDSI scale
        pdsi = water_balance / water_balance.std() * 2
        return pdsi
    
    def preprocess_data(self, climate_data: pd.DataFrame, satellite_data: pd.DataFrame,
                       soil_data: pd.DataFrame) -> pd.DataFrame:
        """
        Preprocess and combine all data sources
        """
        # Calculate vegetation indices
        satellite_data = self.calculate_vegetation_indices(satellite_data)
        
        # Calculate drought indices
        climate_data = self.calculate_drought_indices(climate_data)
        
        # Merge all data sources
        merged_data = climate_data.merge(satellite_data, on='timestamp', how='inner')
        merged_data = merged_data.merge(soil_data, on='timestamp', how='inner')
        
        # Feature engineering
        merged_data['precipitation_30d_avg'] = merged_data['precipitation'].rolling(window=30).mean()
        merged_data['precipitation_90d_avg'] = merged_data['precipitation'].rolling(window=90).mean()
        merged_data['temperature_30d_avg'] = merged_data['temperature'].rolling(window=30).mean()
        merged_data['soil_moisture_30d_avg'] = merged_data['soil_moisture'].rolling(window=30).mean()
        
        # Create lag features
        for lag in [1, 7, 14, 30]:
            merged_data[f'ndvi_lag_{lag}'] = merged_data['ndvi'].shift(lag)
            merged_data[f'precipitation_lag_{lag}'] = merged_data['precipitation'].shift(lag)
            merged_data[f'soil_moisture_lag_{lag}'] = merged_data['soil_moisture'].shift(lag)
        
        # Calculate trends
        merged_data['ndvi_trend'] = merged_data['ndvi'].rolling(window=30).apply(lambda x: np.polyfit(range(len(x)), x, 1)[0])
        merged_data['precipitation_trend'] = merged_data['precipitation'].rolling(window=30).apply(lambda x: np.polyfit(range(len(x)), x, 1)[0])
        
        # Fill NaN values
        merged_data = merged_data.fillna(method='bfill').fillna(method='ffill').fillna(0)
        
        return merged_data
    
    def create_sequences(self, data: np.ndarray, target: np.ndarray, 
                        sequence_length: int = 30) -> Tuple[np.ndarray, np.ndarray]:
        """
        Create sequences for time series prediction
        """
        X, y = [], []
        
        for i in range(sequence_length, len(data)):
            X.append(data[i-sequence_length:i])
            y.append(target[i])
        
        return np.array(X), np.array(y)
    
    def train(self, climate_data: pd.DataFrame, satellite_data: pd.DataFrame,
              soil_data: pd.DataFrame, drought_labels: np.ndarray,
              validation_split: float = 0.2) -> Dict:
        """
        Train the drought prediction model
        """
        logger.info("Starting drought model training...")
        
        # Preprocess data
        processed_data = self.preprocess_data(climate_data, satellite_data, soil_data)
        
        # Select features
        feature_columns = [
            'precipitation', 'temperature', 'humidity', 'wind_speed',
            'ndvi', 'evi', 'ndwi', 'vci', 'tci', 'vhi',
            'soil_moisture', 'soil_temperature',
            'spi_3m', 'spi_6m', 'spi_12m', 'spei', 'pdsi',
            'precipitation_30d_avg', 'precipitation_90d_avg',
            'temperature_30d_avg', 'soil_moisture_30d_avg'
        ] + [col for col in processed_data.columns if 'lag_' in col or 'trend' in col]
        
        features = processed_data[feature_columns].values
        features_scaled = self.feature_scaler.fit_transform(features)
        
        # Create sequences
        X, y = self.create_sequences(features_scaled, drought_labels)
        
        # Split data
        split_idx = int(len(X) * (1 - validation_split))
        X_train, X_val = X[:split_idx], X[split_idx:]
        y_train, y_val = y[:split_idx], y[split_idx:]
        
        # Train LSTM model
        self.lstm_model = self.build_lstm_model((X.shape[1], X.shape[2]))
        
        lstm_history = self.lstm_model.fit(
            X_train, y_train,
            validation_data=(X_val, y_val),
            epochs=100,
            batch_size=32,
            verbose=1,
            callbacks=[
                tf.keras.callbacks.EarlyStopping(patience=10, restore_best_weights=True)
            ]
        )
        
        # Train CNN model
        self.cnn_model = self.build_cnn_model((X.shape[1], X.shape[2]))
        
        cnn_history = self.cnn_model.fit(
            X_train, y_train,
            validation_data=(X_val, y_val),
            epochs=80,
            batch_size=32,
            verbose=1,
            callbacks=[
                tf.keras.callbacks.EarlyStopping(patience=10, restore_best_weights=True)
            ]
        )
        
        # Train ensemble model
        self.ensemble_model = GradientBoostingRegressor(
            n_estimators=200,
            learning_rate=0.05,
            max_depth=6,
            random_state=42
        )
        
        # Prepare ensemble features
        lstm_pred_train = self.lstm_model.predict(X_train).flatten()
        cnn_pred_train = self.cnn_model.predict(X_train).flatten()
        
        ensemble_features_train = np.column_stack([
            lstm_pred_train,
            cnn_pred_train,
            features_scaled[30:split_idx+30]  # Align with predictions
        ])
        
        self.ensemble_model.fit(ensemble_features_train, y_train)
        
        # Evaluate models
        metrics = self.evaluate(X_val, y_val)
        
        self.is_trained = True
        logger.info("Drought model training completed successfully")
        
        return {
            'lstm_history': lstm_history.history,
            'cnn_history': cnn_history.history,
            'metrics': metrics
        }
    
    def predict(self, climate_data: pd.DataFrame, satellite_data: pd.DataFrame,
                soil_data: pd.DataFrame) -> Dict:
        """
        Make drought predictions
        """
        if not self.is_trained:
            raise ValueError("Model must be trained before making predictions")
        
        # Preprocess data
        processed_data = self.preprocess_data(climate_data, satellite_data, soil_data)
        
        # Select features
        feature_columns = [
            'precipitation', 'temperature', 'humidity', 'wind_speed',
            'ndvi', 'evi', 'ndwi', 'vci', 'tci', 'vhi',
            'soil_moisture', 'soil_temperature',
            'spi_3m', 'spi_6m', 'spi_12m', 'spei', 'pdsi',
            'precipitation_30d_avg', 'precipitation_90d_avg',
            'temperature_30d_avg', 'soil_moisture_30d_avg'
        ] + [col for col in processed_data.columns if 'lag_' in col or 'trend' in col]
        
        features = processed_data[feature_columns].values
        features_scaled = self.feature_scaler.transform(features)
        
        # Create sequence for prediction
        X = features_scaled[-30:].reshape(1, 30, -1)
        
        # Get individual model predictions
        lstm_pred = self.lstm_model.predict(X)[0][0]
        cnn_pred = self.cnn_model.predict(X)[0][0]
        
        # Get ensemble prediction
        ensemble_features = np.column_stack([
            [lstm_pred],
            [cnn_pred],
            features_scaled[-1:]
        ])
        ensemble_pred = self.ensemble_model.predict(ensemble_features)[0]
        
        # Calculate drought severity
        severity = self._calculate_drought_severity(ensemble_pred)
        
        return {
            'drought_severity': float(ensemble_pred),
            'severity_level': severity,
            'lstm_prediction': float(lstm_pred),
            'cnn_prediction': float(cnn_pred),
            'ensemble_prediction': float(ensemble_pred),
            'timestamp': datetime.now().isoformat(),
            'confidence': self._calculate_confidence(lstm_pred, cnn_pred, ensemble_pred)
        }
    
    def _calculate_drought_severity(self, severity_score: float) -> str:
        """
        Calculate drought severity level
        """
        if severity_score < -2.0:
            return "EXTREME_DROUGHT"
        elif severity_score < -1.5:
            return "SEVERE_DROUGHT"
        elif severity_score < -1.0:
            return "MODERATE_DROUGHT"
        elif severity_score < -0.5:
            return "MILD_DROUGHT"
        elif severity_score < 0.5:
            return "NORMAL"
        else:
            return "WET_CONDITIONS"
    
    def _calculate_confidence(self, lstm_pred: float, cnn_pred: float, ensemble_pred: float) -> float:
        """
        Calculate prediction confidence based on model agreement
        """
        predictions = [lstm_pred, cnn_pred, ensemble_pred]
        std_dev = np.std(predictions)
        mean_pred = np.mean(predictions)
        
        # Higher confidence when models agree (lower std dev)
        confidence = max(0.5, 1.0 - std_dev / abs(mean_pred) if mean_pred != 0 else 0.8)
        return min(1.0, confidence)
    
    def evaluate(self, X_test: np.ndarray, y_test: np.ndarray) -> Dict:
        """
        Evaluate model performance
        """
        # LSTM predictions
        lstm_pred = self.lstm_model.predict(X_test).flatten()
        
        # CNN predictions
        cnn_pred = self.cnn_model.predict(X_test).flatten()
        
        # Ensemble predictions
        ensemble_features = np.column_stack([
            lstm_pred,
            cnn_pred,
            X_test[:, -1, :]  # Last timestep features
        ])
        ensemble_pred = self.ensemble_model.predict(ensemble_features)
        
        # Calculate metrics
        metrics = {
            'lstm': {
                'mse': mean_squared_error(y_test, lstm_pred),
                'mae': mean_absolute_error(y_test, lstm_pred),
                'r2': r2_score(y_test, lstm_pred)
            },
            'cnn': {
                'mse': mean_squared_error(y_test, cnn_pred),
                'mae': mean_absolute_error(y_test, cnn_pred),
                'r2': r2_score(y_test, cnn_pred)
            },
            'ensemble': {
                'mse': mean_squared_error(y_test, ensemble_pred),
                'mae': mean_absolute_error(y_test, ensemble_pred),
                'r2': r2_score(y_test, ensemble_pred)
            }
        }
        
        return metrics
    
    def save_models(self, path: str):
        """
        Save trained models
        """
        if self.lstm_model:
            self.lstm_model.save(f"{path}/drought_lstm_model.h5")
        
        if self.cnn_model:
            self.cnn_model.save(f"{path}/drought_cnn_model.h5")
        
        if self.ensemble_model:
            joblib.dump(self.ensemble_model, f"{path}/drought_ensemble_model.pkl")
        
        joblib.dump(self.scaler, f"{path}/drought_scaler.pkl")
        joblib.dump(self.feature_scaler, f"{path}/drought_feature_scaler.pkl")
        
        logger.info(f"Drought models saved to {path}")
    
    def load_models(self, path: str):
        """
        Load trained models
        """
        try:
            self.lstm_model = load_model(f"{path}/drought_lstm_model.h5")
            self.cnn_model = load_model(f"{path}/drought_cnn_model.h5")
            self.ensemble_model = joblib.load(f"{path}/drought_ensemble_model.pkl")
            self.scaler = joblib.load(f"{path}/drought_scaler.pkl")
            self.feature_scaler = joblib.load(f"{path}/drought_feature_scaler.pkl")
            self.is_trained = True
            
            logger.info(f"Drought models loaded from {path}")
        except Exception as e:
            logger.error(f"Error loading drought models: {e}")
            raise 