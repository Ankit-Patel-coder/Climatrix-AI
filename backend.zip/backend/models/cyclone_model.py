"""
Cyclone Prediction Model
Uses advanced deep learning techniques to predict cyclones based on:
- Atmospheric pressure patterns
- Sea surface temperatures (SST)
- Wind speed and direction
- Humidity and temperature profiles
- Ocean heat content
- Historical cyclone tracks
"""

import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import LSTM, Dense, Dropout, Conv2D, MaxPooling2D, Flatten, Reshape
from tensorflow.keras.optimizers import Adam
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
import joblib
import logging
from typing import Tuple, List, Dict, Optional
import cv2
from datetime import datetime, timedelta
import xarray as xr
import netCDF4 as nc

logger = logging.getLogger(__name__)

class CyclonePredictionModel:
    """
    Advanced cyclone prediction model using multiple data sources and deep learning
    """
    
    def __init__(self, model_path: str = None):
        self.lstm_model = None
        self.cnn_model = None
        self.ensemble_model = None
        self.scaler = StandardScaler()
        self.atmospheric_scaler = MinMaxScaler()
        self.ocean_scaler = StandardScaler()
        self.is_trained = False
        
        if model_path:
            self.load_models(model_path)
    
    def build_lstm_model(self, input_shape: Tuple[int, int]) -> Sequential:
        """
        Build LSTM model for atmospheric pattern recognition
        """
        model = Sequential([
            LSTM(256, return_sequences=True, input_shape=input_shape),
            Dropout(0.3),
            LSTM(128, return_sequences=True),
            Dropout(0.3),
            LSTM(64, return_sequences=False),
            Dropout(0.2),
            Dense(128, activation='relu'),
            Dense(64, activation='relu'),
            Dense(32, activation='relu'),
            Dense(1, activation='sigmoid')
        ])
        
        model.compile(
            optimizer=Adam(learning_rate=0.001),
            loss='binary_crossentropy',
            metrics=['accuracy', 'precision', 'recall']
        )
        
        return model
    
    def build_cnn_model(self, input_shape: Tuple[int, int, int]) -> Sequential:
        """
        Build CNN model for spatial atmospheric data processing
        """
        model = Sequential([
            Conv2D(64, (3, 3), activation='relu', input_shape=input_shape),
            MaxPooling2D((2, 2)),
            Conv2D(128, (3, 3), activation='relu'),
            MaxPooling2D((2, 2)),
            Conv2D(256, (3, 3), activation='relu'),
            MaxPooling2D((2, 2)),
            Conv2D(128, (3, 3), activation='relu'),
            Flatten(),
            Dense(256, activation='relu'),
            Dropout(0.5),
            Dense(128, activation='relu'),
            Dense(64, activation='relu'),
            Dense(1, activation='sigmoid')
        ])
        
        model.compile(
            optimizer=Adam(learning_rate=0.001),
            loss='binary_crossentropy',
            metrics=['accuracy']
        )
        
        return model
    
    def calculate_atmospheric_indices(self, atmospheric_data: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate various atmospheric indices for cyclone prediction
        """
        # Southern Oscillation Index (SOI)
        atmospheric_data['soi'] = self._calculate_soi(atmospheric_data)
        
        # Madden-Julian Oscillation (MJO) index
        atmospheric_data['mjo_index'] = self._calculate_mjo(atmospheric_data)
        
        # North Atlantic Oscillation (NAO)
        atmospheric_data['nao'] = self._calculate_nao(atmospheric_data)
        
        # Pacific Decadal Oscillation (PDO)
        atmospheric_data['pdo'] = self._calculate_pdo(atmospheric_data)
        
        # Vertical Wind Shear
        atmospheric_data['wind_shear'] = atmospheric_data['wind_200hpa'] - atmospheric_data['wind_850hpa']
        
        # Potential Intensity
        atmospheric_data['potential_intensity'] = self._calculate_potential_intensity(atmospheric_data)
        
        # Genesis Potential Index (GPI)
        atmospheric_data['gpi'] = self._calculate_gpi(atmospheric_data)
        
        return atmospheric_data
    
    def _calculate_soi(self, data: pd.DataFrame) -> pd.Series:
        """
        Calculate Southern Oscillation Index
        """
        # Simplified SOI calculation
        # In production, use proper pressure data from Tahiti and Darwin
        pressure_diff = data['pressure_tahiti'] - data['pressure_darwin']
        soi = (pressure_diff - pressure_diff.rolling(window=30).mean()) / pressure_diff.rolling(window=30).std()
        return soi
    
    def _calculate_mjo(self, data: pd.DataFrame) -> pd.Series:
        """
        Calculate Madden-Julian Oscillation index
        """
        # Simplified MJO calculation using outgoing longwave radiation
        olr_anomaly = data['olr'] - data['olr'].rolling(window=30).mean()
        mjo = olr_anomaly.rolling(window=7).mean()
        return mjo
    
    def _calculate_nao(self, data: pd.DataFrame) -> pd.Series:
        """
        Calculate North Atlantic Oscillation
        """
        # Simplified NAO calculation
        pressure_diff = data['pressure_iceland'] - data['pressure_azores']
        nao = (pressure_diff - pressure_diff.rolling(window=30).mean()) / pressure_diff.rolling(window=30).std()
        return nao
    
    def _calculate_pdo(self, data: pd.DataFrame) -> pd.Series:
        """
        Calculate Pacific Decadal Oscillation
        """
        # Simplified PDO calculation using SST anomalies
        sst_anomaly = data['sst'] - data['sst'].rolling(window=30).mean()
        pdo = sst_anomaly.rolling(window=120).mean()
        return pdo
    
    def _calculate_potential_intensity(self, data: pd.DataFrame) -> pd.Series:
        """
        Calculate potential intensity using SST and atmospheric conditions
        """
        # Simplified potential intensity calculation
        sst_celsius = data['sst'] - 273.15  # Convert to Celsius
        potential_intensity = 0.5 * sst_celsius + 0.3 * data['humidity'] + 0.2 * data['pressure']
        return potential_intensity
    
    def _calculate_gpi(self, data: pd.DataFrame) -> pd.Series:
        """
        Calculate Genesis Potential Index
        """
        # Simplified GPI calculation
        # GPI = |10^5 η|^(3/2) * (H/50)^3 * (Vpot/70)^3 * (1 + 0.1Vshear)^(-2)
        # Where η is absolute vorticity, H is relative humidity, Vpot is potential intensity, Vshear is wind shear
        
        abs_vorticity = abs(data['vorticity'])
        rel_humidity = data['humidity'] / 100.0  # Normalize to 0-1
        potential_intensity = data['potential_intensity']
        wind_shear = abs(data['wind_shear'])
        
        gpi = (abs_vorticity ** 1.5) * (rel_humidity ** 3) * (potential_intensity ** 3) * ((1 + 0.1 * wind_shear) ** (-2))
        return gpi
    
    def preprocess_atmospheric_data(self, atmospheric_data: pd.DataFrame) -> np.ndarray:
        """
        Preprocess atmospheric data for cyclone prediction
        """
        # Calculate atmospheric indices
        atmospheric_data = self.calculate_atmospheric_indices(atmospheric_data)
        
        # Feature engineering
        atmospheric_data['pressure_gradient'] = atmospheric_data['pressure'].diff()
        atmospheric_data['temperature_gradient'] = atmospheric_data['temperature'].diff()
        atmospheric_data['humidity_gradient'] = atmospheric_data['humidity'].diff()
        
        # Create lag features
        for lag in [1, 3, 6, 12, 24]:
            atmospheric_data[f'pressure_lag_{lag}'] = atmospheric_data['pressure'].shift(lag)
            atmospheric_data[f'temperature_lag_{lag}'] = atmospheric_data['temperature'].shift(lag)
            atmospheric_data[f'wind_speed_lag_{lag}'] = atmospheric_data['wind_speed'].shift(lag)
            atmospheric_data[f'sst_lag_{lag}'] = atmospheric_data['sst'].shift(lag)
        
        # Calculate rolling statistics
        atmospheric_data['pressure_24h_avg'] = atmospheric_data['pressure'].rolling(window=24).mean()
        atmospheric_data['temperature_24h_avg'] = atmospheric_data['temperature'].rolling(window=24).mean()
        atmospheric_data['wind_speed_24h_avg'] = atmospheric_data['wind_speed'].rolling(window=24).mean()
        atmospheric_data['sst_24h_avg'] = atmospheric_data['sst'].rolling(window=24).mean()
        
        # Fill NaN values
        atmospheric_data = atmospheric_data.fillna(method='bfill').fillna(method='ffill').fillna(0)
        
        # Select features
        feature_columns = [
            'pressure', 'temperature', 'humidity', 'wind_speed', 'wind_direction',
            'sst', 'olr', 'vorticity', 'divergence',
            'soi', 'mjo_index', 'nao', 'pdo', 'wind_shear',
            'potential_intensity', 'gpi',
            'pressure_gradient', 'temperature_gradient', 'humidity_gradient',
            'pressure_24h_avg', 'temperature_24h_avg', 'wind_speed_24h_avg', 'sst_24h_avg'
        ] + [col for col in atmospheric_data.columns if 'lag_' in col]
        
        return atmospheric_data[feature_columns].values
    
    def preprocess_ocean_data(self, ocean_data: pd.DataFrame) -> np.ndarray:
        """
        Preprocess ocean data for cyclone prediction
        """
        # Calculate ocean heat content
        ocean_data['ocean_heat_content'] = self._calculate_ocean_heat_content(ocean_data)
        
        # Calculate mixed layer depth
        ocean_data['mixed_layer_depth'] = self._calculate_mixed_layer_depth(ocean_data)
        
        # Calculate sea surface height anomalies
        ocean_data['ssh_anomaly'] = ocean_data['sea_surface_height'] - ocean_data['sea_surface_height'].rolling(window=30).mean()
        
        # Feature engineering
        ocean_data['sst_anomaly'] = ocean_data['sst'] - ocean_data['sst'].rolling(window=30).mean()
        ocean_data['sst_trend'] = ocean_data['sst'].rolling(window=30).apply(lambda x: np.polyfit(range(len(x)), x, 1)[0])
        
        # Create lag features
        for lag in [1, 3, 6, 12, 24]:
            ocean_data[f'ocean_heat_content_lag_{lag}'] = ocean_data['ocean_heat_content'].shift(lag)
            ocean_data[f'sst_anomaly_lag_{lag}'] = ocean_data['sst_anomaly'].shift(lag)
        
        # Fill NaN values
        ocean_data = ocean_data.fillna(method='bfill').fillna(method='ffill').fillna(0)
        
        # Select features
        feature_columns = [
            'sst', 'ocean_heat_content', 'mixed_layer_depth', 'sea_surface_height',
            'ssh_anomaly', 'sst_anomaly', 'sst_trend'
        ] + [col for col in ocean_data.columns if 'lag_' in col]
        
        return ocean_data[feature_columns].values
    
    def _calculate_ocean_heat_content(self, ocean_data: pd.DataFrame) -> pd.Series:
        """
        Calculate ocean heat content
        """
        # Simplified OHC calculation
        # OHC = ρ * Cp * ∫T(z)dz from surface to 26°C isotherm
        # Simplified as: OHC = constant * SST * mixed_layer_depth
        constant = 4.2e6  # J/m³/K
        ohc = constant * ocean_data['sst'] * ocean_data['mixed_layer_depth']
        return ohc
    
    def _calculate_mixed_layer_depth(self, ocean_data: pd.DataFrame) -> pd.Series:
        """
        Calculate mixed layer depth
        """
        # Simplified MLD calculation
        # In production, use proper temperature profile data
        mld = 50 + 10 * np.sin(2 * np.pi * ocean_data.index / 365)  # Seasonal variation
        return mld
    
    def create_sequences(self, data: np.ndarray, target: np.ndarray, 
                        sequence_length: int = 48) -> Tuple[np.ndarray, np.ndarray]:
        """
        Create sequences for time series prediction
        """
        X, y = [], []
        
        for i in range(sequence_length, len(data)):
            X.append(data[i-sequence_length:i])
            y.append(target[i])
        
        return np.array(X), np.array(y)
    
    def create_spatial_sequences(self, spatial_data: List[np.ndarray], target: np.ndarray,
                                sequence_length: int = 24) -> Tuple[np.ndarray, np.ndarray]:
        """
        Create spatial sequences for CNN processing
        """
        X, y = [], []
        
        for i in range(sequence_length, len(spatial_data)):
            sequence = spatial_data[i-sequence_length:i]
            X.append(np.array(sequence))
            y.append(target[i])
        
        return np.array(X), np.array(y)
    
    def train(self, atmospheric_data: pd.DataFrame, ocean_data: pd.DataFrame,
              spatial_data: List[np.ndarray], cyclone_labels: np.ndarray,
              validation_split: float = 0.2) -> Dict:
        """
        Train the cyclone prediction model
        """
        logger.info("Starting cyclone model training...")
        
        # Preprocess data
        atmospheric_features = self.preprocess_atmospheric_data(atmospheric_data)
        ocean_features = self.preprocess_ocean_data(ocean_data)
        
        # Combine features
        combined_features = np.column_stack([atmospheric_features, ocean_features])
        combined_features_scaled = self.scaler.fit_transform(combined_features)
        
        # Create sequences
        X_temporal, y = self.create_sequences(combined_features_scaled, cyclone_labels)
        
        # Create spatial sequences if available
        X_spatial = None
        if spatial_data:
            X_spatial, y_spatial = self.create_spatial_sequences(spatial_data, cyclone_labels)
            # Ensure spatial and temporal data are aligned
            min_len = min(len(X_temporal), len(X_spatial))
            X_temporal = X_temporal[:min_len]
            X_spatial = X_spatial[:min_len]
            y = y[:min_len]
        
        # Split data
        split_idx = int(len(X_temporal) * (1 - validation_split))
        X_train_temp, X_val_temp = X_temporal[:split_idx], X_temporal[split_idx:]
        y_train, y_val = y[:split_idx], y[split_idx:]
        
        # Train LSTM model
        self.lstm_model = self.build_lstm_model((X_temporal.shape[1], X_temporal.shape[2]))
        
        lstm_history = self.lstm_model.fit(
            X_train_temp, y_train,
            validation_data=(X_val_temp, y_val),
            epochs=100,
            batch_size=32,
            verbose=1,
            callbacks=[
                tf.keras.callbacks.EarlyStopping(patience=15, restore_best_weights=True)
            ]
        )
        
        # Train CNN model if spatial data available
        cnn_history = None
        if X_spatial is not None:
            X_train_spat, X_val_spat = X_spatial[:split_idx], X_spatial[split_idx:]
            
            self.cnn_model = self.build_cnn_model((X_spatial.shape[1], X_spatial.shape[2], X_spatial.shape[3]))
            
            cnn_history = self.cnn_model.fit(
                X_train_spat, y_train,
                validation_data=(X_val_spat, y_val),
                epochs=80,
                batch_size=32,
                verbose=1,
                callbacks=[
                    tf.keras.callbacks.EarlyStopping(patience=15, restore_best_weights=True)
                ]
            )
        
        # Train ensemble model
        self.ensemble_model = GradientBoostingClassifier(
            n_estimators=200,
            learning_rate=0.05,
            max_depth=8,
            random_state=42
        )
        
        # Prepare ensemble features
        lstm_pred_train = self.lstm_model.predict(X_train_temp).flatten()
        
        ensemble_features_train = np.column_stack([
            lstm_pred_train,
            combined_features_scaled[48:split_idx+48]  # Align with predictions
        ])
        
        if X_spatial is not None:
            cnn_pred_train = self.cnn_model.predict(X_train_spat).flatten()
            ensemble_features_train = np.column_stack([
                ensemble_features_train,
                cnn_pred_train
            ])
        
        self.ensemble_model.fit(ensemble_features_train, y_train)
        
        # Evaluate models
        metrics = self.evaluate(X_val_temp, y_val, X_spatial[split_idx:] if X_spatial is not None else None)
        
        self.is_trained = True
        logger.info("Cyclone model training completed successfully")
        
        return {
            'lstm_history': lstm_history.history,
            'cnn_history': cnn_history.history if cnn_history else None,
            'metrics': metrics
        }
    
    def predict(self, atmospheric_data: pd.DataFrame, ocean_data: pd.DataFrame,
                spatial_data: Optional[List[np.ndarray]] = None) -> Dict:
        """
        Make cyclone predictions
        """
        if not self.is_trained:
            raise ValueError("Model must be trained before making predictions")
        
        # Preprocess data
        atmospheric_features = self.preprocess_atmospheric_data(atmospheric_data)
        ocean_features = self.preprocess_ocean_data(ocean_data)
        
        # Combine features
        combined_features = np.column_stack([atmospheric_features, ocean_features])
        combined_features_scaled = self.scaler.transform(combined_features)
        
        # Create sequence for prediction
        X_temporal = combined_features_scaled[-48:].reshape(1, 48, -1)
        
        # Get LSTM prediction
        lstm_pred = self.lstm_model.predict(X_temporal)[0][0]
        
        # Get CNN prediction if spatial data available
        cnn_pred = None
        if spatial_data and self.cnn_model:
            X_spatial = np.array(spatial_data[-24:]).reshape(1, 24, spatial_data[0].shape[0], spatial_data[0].shape[1])
            cnn_pred = self.cnn_model.predict(X_spatial)[0][0]
        
        # Get ensemble prediction
        ensemble_features = np.column_stack([
            [lstm_pred],
            combined_features_scaled[-1:]
        ])
        
        if cnn_pred is not None:
            ensemble_features = np.column_stack([
                ensemble_features,
                [cnn_pred]
            ])
        
        ensemble_pred = self.ensemble_model.predict_proba(ensemble_features)[0][1]
        
        # Calculate cyclone intensity and risk level
        intensity = self._calculate_cyclone_intensity(ensemble_pred)
        risk_level = self._calculate_risk_level(ensemble_pred)
        
        return {
            'cyclone_probability': float(ensemble_pred),
            'intensity': intensity,
            'risk_level': risk_level,
            'lstm_prediction': float(lstm_pred),
            'cnn_prediction': float(cnn_pred) if cnn_pred else None,
            'ensemble_prediction': float(ensemble_pred),
            'timestamp': datetime.now().isoformat(),
            'confidence': self._calculate_confidence(lstm_pred, cnn_pred, ensemble_pred)
        }
    
    def _calculate_cyclone_intensity(self, probability: float) -> str:
        """
        Calculate cyclone intensity based on probability
        """
        if probability < 0.3:
            return "TROPICAL_DEPRESSION"
        elif probability < 0.5:
            return "TROPICAL_STORM"
        elif probability < 0.7:
            return "CATEGORY_1"
        elif probability < 0.85:
            return "CATEGORY_2"
        elif probability < 0.95:
            return "CATEGORY_3"
        else:
            return "MAJOR_HURRICANE"
    
    def _calculate_risk_level(self, probability: float) -> str:
        """
        Calculate risk level based on cyclone probability
        """
        if probability < 0.2:
            return "LOW"
        elif probability < 0.4:
            return "MODERATE"
        elif probability < 0.6:
            return "HIGH"
        elif probability < 0.8:
            return "VERY_HIGH"
        else:
            return "EXTREME"
    
    def _calculate_confidence(self, lstm_pred: float, cnn_pred: Optional[float], ensemble_pred: float) -> float:
        """
        Calculate prediction confidence based on model agreement
        """
        predictions = [lstm_pred, ensemble_pred]
        if cnn_pred is not None:
            predictions.append(cnn_pred)
        
        std_dev = np.std(predictions)
        mean_pred = np.mean(predictions)
        
        # Higher confidence when models agree (lower std dev)
        confidence = max(0.5, 1.0 - std_dev / abs(mean_pred) if mean_pred != 0 else 0.8)
        return min(1.0, confidence)
    
    def evaluate(self, X_test: np.ndarray, y_test: np.ndarray,
                spatial_test: Optional[List[np.ndarray]] = None) -> Dict:
        """
        Evaluate model performance
        """
        # LSTM predictions
        lstm_pred = self.lstm_model.predict(X_test).flatten()
        lstm_pred_binary = (lstm_pred > 0.5).astype(int)
        
        # CNN predictions
        cnn_pred = None
        cnn_pred_binary = None
        if spatial_test and self.cnn_model:
            X_spat_test = np.array(spatial_test)
            cnn_pred = self.cnn_model.predict(X_spat_test).flatten()
            cnn_pred_binary = (cnn_pred > 0.5).astype(int)
        
        # Ensemble predictions
        ensemble_features = np.column_stack([
            lstm_pred,
            X_test[:, -1, :]  # Last timestep features
        ])
        
        if cnn_pred is not None:
            ensemble_features = np.column_stack([
                ensemble_features,
                cnn_pred
            ])
        
        ensemble_pred = self.ensemble_model.predict_proba(ensemble_features)[:, 1]
        ensemble_pred_binary = (ensemble_pred > 0.5).astype(int)
        
        # Calculate metrics
        metrics = {
            'lstm': {
                'accuracy': accuracy_score(y_test, lstm_pred_binary),
                'precision': precision_score(y_test, lstm_pred_binary, zero_division=0),
                'recall': recall_score(y_test, lstm_pred_binary, zero_division=0),
                'f1_score': f1_score(y_test, lstm_pred_binary, zero_division=0),
                'roc_auc': roc_auc_score(y_test, lstm_pred)
            },
            'ensemble': {
                'accuracy': accuracy_score(y_test, ensemble_pred_binary),
                'precision': precision_score(y_test, ensemble_pred_binary, zero_division=0),
                'recall': recall_score(y_test, ensemble_pred_binary, zero_division=0),
                'f1_score': f1_score(y_test, ensemble_pred_binary, zero_division=0),
                'roc_auc': roc_auc_score(y_test, ensemble_pred)
            }
        }
        
        if cnn_pred is not None:
            metrics['cnn'] = {
                'accuracy': accuracy_score(y_test, cnn_pred_binary),
                'precision': precision_score(y_test, cnn_pred_binary, zero_division=0),
                'recall': recall_score(y_test, cnn_pred_binary, zero_division=0),
                'f1_score': f1_score(y_test, cnn_pred_binary, zero_division=0),
                'roc_auc': roc_auc_score(y_test, cnn_pred)
            }
        
        return metrics
    
    def save_models(self, path: str):
        """
        Save trained models
        """
        if self.lstm_model:
            self.lstm_model.save(f"{path}/cyclone_lstm_model.h5")
        
        if self.cnn_model:
            self.cnn_model.save(f"{path}/cyclone_cnn_model.h5")
        
        if self.ensemble_model:
            joblib.dump(self.ensemble_model, f"{path}/cyclone_ensemble_model.pkl")
        
        joblib.dump(self.scaler, f"{path}/cyclone_scaler.pkl")
        joblib.dump(self.atmospheric_scaler, f"{path}/cyclone_atmospheric_scaler.pkl")
        joblib.dump(self.ocean_scaler, f"{path}/cyclone_ocean_scaler.pkl")
        
        logger.info(f"Cyclone models saved to {path}")
    
    def load_models(self, path: str):
        """
        Load trained models
        """
        try:
            self.lstm_model = load_model(f"{path}/cyclone_lstm_model.h5")
            self.cnn_model = load_model(f"{path}/cyclone_cnn_model.h5")
            self.ensemble_model = joblib.load(f"{path}/cyclone_ensemble_model.pkl")
            self.scaler = joblib.load(f"{path}/cyclone_scaler.pkl")
            self.atmospheric_scaler = joblib.load(f"{path}/cyclone_atmospheric_scaler.pkl")
            self.ocean_scaler = joblib.load(f"{path}/cyclone_ocean_scaler.pkl")
            self.is_trained = True
            
            logger.info(f"Cyclone models loaded from {path}")
        except Exception as e:
            logger.error(f"Error loading cyclone models: {e}")
            raise 