"""
Flood Prediction Model
Uses LSTM networks and ensemble methods to predict floods based on:
- River water levels
- Rainfall data
- Satellite imagery (water body detection)
- Soil moisture
- Historical flood patterns
"""

import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import LSTM, Dense, Dropout, Conv2D, MaxPooling2D, Flatten
from tensorflow.keras.optimizers import Adam
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
import joblib
import logging
from typing import Tuple, List, Dict, Optional
import cv2
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class FloodPredictionModel:
    """
    Advanced flood prediction model combining LSTM, CNN, and ensemble methods
    """
    
    def __init__(self, model_path: str = None):
        self.lstm_model = None
        self.cnn_model = None
        self.ensemble_model = None
        self.scaler = StandardScaler()
        self.image_scaler = MinMaxScaler()
        self.is_trained = False
        
        if model_path:
            self.load_models(model_path)
    
    def build_lstm_model(self, input_shape: Tuple[int, int]) -> Sequential:
        """
        Build LSTM model for time series prediction
        """
        model = Sequential([
            LSTM(128, return_sequences=True, input_shape=input_shape),
            Dropout(0.2),
            LSTM(64, return_sequences=False),
            Dropout(0.2),
            Dense(32, activation='relu'),
            Dense(16, activation='relu'),
            Dense(1, activation='sigmoid')
        ])
        
        model.compile(
            optimizer=Adam(learning_rate=0.001),
            loss='binary_crossentropy',
            metrics=['accuracy', 'precision', 'recall']
        )
        
        return model
    
    def build_cnn_model(self, input_shape: Tuple[int, int, int]) -> Sequential:
        """
        Build CNN model for satellite image processing
        """
        model = Sequential([
            Conv2D(32, (3, 3), activation='relu', input_shape=input_shape),
            MaxPooling2D((2, 2)),
            Conv2D(64, (3, 3), activation='relu'),
            MaxPooling2D((2, 2)),
            Conv2D(64, (3, 3), activation='relu'),
            Flatten(),
            Dense(64, activation='relu'),
            Dropout(0.5),
            Dense(32, activation='relu'),
            Dense(1, activation='sigmoid')
        ])
        
        model.compile(
            optimizer=Adam(learning_rate=0.001),
            loss='binary_crossentropy',
            metrics=['accuracy']
        )
        
        return model
    
    def preprocess_temporal_data(self, data: pd.DataFrame) -> np.ndarray:
        """
        Preprocess temporal data (river levels, rainfall, etc.)
        """
        # Feature engineering
        data['rainfall_3h_avg'] = data['rainfall'].rolling(window=3).mean()
        data['rainfall_24h_avg'] = data['rainfall'].rolling(window=24).mean()
        data['water_level_change'] = data['water_level'].diff()
        data['water_level_velocity'] = data['water_level_change'].diff()
        
        # Create lag features
        for lag in [1, 3, 6, 12, 24]:
            data[f'water_level_lag_{lag}'] = data['water_level'].shift(lag)
            data[f'rainfall_lag_{lag}'] = data['rainfall'].shift(lag)
        
        # Fill NaN values
        data = data.fillna(method='bfill').fillna(0)
        
        # Select features
        feature_columns = [
            'water_level', 'rainfall', 'temperature', 'humidity',
            'rainfall_3h_avg', 'rainfall_24h_avg', 'water_level_change',
            'water_level_velocity'
        ] + [col for col in data.columns if 'lag_' in col]
        
        return data[feature_columns].values
    
    def preprocess_satellite_images(self, images: List[np.ndarray]) -> np.ndarray:
        """
        Preprocess satellite images for water body detection
        """
        processed_images = []
        
        for img in images:
            # Resize to standard size
            img_resized = cv2.resize(img, (64, 64))
            
            # Normalize pixel values
            img_normalized = img_resized / 255.0
            
            # Apply water body detection filters
            # Convert to HSV for better water detection
            if len(img_normalized.shape) == 3:
                hsv = cv2.cvtColor(img_normalized, cv2.COLOR_RGB2HSV)
                # Water typically has low saturation and medium value
                water_mask = cv2.inRange(hsv, (100, 0, 0), (130, 255, 255))
                water_ratio = np.sum(water_mask > 0) / (64 * 64)
                
                # Add water ratio as additional feature
                img_with_water = np.append(img_normalized.flatten(), water_ratio)
            else:
                img_with_water = img_normalized.flatten()
            
            processed_images.append(img_with_water)
        
        return np.array(processed_images)
    
    def create_sequences(self, data: np.ndarray, target: np.ndarray, 
                        sequence_length: int = 24) -> Tuple[np.ndarray, np.ndarray]:
        """
        Create sequences for LSTM training
        """
        X, y = [], []
        
        for i in range(sequence_length, len(data)):
            X.append(data[i-sequence_length:i])
            y.append(target[i])
        
        return np.array(X), np.array(y)
    
    def train(self, temporal_data: pd.DataFrame, satellite_data: List[np.ndarray],
              labels: np.ndarray, validation_split: float = 0.2) -> Dict:
        """
        Train the flood prediction model
        """
        logger.info("Starting flood model training...")
        
        # Preprocess temporal data
        temporal_features = self.preprocess_temporal_data(temporal_data)
        temporal_features_scaled = self.scaler.fit_transform(temporal_features)
        
        # Create sequences
        X_temporal, y = self.create_sequences(temporal_features_scaled, labels)
        
        # Preprocess satellite data
        if satellite_data:
            X_satellite = self.preprocess_satellite_images(satellite_data)
            X_satellite = X_satellite[:len(y)]  # Align with temporal data
        
        # Split data
        split_idx = int(len(X_temporal) * (1 - validation_split))
        X_train_temp, X_val_temp = X_temporal[:split_idx], X_temporal[split_idx:]
        y_train, y_val = y[:split_idx], y[split_idx:]
        
        # Train LSTM model
        self.lstm_model = self.build_lstm_model((X_temporal.shape[1], X_temporal.shape[2]))
        
        lstm_history = self.lstm_model.fit(
            X_train_temp, y_train,
            validation_data=(X_val_temp, y_val),
            epochs=50,
            batch_size=32,
            verbose=1
        )
        
        # Train CNN model if satellite data available
        if satellite_data:
            X_train_sat, X_val_sat = X_satellite[:split_idx], X_satellite[split_idx:]
            
            # Reshape for CNN (assuming 64x64 images)
            X_train_sat_reshaped = X_train_sat.reshape(-1, 64, 64, 3)
            X_val_sat_reshaped = X_val_sat.reshape(-1, 64, 64, 3)
            
            self.cnn_model = self.build_cnn_model((64, 64, 3))
            
            cnn_history = self.cnn_model.fit(
                X_train_sat_reshaped, y_train,
                validation_data=(X_val_sat_reshaped, y_val),
                epochs=30,
                batch_size=32,
                verbose=1
            )
        
        # Train ensemble model
        self.ensemble_model = GradientBoostingClassifier(
            n_estimators=100,
            learning_rate=0.1,
            max_depth=5,
            random_state=42
        )
        
        # Prepare ensemble features
        lstm_pred_train = self.lstm_model.predict(X_train_temp).flatten()
        ensemble_features_train = np.column_stack([
            lstm_pred_train,
            temporal_features_scaled[24:split_idx+24]  # Align with predictions
        ])
        
        self.ensemble_model.fit(ensemble_features_train, y_train)
        
        # Evaluate models
        metrics = self.evaluate(X_val_temp, y_val, satellite_data[split_idx:] if satellite_data else None)
        
        self.is_trained = True
        logger.info("Flood model training completed successfully")
        
        return {
            'lstm_history': lstm_history.history,
            'cnn_history': cnn_history.history if satellite_data else None,
            'metrics': metrics
        }
    
    def predict(self, temporal_data: pd.DataFrame, 
                satellite_data: Optional[List[np.ndarray]] = None) -> Dict:
        """
        Make flood predictions
        """
        if not self.is_trained:
            raise ValueError("Model must be trained before making predictions")
        
        # Preprocess temporal data
        temporal_features = self.preprocess_temporal_data(temporal_data)
        temporal_features_scaled = self.scaler.transform(temporal_features)
        
        # Create sequence for prediction
        X_temporal = temporal_features_scaled[-24:].reshape(1, 24, -1)
        
        # Get LSTM prediction
        lstm_pred = self.lstm_model.predict(X_temporal)[0][0]
        
        # Get CNN prediction if satellite data available
        cnn_pred = None
        if satellite_data and self.cnn_model:
            X_satellite = self.preprocess_satellite_images(satellite_data[-1:])
            X_satellite_reshaped = X_satellite.reshape(-1, 64, 64, 3)
            cnn_pred = self.cnn_model.predict(X_satellite_reshaped)[0][0]
        
        # Get ensemble prediction
        ensemble_features = np.column_stack([
            [lstm_pred],
            temporal_features_scaled[-1:]
        ])
        ensemble_pred = self.ensemble_model.predict_proba(ensemble_features)[0][1]
        
        # Calculate confidence and risk level
        confidence = ensemble_pred
        risk_level = self._calculate_risk_level(confidence)
        
        return {
            'flood_probability': float(confidence),
            'risk_level': risk_level,
            'lstm_prediction': float(lstm_pred),
            'cnn_prediction': float(cnn_pred) if cnn_pred else None,
            'ensemble_prediction': float(ensemble_pred),
            'timestamp': datetime.now().isoformat(),
            'confidence': float(confidence)
        }
    
    def _calculate_risk_level(self, probability: float) -> str:
        """
        Calculate risk level based on flood probability
        """
        if probability < 0.3:
            return "LOW"
        elif probability < 0.6:
            return "MEDIUM"
        elif probability < 0.8:
            return "HIGH"
        else:
            return "CRITICAL"
    
    def evaluate(self, X_test: np.ndarray, y_test: np.ndarray,
                satellite_test: Optional[List[np.ndarray]] = None) -> Dict:
        """
        Evaluate model performance
        """
        # LSTM predictions
        lstm_pred = self.lstm_model.predict(X_test).flatten()
        lstm_pred_binary = (lstm_pred > 0.5).astype(int)
        
        # CNN predictions
        cnn_pred = None
        cnn_pred_binary = None
        if satellite_test and self.cnn_model:
            X_sat_test = self.preprocess_satellite_images(satellite_test)
            X_sat_test_reshaped = X_sat_test.reshape(-1, 64, 64, 3)
            cnn_pred = self.cnn_model.predict(X_sat_test_reshaped).flatten()
            cnn_pred_binary = (cnn_pred > 0.5).astype(int)
        
        # Ensemble predictions
        ensemble_features = np.column_stack([
            lstm_pred,
            X_test[:, -1, :]  # Last timestep features
        ])
        ensemble_pred = self.ensemble_model.predict_proba(ensemble_features)[:, 1]
        ensemble_pred_binary = (ensemble_pred > 0.5).astype(int)
        
        # Calculate metrics
        metrics = {
            'lstm': {
                'accuracy': accuracy_score(y_test, lstm_pred_binary),
                'precision': precision_score(y_test, lstm_pred_binary, zero_division=0),
                'recall': recall_score(y_test, lstm_pred_binary, zero_division=0),
                'f1_score': f1_score(y_test, lstm_pred_binary, zero_division=0),
                'roc_auc': roc_auc_score(y_test, lstm_pred)
            },
            'ensemble': {
                'accuracy': accuracy_score(y_test, ensemble_pred_binary),
                'precision': precision_score(y_test, ensemble_pred_binary, zero_division=0),
                'recall': recall_score(y_test, ensemble_pred_binary, zero_division=0),
                'f1_score': f1_score(y_test, ensemble_pred_binary, zero_division=0),
                'roc_auc': roc_auc_score(y_test, ensemble_pred)
            }
        }
        
        if cnn_pred is not None:
            metrics['cnn'] = {
                'accuracy': accuracy_score(y_test, cnn_pred_binary),
                'precision': precision_score(y_test, cnn_pred_binary, zero_division=0),
                'recall': recall_score(y_test, cnn_pred_binary, zero_division=0),
                'f1_score': f1_score(y_test, cnn_pred_binary, zero_division=0),
                'roc_auc': roc_auc_score(y_test, cnn_pred)
            }
        
        return metrics
    
    def save_models(self, path: str):
        """
        Save trained models
        """
        if self.lstm_model:
            self.lstm_model.save(f"{path}/lstm_model.h5")
        
        if self.cnn_model:
            self.cnn_model.save(f"{path}/cnn_model.h5")
        
        if self.ensemble_model:
            joblib.dump(self.ensemble_model, f"{path}/ensemble_model.pkl")
        
        joblib.dump(self.scaler, f"{path}/scaler.pkl")
        joblib.dump(self.image_scaler, f"{path}/image_scaler.pkl")
        
        logger.info(f"Models saved to {path}")
    
    def load_models(self, path: str):
        """
        Load trained models
        """
        try:
            self.lstm_model = load_model(f"{path}/lstm_model.h5")
            self.cnn_model = load_model(f"{path}/cnn_model.h5")
            self.ensemble_model = joblib.load(f"{path}/ensemble_model.pkl")
            self.scaler = joblib.load(f"{path}/scaler.pkl")
            self.image_scaler = joblib.load(f"{path}/image_scaler.pkl")
            self.is_trained = True
            
            logger.info(f"Models loaded from {path}")
        except Exception as e:
            logger.error(f"Error loading models: {e}")
            raise 