"""
Simplified AI Models for Demo (No TensorFlow Required)
Uses scikit-learn and other available libraries
"""

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor, GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import logging
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime
import json

logger = logging.getLogger(__name__)

class SimpleFloodModel:
    """Simplified flood prediction model using scikit-learn"""
    
    def __init__(self):
        self.model = GradientBoostingClassifier(n_estimators=100, random_state=42)
        self.scaler = StandardScaler()
        self.is_trained = False
        
    def preprocess_data(self, data: pd.DataFrame) -> np.ndarray:
        """Preprocess input data"""
        # Extract relevant features
        features = []
        for _, row in data.iterrows():
            feature_vector = [
                row.get('precipitation', 0),
                row.get('temperature', 20),
                row.get('humidity', 50),
                row.get('pressure', 1013),
                row.get('wind_speed', 0),
                row.get('water_level', 0),
                row.get('soil_moisture', 0.5)
            ]
            features.append(feature_vector)
        
        return np.array(features)
    
    def train(self, data: pd.DataFrame, labels: np.ndarray):
        """Train the model"""
        X = self.preprocess_data(data)
        X_scaled = self.scaler.fit_transform(X)
        
        self.model.fit(X_scaled, labels)
        self.is_trained = True
        logger.info("Flood model trained successfully")
    
    def predict(self, data: pd.DataFrame) -> Dict:
        """Make prediction"""
        if not self.is_trained:
            # Return simulated prediction for demo
            return {
                "probability": 0.75,
                "risk_level": "HIGH",
                "confidence": 0.85,
                "timestamp": datetime.now().isoformat(),
                "water_level": 2.5,
                "rainfall_24h": 45.2
            }
        
        X = self.preprocess_data(data)
        X_scaled = self.scaler.transform(X)
        
        probability = self.model.predict_proba(X_scaled)[0][1]
        
        # Determine risk level
        if probability > 0.7:
            risk_level = "HIGH"
        elif probability > 0.4:
            risk_level = "MEDIUM"
        else:
            risk_level = "LOW"
        
        return {
            "probability": float(probability),
            "risk_level": risk_level,
            "confidence": 0.85,
            "timestamp": datetime.now().isoformat(),
            "water_level": data.iloc[0].get('water_level', 0),
            "rainfall_24h": data.iloc[0].get('precipitation', 0)
        }

class SimpleDroughtModel:
    """Simplified drought prediction model using scikit-learn"""
    
    def __init__(self):
        self.model = RandomForestRegressor(n_estimators=100, random_state=42)
        self.scaler = StandardScaler()
        self.is_trained = False
        
    def preprocess_data(self, data: pd.DataFrame) -> np.ndarray:
        """Preprocess input data"""
        features = []
        for _, row in data.iterrows():
            feature_vector = [
                row.get('temperature', 20),
                row.get('precipitation', 0),
                row.get('humidity', 50),
                row.get('soil_moisture', 0.5),
                row.get('ndvi', 0.3),
                row.get('evi', 0.2),
                row.get('lst', 25)
            ]
            features.append(feature_vector)
        
        return np.array(features)
    
    def train(self, data: pd.DataFrame, labels: np.ndarray):
        """Train the model"""
        X = self.preprocess_data(data)
        X_scaled = self.scaler.fit_transform(X)
        
        self.model.fit(X_scaled, labels)
        self.is_trained = True
        logger.info("Drought model trained successfully")
    
    def predict(self, data: pd.DataFrame) -> Dict:
        """Make prediction"""
        if not self.is_trained:
            # Return simulated prediction for demo
            return {
                "probability": 0.45,
                "risk_level": "MEDIUM",
                "confidence": 0.78,
                "timestamp": datetime.now().isoformat(),
                "vegetation_health": 0.6,
                "soil_moisture": 0.3
            }
        
        X = self.preprocess_data(data)
        X_scaled = self.scaler.transform(X)
        
        severity = self.model.predict(X_scaled)[0]
        probability = max(0, min(1, severity / 10))  # Normalize to 0-1
        
        # Determine risk level
        if probability > 0.6:
            risk_level = "HIGH"
        elif probability > 0.3:
            risk_level = "MEDIUM"
        else:
            risk_level = "LOW"
        
        return {
            "probability": float(probability),
            "risk_level": risk_level,
            "confidence": 0.78,
            "timestamp": datetime.now().isoformat(),
            "vegetation_health": data.iloc[0].get('ndvi', 0.3),
            "soil_moisture": data.iloc[0].get('soil_moisture', 0.5)
        }

class SimpleCycloneModel:
    """Simplified cyclone prediction model using scikit-learn"""
    
    def __init__(self):
        self.model = RandomForestClassifier(n_estimators=100, random_state=42)
        self.scaler = StandardScaler()
        self.is_trained = False
        
    def preprocess_data(self, data: pd.DataFrame) -> np.ndarray:
        """Preprocess input data"""
        features = []
        for _, row in data.iterrows():
            feature_vector = [
                row.get('pressure', 1013),
                row.get('temperature', 20),
                row.get('wind_speed', 0),
                row.get('humidity', 50),
                row.get('sst', 25),  # Sea surface temperature
                row.get('wind_shear', 0),
                row.get('relative_humidity', 50)
            ]
            features.append(feature_vector)
        
        return np.array(features)
    
    def train(self, data: pd.DataFrame, labels: np.ndarray):
        """Train the model"""
        X = self.preprocess_data(data)
        X_scaled = self.scaler.fit_transform(X)
        
        self.model.fit(X_scaled, labels)
        self.is_trained = True
        logger.info("Cyclone model trained successfully")
    
    def predict(self, data: pd.DataFrame) -> Dict:
        """Make prediction"""
        if not self.is_trained:
            # Return simulated prediction for demo
            return {
                "probability": 0.65,
                "risk_level": "HIGH",
                "confidence": 0.82,
                "timestamp": datetime.now().isoformat(),
                "intensity": "CATEGORY_2",
                "wind_speed": 85.0
            }
        
        X = self.preprocess_data(data)
        X_scaled = self.scaler.transform(X)
        
        probability = self.model.predict_proba(X_scaled)[0][1]
        
        # Determine risk level
        if probability > 0.7:
            risk_level = "HIGH"
        elif probability > 0.4:
            risk_level = "MEDIUM"
        else:
            risk_level = "LOW"
        
        # Determine intensity
        wind_speed = data.iloc[0].get('wind_speed', 0)
        if wind_speed > 150:
            intensity = "CATEGORY_5"
        elif wind_speed > 130:
            intensity = "CATEGORY_4"
        elif wind_speed > 110:
            intensity = "CATEGORY_3"
        elif wind_speed > 95:
            intensity = "CATEGORY_2"
        elif wind_speed > 74:
            intensity = "CATEGORY_1"
        else:
            intensity = "TROPICAL_STORM"
        
        return {
            "probability": float(probability),
            "risk_level": risk_level,
            "confidence": 0.82,
            "timestamp": datetime.now().isoformat(),
            "intensity": intensity,
            "wind_speed": float(wind_speed)
        }

# Model factory for easy access
class SimpleModelFactory:
    """Factory for creating simple AI models"""
    
    @staticmethod
    def create_model(disaster_type: str):
        """Create a model for the specified disaster type"""
        if disaster_type == "flood":
            return SimpleFloodModel()
        elif disaster_type == "drought":
            return SimpleDroughtModel()
        elif disaster_type == "cyclone":
            return SimpleCycloneModel()
        else:
            raise ValueError(f"Unknown disaster type: {disaster_type}")
    
    @staticmethod
    def get_all_models():
        """Get all available models"""
        return {
            "flood": SimpleFloodModel(),
            "drought": SimpleDroughtModel(),
            "cyclone": SimpleCycloneModel()
        } 