"""
Database Models for AI Climate Resilience System
PostgreSQL with advanced features for geospatial data, JSON storage, and ML model tracking
"""

import asyncio
import asyncpg
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import os
from dataclasses import dataclass, asdict

logger = logging.getLogger(__name__)

@dataclass
class DatabaseConfig:
    """Database configuration"""
    host: str = os.getenv("DB_HOST", "localhost")
    port: int = int(os.getenv("DB_PORT", "5432"))
    database: str = os.getenv("DB_NAME", "climate_resilience")
    user: str = os.getenv("DB_USER", "postgres")
    password: str = os.getenv("DB_PASSWORD", "password")
    min_size: int = 5
    max_size: int = 20

class DatabaseManager:
    """
    Advanced PostgreSQL database manager with geospatial and ML features
    """
    
    def __init__(self, config: DatabaseConfig = None):
        self.config = config or DatabaseConfig()
        self.pool = None
        self.is_initialized = False
    
    async def initialize(self):
        """Initialize database connection pool and create tables"""
        try:
            # Create connection pool
            self.pool = await asyncpg.create_pool(
                host=self.config.host,
                port=self.config.port,
                database=self.config.database,
                user=self.config.user,
                password=self.config.password,
                min_size=self.config.min_size,
                max_size=self.config.max_size
            )
            
            # Create tables
            await self.create_tables()
            
            # Create indexes for performance
            await self.create_indexes()
            
            # Initialize with sample data
            await self.initialize_sample_data()
            
            self.is_initialized = True
            logger.info("Database initialized successfully")
            
        except Exception as e:
            logger.error(f"Database initialization failed: {e}")
            raise
    
    async def create_tables(self):
        """Create all database tables with advanced features"""
        async with self.pool.acquire() as conn:
            # Enable PostGIS extension for geospatial data
            await conn.execute("""
                CREATE EXTENSION IF NOT EXISTS postgis;
                CREATE EXTENSION IF NOT EXISTS postgis_topology;
            """)
            
            # Users table
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id SERIAL PRIMARY KEY,
                    user_id VARCHAR(50) UNIQUE NOT NULL,
                    email VARCHAR(255) UNIQUE,
                    phone VARCHAR(20),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    preferences JSONB DEFAULT '{}',
                    location GEOMETRY(POINT, 4326),
                    alert_settings JSONB DEFAULT '{}'
                );
            """)
            
            # Environmental data table with geospatial support
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS environmental_data (
                    id SERIAL PRIMARY KEY,
                    timestamp TIMESTAMP NOT NULL,
                    location GEOMETRY(POINT, 4326) NOT NULL,
                    data_type VARCHAR(50) NOT NULL,
                    source VARCHAR(100) NOT NULL,
                    weather_data JSONB,
                    satellite_data JSONB,
                    sensor_data JSONB,
                    atmospheric_data JSONB,
                    ocean_data JSONB,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_location_timestamp (location, timestamp),
                    INDEX idx_data_type_timestamp (data_type, timestamp)
                );
            """)
            
            # Predictions table with ML model tracking
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS predictions (
                    id SERIAL PRIMARY KEY,
                    disaster_type VARCHAR(50) NOT NULL,
                    location GEOMETRY(POINT, 4326) NOT NULL,
                    timestamp TIMESTAMP NOT NULL,
                    probability DECIMAL(5,4) NOT NULL,
                    risk_level VARCHAR(20) NOT NULL,
                    confidence DECIMAL(5,4) NOT NULL,
                    model_version VARCHAR(50),
                    model_metadata JSONB,
                    input_features JSONB,
                    prediction_horizon_hours INTEGER DEFAULT 24,
                    actual_outcome BOOLEAN,
                    accuracy_score DECIMAL(5,4),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_disaster_location_timestamp (disaster_type, location, timestamp),
                    INDEX idx_probability_timestamp (probability, timestamp)
                );
            """)
            
            # Alerts table
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS alerts (
                    id SERIAL PRIMARY KEY,
                    alert_id VARCHAR(50) UNIQUE NOT NULL,
                    user_id VARCHAR(50) NOT NULL,
                    disaster_type VARCHAR(50) NOT NULL,
                    location GEOMETRY(POINT, 4326) NOT NULL,
                    risk_level VARCHAR(20) NOT NULL,
                    probability DECIMAL(5,4) NOT NULL,
                    message TEXT NOT NULL,
                    alert_types JSONB NOT NULL,
                    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    delivered_at TIMESTAMP,
                    status VARCHAR(20) DEFAULT 'pending',
                    delivery_status JSONB DEFAULT '{}',
                    INDEX idx_user_timestamp (user_id, sent_at),
                    INDEX idx_disaster_timestamp (disaster_type, sent_at)
                );
            """)
            
            # Model performance tracking
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS model_performance (
                    id SERIAL PRIMARY KEY,
                    model_name VARCHAR(100) NOT NULL,
                    model_version VARCHAR(50) NOT NULL,
                    disaster_type VARCHAR(50) NOT NULL,
                    timestamp TIMESTAMP NOT NULL,
                    accuracy DECIMAL(5,4),
                    precision DECIMAL(5,4),
                    recall DECIMAL(5,4),
                    f1_score DECIMAL(5,4),
                    roc_auc DECIMAL(5,4),
                    mse DECIMAL(10,6),
                    mae DECIMAL(10,6),
                    training_metrics JSONB,
                    validation_metrics JSONB,
                    test_metrics JSONB,
                    model_parameters JSONB,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_model_disaster_timestamp (model_name, disaster_type, timestamp)
                );
            """)
            
            # Data quality monitoring
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS data_quality (
                    id SERIAL PRIMARY KEY,
                    data_source VARCHAR(100) NOT NULL,
                    data_type VARCHAR(50) NOT NULL,
                    timestamp TIMESTAMP NOT NULL,
                    completeness_score DECIMAL(5,4),
                    accuracy_score DECIMAL(5,4),
                    consistency_score DECIMAL(5,4),
                    timeliness_score DECIMAL(5,4),
                    overall_score DECIMAL(5,4),
                    quality_metrics JSONB,
                    issues JSONB,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_source_type_timestamp (data_source, data_type, timestamp)
                );
            """)
            
            # System events and monitoring
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS system_events (
                    id SERIAL PRIMARY KEY,
                    event_type VARCHAR(100) NOT NULL,
                    severity VARCHAR(20) NOT NULL,
                    message TEXT NOT NULL,
                    metadata JSONB,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_event_type_timestamp (event_type, timestamp),
                    INDEX idx_severity_timestamp (severity, timestamp)
                );
            """)
            
            logger.info("Database tables created successfully")
    
    async def create_indexes(self):
        """Create performance indexes"""
        async with self.pool.acquire() as conn:
            # Geospatial indexes
            await conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_env_data_location_gist 
                ON environmental_data USING GIST (location);
                
                CREATE INDEX IF NOT EXISTS idx_predictions_location_gist 
                ON predictions USING GIST (location);
                
                CREATE INDEX IF NOT EXISTS idx_alerts_location_gist 
                ON alerts USING GIST (location);
            """)
            
            # JSONB indexes for efficient querying
            await conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_env_weather_data_gin 
                ON environmental_data USING GIN (weather_data);
                
                CREATE INDEX IF NOT EXISTS idx_env_satellite_data_gin 
                ON environmental_data USING GIN (satellite_data);
                
                CREATE INDEX IF NOT EXISTS idx_predictions_model_metadata_gin 
                ON predictions USING GIN (model_metadata);
            """)
            
            # Composite indexes for common queries
            await conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_predictions_disaster_prob 
                ON predictions (disaster_type, probability DESC);
                
                CREATE INDEX IF NOT EXISTS idx_alerts_user_status 
                ON alerts (user_id, status, sent_at DESC);
            """)
            
            logger.info("Database indexes created successfully")
    
    async def initialize_sample_data(self):
        """Initialize database with sample data for demo"""
        try:
            # Check if sample data already exists
            async with self.pool.acquire() as conn:
                count = await conn.fetchval("SELECT COUNT(*) FROM environmental_data")
                if count > 0:
                    logger.info("Sample data already exists, skipping initialization")
                    return
            
            # Insert sample environmental data
            sample_locations = [
                (40.7128, -74.0060, "New York"),
                (34.0522, -118.2437, "Los Angeles"),
                (41.8781, -87.6298, "Chicago"),
                (29.7604, -95.3698, "Houston"),
                (25.7617, -80.1918, "Miami")
            ]
            
            for lat, lon, city in sample_locations:
                await self.insert_sample_environmental_data(lat, lon, city)
            
            # Insert sample predictions
            await self.insert_sample_predictions()
            
            # Insert sample model performance data
            await self.insert_sample_model_performance()
            
            logger.info("Sample data initialized successfully")
            
        except Exception as e:
            logger.error(f"Sample data initialization failed: {e}")
    
    async def insert_sample_environmental_data(self, lat: float, lon: float, city: str):
        """Insert sample environmental data for a location"""
        async with self.pool.acquire() as conn:
            # Generate 30 days of sample data
            for i in range(30):
                timestamp = datetime.now() - timedelta(days=i)
                
                weather_data = {
                    "temperature": 20 + 10 * (i % 7) / 7,
                    "humidity": 60 + 20 * (i % 5) / 5,
                    "pressure": 1013 + 10 * (i % 3) / 3,
                    "wind_speed": 5 + 10 * (i % 4) / 4,
                    "precipitation": max(0, (i % 10 - 5) * 2)
                }
                
                satellite_data = {
                    "ndvi": 0.3 + 0.2 * (i % 6) / 6,
                    "evi": 0.2 + 0.15 * (i % 6) / 6,
                    "lst": 25 + 8 * (i % 7) / 7
                }
                
                await conn.execute("""
                    INSERT INTO environmental_data 
                    (timestamp, location, data_type, source, weather_data, satellite_data)
                    VALUES ($1, ST_SetSRID(ST_MakePoint($2, $3), 4326), $4, $5, $6, $7)
                """, timestamp, lon, lat, "combined", f"sample_{city}", 
                     json.dumps(weather_data), json.dumps(satellite_data))
    
    async def insert_sample_predictions(self):
        """Insert sample prediction data"""
        async with self.pool.acquire() as conn:
            locations = [
                (40.7128, -74.0060),
                (34.0522, -118.2437),
                (41.8781, -87.6298)
            ]
            
            disaster_types = ["flood", "drought", "cyclone"]
            
            for lat, lon in locations:
                for disaster_type in disaster_types:
                    for i in range(10):
                        timestamp = datetime.now() - timedelta(days=i)
                        probability = 0.3 + 0.4 * (i % 5) / 5
                        
                        await conn.execute("""
                            INSERT INTO predictions 
                            (disaster_type, location, timestamp, probability, risk_level, 
                             confidence, model_version, prediction_horizon_hours)
                            VALUES ($1, ST_SetSRID(ST_MakePoint($2, $3), 4326), $4, $5, $6, $7, $8, $9)
                        """, disaster_type, lon, lat, timestamp, probability,
                             "HIGH" if probability > 0.6 else "MEDIUM" if probability > 0.3 else "LOW",
                             0.8, "v1.0", 24)
    
    async def insert_sample_model_performance(self):
        """Insert sample model performance data"""
        async with self.pool.acquire() as conn:
            models = ["flood_lstm", "drought_ensemble", "cyclone_cnn"]
            disaster_types = ["flood", "drought", "cyclone"]
            
            for model, disaster_type in zip(models, disaster_types):
                await conn.execute("""
                    INSERT INTO model_performance 
                    (model_name, model_version, disaster_type, timestamp, accuracy, 
                     precision, recall, f1_score, roc_auc)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                """, model, "v1.0", disaster_type, datetime.now(),
                     0.92, 0.89, 0.91, 0.90, 0.94)
    
    async def store_prediction(self, disaster_type: str, location: Dict, 
                             prediction: Dict, horizon_hours: int = 24):
        """Store a new prediction in the database"""
        try:
            if self.pool is None:
                logger.warning("Database pool not available, skipping prediction storage")
                return
                
            async with self.pool.acquire() as conn:
                await conn.execute("""
                    INSERT INTO predictions 
                    (disaster_type, location, timestamp, probability, risk_level, 
                     confidence, model_metadata, prediction_horizon_hours)
                    VALUES ($1, ST_SetSRID(ST_MakePoint($2, $3), 4326), $4, $5, $6, $7, $8, $9)
                """, disaster_type, location["longitude"], location["latitude"], 
                     datetime.now(), prediction["probability"], prediction["risk_level"],
                     prediction["confidence"], json.dumps(prediction), horizon_hours)
                
                logger.info(f"Prediction stored for {disaster_type}")
                
        except Exception as e:
            logger.error(f"Failed to store prediction: {e}")
            # Don't raise the exception, just log it
    
    async def get_prediction_trends(self, disaster_type: str, days: int = 30) -> List[Dict]:
        """Get prediction trends over time"""
        try:
            if self.pool is None:
                logger.warning("Database pool not available, returning empty trends")
                return []
                
            async with self.pool.acquire() as conn:
                rows = await conn.fetch("""
                    SELECT 
                        DATE(timestamp) as date,
                        AVG(probability) as avg_probability,
                        COUNT(*) as prediction_count,
                        AVG(confidence) as avg_confidence
                    FROM predictions 
                    WHERE disaster_type = $1 
                    AND timestamp >= $2
                    GROUP BY DATE(timestamp)
                    ORDER BY date DESC
                    LIMIT $3
                """, disaster_type, datetime.now() - timedelta(days=days), days)
                
                return [dict(row) for row in rows]
                
        except Exception as e:
            logger.error(f"Failed to get prediction trends: {e}")
            return []
    
    async def get_location_predictions(self, lat: float, lon: float, 
                                     radius_km: float = 50.0) -> List[Dict]:
        """Get predictions for a location within radius"""
        try:
            if self.pool is None:
                logger.warning("Database pool not available, returning empty predictions")
                return []
                
            async with self.pool.acquire() as conn:
                rows = await conn.fetch("""
                    SELECT 
                        disaster_type,
                        probability,
                        risk_level,
                        confidence,
                        timestamp,
                        model_metadata
                    FROM predictions 
                    WHERE ST_DWithin(
                        location, 
                        ST_SetSRID(ST_MakePoint($1, $2), 4326), 
                        $3 * 1000
                    )
                    AND timestamp >= $4
                    ORDER BY timestamp DESC
                    LIMIT 100
                """, lon, lat, radius_km, datetime.now() - timedelta(days=7))
                
                return [dict(row) for row in rows]
                
        except Exception as e:
            logger.error(f"Failed to get location predictions: {e}")
            return []
    
    async def store_environmental_data(self, data: Dict):
        """Store environmental data"""
        try:
            if self.pool is None:
                logger.warning("Database pool not available, skipping environmental data storage")
                return
                
            async with self.pool.acquire() as conn:
                await conn.execute("""
                    INSERT INTO environmental_data 
                    (timestamp, location, data_type, source, weather_data, 
                     satellite_data, sensor_data, atmospheric_data, ocean_data)
                    VALUES ($1, ST_SetSRID(ST_MakePoint($2, $3), 4326), $4, $5, $6, $7, $8, $9, $10)
                """, data["timestamp"], data["longitude"], data["latitude"], 
                     data["data_type"], data["source"], 
                     json.dumps(data.get("weather_data", {})),
                     json.dumps(data.get("satellite_data", {})),
                     json.dumps(data.get("sensor_data", {})),
                     json.dumps(data.get("atmospheric_data", {})),
                     json.dumps(data.get("ocean_data", {})))
                
        except Exception as e:
            logger.error(f"Failed to store environmental data: {e}")
            # Don't raise the exception, just log it
    
    async def get_system_statistics(self) -> Dict:
        """Get system statistics for monitoring"""
        try:
            if self.pool is None:
                logger.warning("Database pool not available, returning empty statistics")
                return {}
                
            async with self.pool.acquire() as conn:
                stats = {}
                
                # Count predictions by disaster type
                pred_counts = await conn.fetch("""
                    SELECT disaster_type, COUNT(*) as count
                    FROM predictions 
                    WHERE timestamp >= $1
                    GROUP BY disaster_type
                """, datetime.now() - timedelta(days=30))
                
                stats["predictions_by_type"] = {row["disaster_type"]: row["count"] for row in pred_counts}
                
                # Average prediction accuracy
                avg_accuracy = await conn.fetchval("""
                    SELECT AVG(accuracy_score) 
                    FROM predictions 
                    WHERE accuracy_score IS NOT NULL
                    AND timestamp >= $1
                """, datetime.now() - timedelta(days=30))
                
                stats["avg_accuracy"] = float(avg_accuracy) if avg_accuracy else 0.0
                
                # Data quality scores
                quality_scores = await conn.fetch("""
                    SELECT data_source, AVG(overall_score) as avg_score
                    FROM data_quality 
                    WHERE timestamp >= $1
                    GROUP BY data_source
                """, datetime.now() - timedelta(days=7))
                
                stats["data_quality"] = {row["data_source"]: float(row["avg_score"]) for row in quality_scores}
                
                return stats
                
        except Exception as e:
            logger.error(f"Failed to get system statistics: {e}")
            return {}
    
    async def close(self):
        """Close database connection pool"""
        if self.pool:
            await self.pool.close()
            logger.info("Database connection pool closed") 