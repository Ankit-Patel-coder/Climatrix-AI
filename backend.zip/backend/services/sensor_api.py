"""
Sensor API Service
Integrates with IoT environmental sensors:
- Soil moisture sensors
- Water level sensors
- Weather stations
- Air quality sensors
"""

import aiohttp
import pandas as pd
import numpy as np
from typing import Dict, List, Optional
from datetime import datetime, timedelta
import logging
import os
import json

logger = logging.getLogger(__name__)

class SensorAPIService:
    """
    IoT sensor data collection service
    """
    
    def __init__(self):
        self.sensor_base_url = os.getenv("SENSOR_API_URL", "http://localhost:8080")
        self.session = None
    
    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
    
    async def collect_sensor_data(self) -> Dict:
        """
        Collect data from all IoT sensors
        """
        try:
            sensor_data = {}
            
            # Collect soil sensors data
            soil_data = await self.get_soil_sensors_data()
            sensor_data["soil"] = soil_data
            
            # Collect water sensors data
            water_data = await self.get_water_sensors_data()
            sensor_data["water"] = water_data
            
            # Collect weather station data
            weather_data = await self.get_weather_station_data()
            sensor_data["weather_station"] = weather_data
            
            # Collect air quality data
            air_quality_data = await self.get_air_quality_data()
            sensor_data["air_quality"] = air_quality_data
            
            return sensor_data
            
        except Exception as e:
            logger.error(f"Sensor data collection failed: {e}")
            return {}
    
    async def get_soil_sensors(self, latitude: float, longitude: float) -> Optional[pd.DataFrame]:
        """
        Get soil sensor data for a location
        """
        try:
            # For demo purposes, return simulated data
            return pd.DataFrame({
                'timestamp': [datetime.now()],
                'soil_moisture': [np.random.uniform(0.1, 0.5)],
                'soil_temperature': [np.random.uniform(15, 30)],
                'soil_ph': [np.random.uniform(6.0, 7.5)],
                'soil_conductivity': [np.random.uniform(100, 500)],
                'sensor_id': ['soil_sensor_001'],
                'latitude': [latitude],
                'longitude': [longitude]
            })
        except Exception as e:
            logger.error(f"Soil sensors data failed: {e}")
            return None
    
    async def get_water_sensors(self, latitude: float, longitude: float) -> Optional[pd.DataFrame]:
        """
        Get water sensor data for a location
        """
        try:
            # For demo purposes, return simulated data
            return pd.DataFrame({
                'timestamp': [datetime.now()],
                'water_level': [np.random.uniform(0.5, 3.0)],
                'water_temperature': [np.random.uniform(10, 25)],
                'water_ph': [np.random.uniform(6.5, 8.5)],
                'water_turbidity': [np.random.uniform(0, 10)],
                'flow_rate': [np.random.uniform(0, 100)],
                'sensor_id': ['water_sensor_001'],
                'latitude': [latitude],
                'longitude': [longitude]
            })
        except Exception as e:
            logger.error(f"Water sensors data failed: {e}")
            return None
    
    async def get_soil_sensors_data(self) -> Dict:
        """
        Get data from all soil sensors
        """
        try:
            # For demo purposes, return simulated data
            return {
                "sensors": [
                    {
                        "sensor_id": "soil_001",
                        "location": {"lat": 40.7128, "lon": -74.0060},
                        "soil_moisture": 0.35,
                        "soil_temperature": 22.5,
                        "soil_ph": 6.8,
                        "timestamp": datetime.now().isoformat()
                    },
                    {
                        "sensor_id": "soil_002",
                        "location": {"lat": 40.7150, "lon": -74.0080},
                        "soil_moisture": 0.28,
                        "soil_temperature": 21.8,
                        "soil_ph": 7.1,
                        "timestamp": datetime.now().isoformat()
                    }
                ]
            }
        except Exception as e:
            logger.error(f"Soil sensors data collection failed: {e}")
            return {}
    
    async def get_water_sensors_data(self) -> Dict:
        """
        Get data from all water sensors
        """
        try:
            # For demo purposes, return simulated data
            return {
                "sensors": [
                    {
                        "sensor_id": "water_001",
                        "location": {"lat": 40.7128, "lon": -74.0060},
                        "water_level": 1.8,
                        "water_temperature": 18.5,
                        "water_ph": 7.2,
                        "flow_rate": 45.2,
                        "timestamp": datetime.now().isoformat()
                    },
                    {
                        "sensor_id": "water_002",
                        "location": {"lat": 40.7150, "lon": -74.0080},
                        "water_level": 2.1,
                        "water_temperature": 19.2,
                        "water_ph": 7.0,
                        "flow_rate": 38.7,
                        "timestamp": datetime.now().isoformat()
                    }
                ]
            }
        except Exception as e:
            logger.error(f"Water sensors data collection failed: {e}")
            return {}
    
    async def get_weather_station_data(self) -> Dict:
        """
        Get data from weather stations
        """
        try:
            # For demo purposes, return simulated data
            return {
                "stations": [
                    {
                        "station_id": "weather_001",
                        "location": {"lat": 40.7128, "lon": -74.0060},
                        "temperature": 23.5,
                        "humidity": 65.0,
                        "pressure": 1013.25,
                        "wind_speed": 5.2,
                        "wind_direction": 180.0,
                        "precipitation": 0.0,
                        "timestamp": datetime.now().isoformat()
                    },
                    {
                        "station_id": "weather_002",
                        "location": {"lat": 40.7150, "lon": -74.0080},
                        "temperature": 24.1,
                        "humidity": 62.0,
                        "pressure": 1012.8,
                        "wind_speed": 4.8,
                        "wind_direction": 175.0,
                        "precipitation": 0.0,
                        "timestamp": datetime.now().isoformat()
                    }
                ]
            }
        except Exception as e:
            logger.error(f"Weather station data collection failed: {e}")
            return {}
    
    async def get_air_quality_data(self) -> Dict:
        """
        Get data from air quality sensors
        """
        try:
            # For demo purposes, return simulated data
            return {
                "sensors": [
                    {
                        "sensor_id": "aq_001",
                        "location": {"lat": 40.7128, "lon": -74.0060},
                        "pm25": 12.5,
                        "pm10": 25.3,
                        "co": 0.8,
                        "no2": 15.2,
                        "o3": 45.8,
                        "timestamp": datetime.now().isoformat()
                    },
                    {
                        "sensor_id": "aq_002",
                        "location": {"lat": 40.7150, "lon": -74.0080},
                        "pm25": 14.2,
                        "pm10": 28.7,
                        "co": 1.1,
                        "no2": 18.5,
                        "o3": 42.3,
                        "timestamp": datetime.now().isoformat()
                    }
                ]
            }
        except Exception as e:
            logger.error(f"Air quality data collection failed: {e}")
            return {}
    
    async def check_connection(self) -> bool:
        """
        Check if sensor APIs are accessible
        """
        try:
            # Test sensor API connection
            url = f"{self.sensor_base_url}/health"
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        return True
            
            return False
            
        except Exception as e:
            logger.error(f"Sensor API connection check failed: {e}")
            return False 