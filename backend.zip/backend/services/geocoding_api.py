"""
Geocoding service for converting city names to coordinates
Uses free geocoding APIs to convert location names to lat/lng
"""

import aiohttp
import logging
from typing import Dict, Optional, Tuple
import json

logger = logging.getLogger(__name__)

class GeocodingService:
    """Service for converting city names to coordinates"""
    
    def __init__(self):
        self.base_url = "https://nominatim.openstreetmap.org"
        self.session = None
    
    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create HTTP session"""
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession(
                headers={
                    'User-Agent': 'AI-Climate-Resilience-System/1.0'
                }
            )
        return self.session
    
    async def geocode_city(self, city_name: str, country_code: Optional[str] = None) -> Optional[Dict]:
        """
        Convert city name to coordinates using OpenStreetMap Nominatim
        
        Args:
            city_name: Name of the city (e.g., "New York", "Mumbai", "London")
            country_code: Optional country code (e.g., "US", "IN", "GB")
        
        Returns:
            Dict with coordinates and location info, or None if not found
        """
        try:
            session = await self._get_session()
            
            # Build query parameters
            params = {
                'q': city_name,
                'format': 'json',
                'limit': 1,
                'addressdetails': 1
            }
            
            if country_code:
                params['countrycodes'] = country_code
            
            # Make request to Nominatim
            async with session.get(f"{self.base_url}/search", params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if data and len(data) > 0:
                        location = data[0]
                        return {
                            'latitude': float(location['lat']),
                            'longitude': float(location['lon']),
                            'display_name': location['display_name'],
                            'city': location.get('address', {}).get('city') or 
                                   location.get('address', {}).get('town') or 
                                   location.get('address', {}).get('village') or 
                                   city_name,
                            'country': location.get('address', {}).get('country'),
                            'country_code': location.get('address', {}).get('country_code'),
                            'state': location.get('address', {}).get('state'),
                            'confidence': self._calculate_confidence(location)
                        }
                    else:
                        logger.warning(f"No results found for city: {city_name}")
                        return None
                else:
                    logger.error(f"Geocoding request failed with status {response.status}")
                    return None
                    
        except Exception as e:
            logger.error(f"Geocoding error for {city_name}: {e}")
            return None
    
    def _calculate_confidence(self, location: Dict) -> float:
        """Calculate confidence score for the geocoding result"""
        # Simple confidence calculation based on result type
        result_type = location.get('type', '')
        if result_type in ['city', 'town', 'village']:
            return 0.95
        elif result_type in ['state', 'country']:
            return 0.85
        else:
            return 0.75
    
    async def reverse_geocode(self, latitude: float, longitude: float) -> Optional[Dict]:
        """
        Convert coordinates back to location name
        
        Args:
            latitude: Latitude coordinate
            longitude: Longitude coordinate
        
        Returns:
            Dict with location info, or None if not found
        """
        try:
            session = await self._get_session()
            
            params = {
                'lat': latitude,
                'lon': longitude,
                'format': 'json',
                'addressdetails': 1
            }
            
            async with session.get(f"{self.base_url}/reverse", params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    if data:
                        address = data.get('address', {})
                        return {
                            'display_name': data.get('display_name'),
                            'city': address.get('city') or address.get('town') or address.get('village'),
                            'country': address.get('country'),
                            'state': address.get('state'),
                            'postcode': address.get('postcode')
                        }
                return None
                
        except Exception as e:
            logger.error(f"Reverse geocoding error: {e}")
            return None
    
    async def search_cities(self, query: str, limit: int = 5) -> list:
        """
        Search for cities matching a query
        
        Args:
            query: Search query
            limit: Maximum number of results
        
        Returns:
            List of matching cities
        """
        try:
            session = await self._get_session()
            
            params = {
                'q': query,
                'format': 'json',
                'limit': limit,
                'addressdetails': 1,
                'featuretype': 'city'
            }
            
            async with session.get(f"{self.base_url}/search", params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    results = []
                    
                    for item in data:
                        address = item.get('address', {})
                        results.append({
                            'display_name': item['display_name'],
                            'city': address.get('city') or address.get('town') or address.get('village'),
                            'country': address.get('country'),
                            'state': address.get('state'),
                            'latitude': float(item['lat']),
                            'longitude': float(item['lon'])
                        })
                    
                    return results
                else:
                    return []
                    
        except Exception as e:
            logger.error(f"City search error: {e}")
            return []
    
    async def close(self):
        """Close the HTTP session"""
        if self.session and not self.session.closed:
            await self.session.close()

# Global instance
geocoding_service = GeocodingService() 