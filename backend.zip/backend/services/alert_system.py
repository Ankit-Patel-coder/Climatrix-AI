"""
Alert System Service
Manages disaster alerts and notifications:
- SMS alerts
- Email notifications
- Push notifications
- Alert prioritization
- User preferences
"""

import asyncio
import aiohttp
import pandas as pd
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import logging
import os
import json
import uuid

logger = logging.getLogger(__name__)

class AlertSystem:
    """
    Disaster alert and notification system
    """
    
    def __init__(self):
        self.twilio_account_sid = os.getenv("TWILIO_ACCOUNT_SID", "")
        self.twilio_auth_token = os.getenv("TWILIO_AUTH_TOKEN", "")
        self.twilio_phone_number = os.getenv("TWILIO_PHONE_NUMBER", "")
        self.smtp_server = os.getenv("SMTP_SERVER", "")
        self.smtp_port = int(os.getenv("SMTP_PORT", "587"))
        self.smtp_username = os.getenv("SMTP_USERNAME", "")
        self.smtp_password = os.getenv("SMTP_PASSWORD", "")
        self.session = None
        
        # In-memory storage for demo (use database in production)
        self.active_alerts = {}
        self.user_subscriptions = {}
        self.alert_history = []
    
    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
    
    async def subscribe_user(self, user_id: str, location: Dict, alert_types: List[str], 
                           disaster_types: List[str]) -> str:
        """
        Subscribe a user to disaster alerts
        """
        try:
            subscription_id = str(uuid.uuid4())
            
            subscription = {
                "subscription_id": subscription_id,
                "user_id": user_id,
                "location": location,
                "alert_types": alert_types,
                "disaster_types": disaster_types,
                "created_at": datetime.now(),
                "active": True
            }
            
            self.user_subscriptions[subscription_id] = subscription
            
            logger.info(f"User {user_id} subscribed to alerts with ID {subscription_id}")
            return subscription_id
            
        except Exception as e:
            logger.error(f"User subscription failed: {e}")
            raise
    
    async def unsubscribe_user(self, subscription_id: str):
        """
        Unsubscribe a user from alerts
        """
        try:
            if subscription_id in self.user_subscriptions:
                self.user_subscriptions[subscription_id]["active"] = False
                logger.info(f"User unsubscribed from alerts: {subscription_id}")
            else:
                logger.warning(f"Subscription not found: {subscription_id}")
                
        except Exception as e:
            logger.error(f"User unsubscription failed: {e}")
            raise
    
    async def process_alerts(self):
        """
        Process and send alerts based on predictions
        """
        try:
            # Get active subscriptions
            active_subscriptions = [
                sub for sub in self.user_subscriptions.values() 
                if sub["active"]
            ]
            
            # Process each subscription
            for subscription in active_subscriptions:
                await self.check_and_send_alerts(subscription)
                
        except Exception as e:
            logger.error(f"Alert processing failed: {e}")
    
    async def check_and_send_alerts(self, subscription: Dict):
        """
        Check if alerts should be sent for a subscription
        """
        try:
            location = subscription["location"]
            disaster_types = subscription["disaster_types"]
            
            # Get latest predictions for the location
            predictions = await self.get_location_predictions(
                location["latitude"], 
                location["longitude"]
            )
            
            # Check each disaster type
            for disaster_type in disaster_types:
                if disaster_type in predictions:
                    prediction = predictions[disaster_type]
                    
                    # Check if alert threshold is met
                    if self.should_send_alert(prediction):
                        await self.send_alert(subscription, disaster_type, prediction)
                        
        except Exception as e:
            logger.error(f"Alert check failed: {e}")
    
    async def get_location_predictions(self, latitude: float, longitude: float) -> Dict:
        """
        Get latest predictions for a location
        """
        try:
            # In production, this would query the prediction database
            # For demo, return simulated predictions
            return {
                "flood": {
                    "probability": 0.75,
                    "risk_level": "HIGH",
                    "confidence": 0.85,
                    "timestamp": datetime.now().isoformat()
                },
                "drought": {
                    "probability": 0.25,
                    "risk_level": "LOW",
                    "confidence": 0.78,
                    "timestamp": datetime.now().isoformat()
                },
                "cyclone": {
                    "probability": 0.15,
                    "risk_level": "LOW",
                    "confidence": 0.72,
                    "timestamp": datetime.now().isoformat()
                }
            }
        except Exception as e:
            logger.error(f"Failed to get location predictions: {e}")
            return {}
    
    def should_send_alert(self, prediction: Dict) -> bool:
        """
        Determine if an alert should be sent based on prediction
        """
        try:
            probability = prediction.get("probability", 0)
            risk_level = prediction.get("risk_level", "LOW")
            
            # Alert thresholds
            if risk_level in ["HIGH", "CRITICAL"] and probability > 0.6:
                return True
            elif risk_level == "MEDIUM" and probability > 0.8:
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Alert threshold check failed: {e}")
            return False
    
    async def send_alert(self, subscription: Dict, disaster_type: str, prediction: Dict):
        """
        Send alert to user
        """
        try:
            alert_id = str(uuid.uuid4())
            
            # Create alert message
            message = self.create_alert_message(disaster_type, prediction)
            
            # Send through different channels
            alert_types = subscription["alert_types"]
            
            if "sms" in alert_types:
                await self.send_sms_alert(subscription, message)
            
            if "email" in alert_types:
                await self.send_email_alert(subscription, message)
            
            if "push" in alert_types:
                await self.send_push_alert(subscription, message)
            
            # Store alert
            alert_record = {
                "alert_id": alert_id,
                "user_id": subscription["user_id"],
                "disaster_type": disaster_type,
                "message": message,
                "prediction": prediction,
                "sent_at": datetime.now(),
                "alert_types": alert_types
            }
            
            self.alert_history.append(alert_record)
            self.active_alerts[alert_id] = alert_record
            
            logger.info(f"Alert sent: {alert_id} for user {subscription['user_id']}")
            
        except Exception as e:
            logger.error(f"Alert sending failed: {e}")
    
    def create_alert_message(self, disaster_type: str, prediction: Dict) -> str:
        """
        Create alert message based on disaster type and prediction
        """
        try:
            probability = prediction.get("probability", 0)
            risk_level = prediction.get("risk_level", "LOW")
            confidence = prediction.get("confidence", 0)
            
            if disaster_type == "flood":
                return f"🚨 FLOOD ALERT 🚨\nRisk Level: {risk_level}\nProbability: {probability:.1%}\nConfidence: {confidence:.1%}\nTake immediate action to protect yourself and property."
            
            elif disaster_type == "drought":
                return f"🌵 DROUGHT ALERT 🌵\nRisk Level: {risk_level}\nProbability: {probability:.1%}\nConfidence: {confidence:.1%}\nImplement water conservation measures."
            
            elif disaster_type == "cyclone":
                return f"🌀 CYCLONE ALERT 🌀\nRisk Level: {risk_level}\nProbability: {probability:.1%}\nConfidence: {confidence:.1%}\nPrepare for evacuation if necessary."
            
            else:
                return f"⚠️ DISASTER ALERT ⚠️\nType: {disaster_type}\nRisk Level: {risk_level}\nProbability: {probability:.1%}\nConfidence: {confidence:.1%}"
                
        except Exception as e:
            logger.error(f"Alert message creation failed: {e}")
            return "Disaster alert - please check local authorities for details."
    
    async def send_sms_alert(self, subscription: Dict, message: str):
        """
        Send SMS alert using Twilio
        """
        try:
            if not all([self.twilio_account_sid, self.twilio_auth_token, self.twilio_phone_number]):
                logger.warning("Twilio credentials not configured, skipping SMS")
                return
            
            # In production, get user's phone number from database
            user_phone = "+1234567890"  # Demo phone number
            
            url = f"https://api.twilio.com/2010-04-01/Accounts/{self.twilio_account_sid}/Messages.json"
            
            data = {
                "From": self.twilio_phone_number,
                "To": user_phone,
                "Body": message
            }
            
            auth = aiohttp.BasicAuth(self.twilio_account_sid, self.twilio_auth_token)
            
            async with self.session.post(url, data=data, auth=auth) as response:
                if response.status == 201:
                    logger.info(f"SMS alert sent to {user_phone}")
                else:
                    logger.error(f"SMS alert failed: {response.status}")
                    
        except Exception as e:
            logger.error(f"SMS alert sending failed: {e}")
    
    async def send_email_alert(self, subscription: Dict, message: str):
        """
        Send email alert
        """
        try:
            if not all([self.smtp_server, self.smtp_username, self.smtp_password]):
                logger.warning("SMTP credentials not configured, skipping email")
                return
            
            # In production, get user's email from database
            user_email = "user@example.com"  # Demo email
            
            # In production, use proper email library like aiosmtplib
            logger.info(f"Email alert would be sent to {user_email}: {message[:100]}...")
            
        except Exception as e:
            logger.error(f"Email alert sending failed: {e}")
    
    async def send_push_alert(self, subscription: Dict, message: str):
        """
        Send push notification
        """
        try:
            # In production, integrate with push notification services
            # like Firebase Cloud Messaging or Apple Push Notification Service
            user_id = subscription["user_id"]
            logger.info(f"Push notification would be sent to user {user_id}: {message[:100]}...")
            
        except Exception as e:
            logger.error(f"Push alert sending failed: {e}")
    
    async def get_active_alerts_count(self) -> int:
        """
        Get count of active alerts
        """
        try:
            # Count alerts from last 24 hours
            cutoff_time = datetime.now() - timedelta(hours=24)
            active_count = len([
                alert for alert in self.alert_history
                if alert["sent_at"] > cutoff_time
            ])
            
            return active_count
            
        except Exception as e:
            logger.error(f"Failed to get active alerts count: {e}")
            return 0
    
    async def get_user_alerts(self, user_id: str, limit: int = 50) -> List[Dict]:
        """
        Get alert history for a user
        """
        try:
            user_alerts = [
                alert for alert in self.alert_history
                if alert["user_id"] == user_id
            ]
            
            # Sort by timestamp (newest first)
            user_alerts.sort(key=lambda x: x["sent_at"], reverse=True)
            
            # Limit results
            return user_alerts[:limit]
            
        except Exception as e:
            logger.error(f"Failed to get user alerts: {e}")
            return []
    
    async def get_alert_statistics(self) -> Dict:
        """
        Get alert system statistics
        """
        try:
            total_alerts = len(self.alert_history)
            active_subscriptions = len([
                sub for sub in self.user_subscriptions.values()
                if sub["active"]
            ])
            
            # Alert counts by disaster type
            disaster_counts = {}
            for alert in self.alert_history:
                disaster_type = alert["disaster_type"]
                disaster_counts[disaster_type] = disaster_counts.get(disaster_type, 0) + 1
            
            # Alert counts by risk level
            risk_counts = {}
            for alert in self.alert_history:
                risk_level = alert["prediction"].get("risk_level", "UNKNOWN")
                risk_counts[risk_level] = risk_counts.get(risk_level, 0) + 1
            
            return {
                "total_alerts": total_alerts,
                "active_subscriptions": active_subscriptions,
                "disaster_type_counts": disaster_counts,
                "risk_level_counts": risk_counts,
                "last_24h_alerts": await self.get_active_alerts_count()
            }
            
        except Exception as e:
            logger.error(f"Failed to get alert statistics: {e}")
            return {}
    
    async def update_alert_preferences(self, subscription_id: str, 
                                     alert_types: List[str], disaster_types: List[str]):
        """
        Update user's alert preferences
        """
        try:
            if subscription_id in self.user_subscriptions:
                subscription = self.user_subscriptions[subscription_id]
                subscription["alert_types"] = alert_types
                subscription["disaster_types"] = disaster_types
                subscription["updated_at"] = datetime.now()
                
                logger.info(f"Updated alert preferences for subscription {subscription_id}")
            else:
                logger.warning(f"Subscription not found: {subscription_id}")
                
        except Exception as e:
            logger.error(f"Failed to update alert preferences: {e}")
            raise 