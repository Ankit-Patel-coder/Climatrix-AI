"""
Satellite API Service
Integrates with satellite data providers:
- NASA Landsat
- ESA Sentinel-2
- MODIS
- GOES
"""

import aiohttp
import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import logging
import os
import json

logger = logging.getLogger(__name__)

class SatelliteAPIService:
    """
    Satellite data collection service
    """
    
    def __init__(self):
        self.nasa_api_key = os.getenv("NASA_API_KEY", "")
        self.esa_api_key = os.getenv("ESA_API_KEY", "")
        self.base_urls = {
            "nasa": "https://api.nasa.gov",
            "esa": "https://scihub.copernicus.eu",
            "usgs": "https://landsatlook.usgs.gov"
        }
        self.session = None
    
    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
    
    async def collect_satellite_data(self) -> Dict:
        """
        Collect satellite data from all sources
        """
        try:
            satellite_data = {}
            
            # Collect Landsat data
            landsat_data = await self.get_landsat_data()
            satellite_data["landsat"] = landsat_data
            
            # Collect Sentinel-2 data
            sentinel_data = await self.get_sentinel_data()
            satellite_data["sentinel"] = sentinel_data
            
            # Collect MODIS data
            modis_data = await self.get_modis_data()
            satellite_data["modis"] = modis_data
            
            return satellite_data
            
        except Exception as e:
            logger.error(f"Satellite data collection failed: {e}")
            return {}
    
    async def get_location_satellite_data(self, latitude: float, longitude: float, 
                                        radius_km: float = 50.0) -> pd.DataFrame:
        """
        Get satellite data for a specific location
        """
        try:
            satellite_data = []
            
            # Get Landsat data
            landsat_data = await self.get_landsat_location_data(latitude, longitude)
            if landsat_data is not None and not landsat_data.empty:
                satellite_data.append(landsat_data)
            
            # Get Sentinel-2 data
            sentinel_data = await self.get_sentinel_location_data(latitude, longitude)
            if sentinel_data is not None and not sentinel_data.empty:
                satellite_data.append(sentinel_data)
            
            # Get MODIS data
            modis_data = await self.get_modis_location_data(latitude, longitude)
            if modis_data is not None and not modis_data.empty:
                satellite_data.append(modis_data)
            
            if satellite_data:
                df = pd.concat(satellite_data, ignore_index=True)
                df = df.sort_values('timestamp')
                return df
            else:
                # Return default satellite data structure
                return pd.DataFrame({
                    'timestamp': [datetime.now()],
                    'ndvi': [0.3],
                    'evi': [0.2],
                    'ndwi': [-0.1],
                    'lst': [25.0],
                    'red': [0.1],
                    'nir': [0.2],
                    'green': [0.15],
                    'blue': [0.05],
                    'swir': [0.1],
                    'source': ['simulated']
                })
                
        except Exception as e:
            logger.error(f"Location satellite data collection failed: {e}")
            return pd.DataFrame()
    
    async def get_spatial_images(self, latitude: float, longitude: float, 
                               radius_km: float) -> List[np.ndarray]:
        """
        Get spatial satellite images for the location
        """
        try:
            spatial_images = []
            
            # Get Landsat images
            landsat_images = await self.get_landsat_images(latitude, longitude, radius_km)
            if landsat_images and len(landsat_images) > 0:
                spatial_images.extend(landsat_images)
            
            # Get Sentinel-2 images
            sentinel_images = await self.get_sentinel_images(latitude, longitude, radius_km)
            if sentinel_images and len(sentinel_images) > 0:
                spatial_images.extend(sentinel_images)
            
            return spatial_images
            
        except Exception as e:
            logger.error(f"Spatial images collection failed: {e}")
            return []
    
    async def get_ocean_data(self, latitude: float, longitude: float) -> Optional[pd.DataFrame]:
        """
        Get ocean data from satellite sources
        """
        try:
            ocean_data = []
            
            # Get sea surface temperature
            sst_data = await self.get_sst_data(latitude, longitude)
            if sst_data is not None and not sst_data.empty:
                ocean_data.append(sst_data)
            
            # Get sea surface height
            ssh_data = await self.get_ssh_data(latitude, longitude)
            if ssh_data is not None and not ssh_data.empty:
                ocean_data.append(ssh_data)
            
            # Get ocean color data
            ocean_color = await self.get_ocean_color_data(latitude, longitude)
            if ocean_color is not None and not ocean_color.empty:
                ocean_data.append(ocean_color)
            
            if ocean_data:
                df = pd.concat(ocean_data, ignore_index=True)
                return df
            else:
                return pd.DataFrame()
                
        except Exception as e:
            logger.error(f"Ocean data collection failed: {e}")
            return pd.DataFrame()
    
    async def get_landsat_data(self) -> Dict:
        """
        Get Landsat satellite data
        """
        try:
            # For demo purposes, return simulated data
            return {
                "collection": "landsat-8",
                "timestamp": datetime.now().isoformat(),
                "bands": {
                    "red": 0.1,
                    "green": 0.15,
                    "blue": 0.05,
                    "nir": 0.2,
                    "swir1": 0.1,
                    "swir2": 0.08
                },
                "indices": {
                    "ndvi": 0.3,
                    "evi": 0.2,
                    "ndwi": -0.1
                }
            }
        except Exception as e:
            logger.error(f"Landsat data collection failed: {e}")
            return {}
    
    async def get_sentinel_data(self) -> Dict:
        """
        Get Sentinel-2 satellite data
        """
        try:
            # For demo purposes, return simulated data
            return {
                "collection": "sentinel-2",
                "timestamp": datetime.now().isoformat(),
                "bands": {
                    "red": 0.12,
                    "green": 0.18,
                    "blue": 0.06,
                    "nir": 0.25,
                    "swir1": 0.12,
                    "swir2": 0.09
                },
                "indices": {
                    "ndvi": 0.35,
                    "evi": 0.25,
                    "ndwi": -0.08
                }
            }
        except Exception as e:
            logger.error(f"Sentinel data collection failed: {e}")
            return {}
    
    async def get_modis_data(self) -> Dict:
        """
        Get MODIS satellite data
        """
        try:
            # For demo purposes, return simulated data
            return {
                "collection": "modis",
                "timestamp": datetime.now().isoformat(),
                "products": {
                    "ndvi": 0.32,
                    "lst": 25.5,
                    "evi": 0.22,
                    "lai": 2.1
                }
            }
        except Exception as e:
            logger.error(f"MODIS data collection failed: {e}")
            return {}
    
    async def get_landsat_location_data(self, latitude: float, longitude: float) -> Optional[pd.DataFrame]:
        """
        Get Landsat data for specific location
        """
        try:
            # For demo purposes, return simulated data
            return pd.DataFrame({
                'timestamp': [datetime.now()],
                'red': [0.1],
                'green': [0.15],
                'blue': [0.05],
                'nir': [0.2],
                'swir1': [0.1],
                'swir2': [0.08],
                'ndvi': [0.3],
                'evi': [0.2],
                'ndwi': [-0.1],
                'lst': [25.0],
                'source': ['landsat-8']
            })
        except Exception as e:
            logger.error(f"Landsat location data failed: {e}")
            return None
    
    async def get_sentinel_location_data(self, latitude: float, longitude: float) -> Optional[pd.DataFrame]:
        """
        Get Sentinel-2 data for specific location
        """
        try:
            # For demo purposes, return simulated data
            return pd.DataFrame({
                'timestamp': [datetime.now()],
                'red': [0.12],
                'green': [0.18],
                'blue': [0.06],
                'nir': [0.25],
                'swir1': [0.12],
                'swir2': [0.09],
                'ndvi': [0.35],
                'evi': [0.25],
                'ndwi': [-0.08],
                'lst': [24.5],
                'source': ['sentinel-2']
            })
        except Exception as e:
            logger.error(f"Sentinel location data failed: {e}")
            return None
    
    async def get_modis_location_data(self, latitude: float, longitude: float) -> Optional[pd.DataFrame]:
        """
        Get MODIS data for specific location
        """
        try:
            # For demo purposes, return simulated data
            return pd.DataFrame({
                'timestamp': [datetime.now()],
                'ndvi': [0.32],
                'evi': [0.22],
                'lst': [25.5],
                'lai': [2.1],
                'source': ['modis']
            })
        except Exception as e:
            logger.error(f"MODIS location data failed: {e}")
            return None
    
    async def get_landsat_images(self, latitude: float, longitude: float, 
                               radius_km: float) -> List[np.ndarray]:
        """
        Get Landsat satellite images
        """
        try:
            # For demo purposes, return simulated images
            images = []
            for i in range(5):  # Last 5 time steps
                # Create simulated Landsat image (6 bands)
                image = np.random.rand(64, 64, 6) * 0.3  # Normalized reflectance values
                images.append(image)
            
            return images
            
        except Exception as e:
            logger.error(f"Landsat images collection failed: {e}")
            return []
    
    async def get_sentinel_images(self, latitude: float, longitude: float, 
                                radius_km: float) -> List[np.ndarray]:
        """
        Get Sentinel-2 satellite images
        """
        try:
            # For demo purposes, return simulated images
            images = []
            for i in range(5):  # Last 5 time steps
                # Create simulated Sentinel-2 image (10 bands)
                image = np.random.rand(64, 64, 10) * 0.3  # Normalized reflectance values
                images.append(image)
            
            return images
            
        except Exception as e:
            logger.error(f"Sentinel images collection failed: {e}")
            return []
    
    async def get_sst_data(self, latitude: float, longitude: float) -> Optional[pd.DataFrame]:
        """
        Get sea surface temperature data
        """
        try:
            # For demo purposes, return simulated data
            return pd.DataFrame({
                'timestamp': [datetime.now()],
                'sst': [np.random.uniform(15, 30)],
                'source': ['modis_sst']
            })
        except Exception as e:
            logger.error(f"SST data collection failed: {e}")
            return None
    
    async def get_ssh_data(self, latitude: float, longitude: float) -> Optional[pd.DataFrame]:
        """
        Get sea surface height data
        """
        try:
            # For demo purposes, return simulated data
            return pd.DataFrame({
                'timestamp': [datetime.now()],
                'sea_surface_height': [np.random.uniform(-0.5, 0.5)],
                'source': ['jason_satellite']
            })
        except Exception as e:
            logger.error(f"SSH data collection failed: {e}")
            return None
    
    async def get_ocean_color_data(self, latitude: float, longitude: float) -> Optional[pd.DataFrame]:
        """
        Get ocean color data
        """
        try:
            # For demo purposes, return simulated data
            return pd.DataFrame({
                'timestamp': [datetime.now()],
                'chlorophyll': [np.random.uniform(0.1, 2.0)],
                'turbidity': [np.random.uniform(0.5, 5.0)],
                'source': ['modis_ocean']
            })
        except Exception as e:
            logger.error(f"Ocean color data collection failed: {e}")
            return None
    
    async def get_satellite_data(self, latitude: float, longitude: float) -> Dict:
        """
        Get satellite data for a location (wrapper method for API compatibility)
        """
        try:
            # Get location satellite data
            satellite_df = await self.get_location_satellite_data(latitude, longitude)
            
            # Get spatial images
            spatial_images = await self.get_spatial_images(latitude, longitude, 50.0)
            
            # Get ocean data
            ocean_data = await self.get_ocean_data(latitude, longitude)
            
            return {
                "satellite_data": satellite_df.to_dict('records') if not satellite_df.empty else [],
                "spatial_images": len(spatial_images),
                "ocean_data": ocean_data.to_dict('records') if ocean_data is not None and not ocean_data.empty else [],
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Satellite data retrieval failed: {e}")
            return {
                "satellite_data": [],
                "spatial_images": 0,
                "ocean_data": [],
                "timestamp": datetime.now().isoformat(),
                "error": str(e)
            }
    
    async def check_connection(self) -> bool:
        """
        Check if satellite APIs are accessible
        """
        try:
            # Test NASA API connection
            if self.nasa_api_key:
                url = f"{self.base_urls['nasa']}/planetary/apod"
                params = {'api_key': self.nasa_api_key}
                
                async with aiohttp.ClientSession() as session:
                    async with session.get(url, params=params) as response:
                        if response.status == 200:
                            return True
            
            # Test USGS Landsat connection
            url = f"{self.base_urls['usgs']}/api/v1/collections"
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        return True
            
            return False
            
        except Exception as e:
            logger.error(f"Satellite API connection check failed: {e}")
            return False 