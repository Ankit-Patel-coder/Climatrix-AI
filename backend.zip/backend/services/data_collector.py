"""
Data Collector Service
Integrates multiple data sources for comprehensive environmental monitoring:
- Weather APIs (OpenWeatherMap, NOAA)
- Satellite imagery (Landsat, Sentinel-2)
- Environmental sensors (IoT devices)
- Historical climate data
"""

import asyncio
import aiohttp
import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import logging
import json
import os
from dataclasses import dataclass

from .weather_api import WeatherAPIService
from .satellite_api import SatelliteAPIService
from .sensor_api import SensorAPIService

logger = logging.getLogger(__name__)

@dataclass
class LocationData:
    """Data structure for location-specific environmental data"""
    latitude: float
    longitude: float
    timestamp: datetime
    weather_data: pd.DataFrame
    satellite_data: pd.DataFrame
    soil_data: pd.DataFrame
    water_data: pd.DataFrame
    atmospheric_data: pd.DataFrame
    ocean_data: pd.DataFrame
    spatial_data: List[np.ndarray]

class DataCollector:
    """
    Comprehensive data collection service for environmental monitoring
    """
    
    def __init__(self):
        self.weather_service = WeatherAPIService()
        self.satellite_service = SatelliteAPIService()
        self.sensor_service = SensorAPIService()
        self.session = None
        
    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
    
    async def collect_all_data(self) -> Dict:
        """
        Collect data from all sources for monitoring
        """
        try:
            logger.info("Starting comprehensive data collection...")
            
            # Collect weather data
            weather_data = await self.weather_service.collect_weather_data()
            
            # Collect satellite data
            satellite_data = await self.satellite_service.collect_satellite_data()
            
            # Collect sensor data
            sensor_data = await self.sensor_service.collect_sensor_data()
            
            # Process and combine data
            processed_data = await self.process_combined_data(
                weather_data, satellite_data, sensor_data
            )
            
            # Store data
            await self.store_collected_data(processed_data)
            
            logger.info("Data collection completed successfully")
            return processed_data
            
        except Exception as e:
            logger.error(f"Data collection failed: {e}")
            raise
    
    async def collect_location_data(self, latitude: float, longitude: float, 
                                  radius_km: float = 50.0) -> LocationData:
        """
        Collect comprehensive data for a specific location
        """
        try:
            logger.info(f"Collecting data for location: {latitude}, {longitude}")
            
            # Collect weather data
            weather_data = await self.weather_service.get_location_weather(
                latitude, longitude, radius_km
            )
            
            # Collect satellite data
            satellite_data = await self.satellite_service.get_location_satellite_data(
                latitude, longitude, radius_km
            )
            
            # Collect soil and water data
            soil_data = await self.collect_soil_data(latitude, longitude)
            water_data = await self.collect_water_data(latitude, longitude)
            
            # Collect atmospheric data
            atmospheric_data = await self.collect_atmospheric_data(latitude, longitude)
            
            # Collect ocean data (if applicable)
            ocean_data = await self.collect_ocean_data(latitude, longitude)
            
            # Collect spatial data
            spatial_data = await self.collect_spatial_data(latitude, longitude, radius_km)
            
            return LocationData(
                latitude=latitude,
                longitude=longitude,
                timestamp=datetime.now(),
                weather_data=weather_data,
                satellite_data=satellite_data,
                soil_data=soil_data,
                water_data=water_data,
                atmospheric_data=atmospheric_data,
                ocean_data=ocean_data,
                spatial_data=spatial_data
            )
            
        except Exception as e:
            logger.error(f"Location data collection failed: {e}")
            raise
    
    async def collect_soil_data(self, latitude: float, longitude: float) -> pd.DataFrame:
        """
        Collect soil moisture and temperature data
        """
        try:
            # Get soil data from multiple sources
            soil_data = []
            
            # NASA SMAP soil moisture data
            smap_data = await self.get_smap_soil_moisture(latitude, longitude)
            if smap_data is not None and not smap_data.empty:
                soil_data.append(smap_data)
            
            # Local sensor data
            sensor_soil = await self.sensor_service.get_soil_sensors(latitude, longitude)
            if sensor_soil is not None and not sensor_soil.empty:
                soil_data.append(sensor_soil)
            
            # Combine and process soil data
            if soil_data:
                combined_soil = pd.concat(soil_data, ignore_index=True)
                return self.process_soil_data(combined_soil)
            else:
                # Return default soil data structure
                return pd.DataFrame({
                    'timestamp': [datetime.now()],
                    'soil_moisture': [0.3],  # Default value
                    'soil_temperature': [20.0],  # Default value
                    'soil_type': ['loam'],
                    'depth': [10]
                })
                
        except Exception as e:
            logger.error(f"Soil data collection failed: {e}")
            return pd.DataFrame()
    
    async def collect_water_data(self, latitude: float, longitude: float) -> pd.DataFrame:
        """
        Collect water level and quality data
        """
        try:
            water_data = []
            
            # USGS water level data
            usgs_data = await self.get_usgs_water_data(latitude, longitude)
            if usgs_data is not None and not usgs_data.empty:
                water_data.append(usgs_data)
            
            # Local water sensors
            sensor_water = await self.sensor_service.get_water_sensors(latitude, longitude)
            if sensor_water is not None and not sensor_water.empty:
                water_data.append(sensor_water)
            
            # Combine water data
            if water_data:
                combined_water = pd.concat(water_data, ignore_index=True)
                return self.process_water_data(combined_water)
            else:
                # Return default water data structure
                return pd.DataFrame({
                    'timestamp': [datetime.now()],
                    'water_level': [0.0],
                    'water_temperature': [15.0],
                    'flow_rate': [0.0],
                    'turbidity': [0.0]
                })
                
        except Exception as e:
            logger.error(f"Water data collection failed: {e}")
            return pd.DataFrame()
    
    async def collect_atmospheric_data(self, latitude: float, longitude: float) -> pd.DataFrame:
        """
        Collect atmospheric pressure, wind, and humidity data
        """
        try:
            atmospheric_data = []
            
            # NOAA atmospheric data
            noaa_data = await self.get_noaa_atmospheric_data(latitude, longitude)
            if noaa_data is not None and not noaa_data.empty:
                atmospheric_data.append(noaa_data)
            
            # Weather API atmospheric data
            weather_atmospheric = await self.weather_service.get_atmospheric_data(
                latitude, longitude
            )
            if weather_atmospheric is not None and not weather_atmospheric.empty:
                atmospheric_data.append(weather_atmospheric)
            
            # Combine atmospheric data
            if atmospheric_data:
                combined_atmospheric = pd.concat(atmospheric_data, ignore_index=True)
                return self.process_atmospheric_data(combined_atmospheric)
            else:
                # Return default atmospheric data structure
                return pd.DataFrame({
                    'timestamp': [datetime.now()],
                    'pressure': [1013.25],  # Standard atmospheric pressure
                    'wind_speed': [0.0],
                    'wind_direction': [0.0],
                    'humidity': [50.0],
                    'temperature': [20.0],
                    'vorticity': [0.0],
                    'divergence': [0.0]
                })
                
        except Exception as e:
            logger.error(f"Atmospheric data collection failed: {e}")
            return pd.DataFrame()
    
    async def collect_ocean_data(self, latitude: float, longitude: float) -> pd.DataFrame:
        """
        Collect ocean data (SST, sea level, etc.)
        """
        try:
            ocean_data = []
            
            # NOAA ocean data
            noaa_ocean = await self.get_noaa_ocean_data(latitude, longitude)
            if noaa_ocean is not None and not noaa_ocean.empty:
                ocean_data.append(noaa_ocean)
            
            # Satellite ocean data
            satellite_ocean = await self.satellite_service.get_ocean_data(
                latitude, longitude
            )
            if satellite_ocean is not None and not satellite_ocean.empty:
                ocean_data.append(satellite_ocean)
            
            # Combine ocean data
            if ocean_data:
                combined_ocean = pd.concat(ocean_data, ignore_index=True)
                return self.process_ocean_data(combined_ocean)
            else:
                # Return default ocean data structure
                return pd.DataFrame({
                    'timestamp': [datetime.now()],
                    'sst': [20.0],  # Sea surface temperature
                    'sea_surface_height': [0.0],
                    'ocean_heat_content': [0.0],
                    'mixed_layer_depth': [50.0],
                    'salinity': [35.0]
                })
                
        except Exception as e:
            logger.error(f"Ocean data collection failed: {e}")
            return pd.DataFrame()
    
    async def collect_spatial_data(self, latitude: float, longitude: float, 
                                 radius_km: float) -> List[np.ndarray]:
        """
        Collect spatial data for the location
        """
        try:
            spatial_data = []
            
            # Get satellite imagery
            satellite_images = await self.satellite_service.get_spatial_images(
                latitude, longitude, radius_km
            )
            if satellite_images:
                spatial_data.extend(satellite_images)
            
            # Get radar data
            radar_data = await self.get_radar_data(latitude, longitude, radius_km)
            if radar_data:
                spatial_data.extend(radar_data)
            
            return spatial_data
            
        except Exception as e:
            logger.error(f"Spatial data collection failed: {e}")
            return []
    
    async def get_smap_soil_moisture(self, latitude: float, longitude: float) -> Optional[pd.DataFrame]:
        """
        Get NASA SMAP soil moisture data
        """
        try:
            # In production, implement actual SMAP API call
            # For now, return simulated data
            return pd.DataFrame({
                'timestamp': [datetime.now()],
                'soil_moisture': [np.random.uniform(0.1, 0.5)],
                'depth': [5]
            })
        except Exception as e:
            logger.error(f"SMAP data collection failed: {e}")
            return None
    
    async def get_usgs_water_data(self, latitude: float, longitude: float) -> Optional[pd.DataFrame]:
        """
        Get USGS water level data
        """
        try:
            # In production, implement actual USGS API call
            # For now, return simulated data
            return pd.DataFrame({
                'timestamp': [datetime.now()],
                'water_level': [np.random.uniform(0.5, 2.0)],
                'flow_rate': [np.random.uniform(10, 100)],
                'site_id': ['simulated_site']
            })
        except Exception as e:
            logger.error(f"USGS data collection failed: {e}")
            return None
    
    async def get_noaa_atmospheric_data(self, latitude: float, longitude: float) -> Optional[pd.DataFrame]:
        """
        Get NOAA atmospheric data
        """
        try:
            # In production, implement actual NOAA API call
            # For now, return simulated data
            return pd.DataFrame({
                'timestamp': [datetime.now()],
                'pressure': [np.random.uniform(1000, 1020)],
                'wind_speed': [np.random.uniform(0, 20)],
                'wind_direction': [np.random.uniform(0, 360)],
                'vorticity': [np.random.uniform(-1e-5, 1e-5)],
                'divergence': [np.random.uniform(-1e-5, 1e-5)]
            })
        except Exception as e:
            logger.error(f"NOAA atmospheric data collection failed: {e}")
            return None
    
    async def get_noaa_ocean_data(self, latitude: float, longitude: float) -> Optional[pd.DataFrame]:
        """
        Get NOAA ocean data
        """
        try:
            # In production, implement actual NOAA ocean API call
            # For now, return simulated data
            return pd.DataFrame({
                'timestamp': [datetime.now()],
                'sst': [np.random.uniform(15, 30)],
                'sea_surface_height': [np.random.uniform(-0.5, 0.5)],
                'ocean_heat_content': [np.random.uniform(1e7, 1e8)],
                'mixed_layer_depth': [np.random.uniform(20, 100)]
            })
        except Exception as e:
            logger.error(f"NOAA ocean data collection failed: {e}")
            return None
    
    async def get_radar_data(self, latitude: float, longitude: float, 
                           radius_km: float) -> List[np.ndarray]:
        """
        Get radar data for the location
        """
        try:
            # In production, implement actual radar API call
            # For now, return simulated radar data
            radar_data = []
            for i in range(5):  # Last 5 time steps
                # Create simulated radar image
                radar_image = np.random.rand(64, 64) * 100  # Rainfall intensity
                radar_data.append(radar_image)
            
            return radar_data
            
        except Exception as e:
            logger.error(f"Radar data collection failed: {e}")
            return []
    
    def process_soil_data(self, soil_data: pd.DataFrame) -> pd.DataFrame:
        """
        Process and clean soil data
        """
        # Remove duplicates
        soil_data = soil_data.drop_duplicates(subset=['timestamp'])
        
        # Sort by timestamp
        soil_data = soil_data.sort_values('timestamp')
        
        # Fill missing values
        soil_data = soil_data.ffill().bfill()
        
        return soil_data
    
    def process_water_data(self, water_data: pd.DataFrame) -> pd.DataFrame:
        """
        Process and clean water data
        """
        # Remove duplicates
        water_data = water_data.drop_duplicates(subset=['timestamp'])
        
        # Sort by timestamp
        water_data = water_data.sort_values('timestamp')
        
        # Fill missing values
        water_data = water_data.ffill().bfill()
        
        return water_data
    
    def process_atmospheric_data(self, atmospheric_data: pd.DataFrame) -> pd.DataFrame:
        """
        Process and clean atmospheric data
        """
        # Remove duplicates
        atmospheric_data = atmospheric_data.drop_duplicates(subset=['timestamp'])
        
        # Sort by timestamp
        atmospheric_data = atmospheric_data.sort_values('timestamp')
        
        # Fill missing values
        atmospheric_data = atmospheric_data.ffill().bfill()
        
        return atmospheric_data
    
    def process_ocean_data(self, ocean_data: pd.DataFrame) -> pd.DataFrame:
        """
        Process and clean ocean data
        """
        # Remove duplicates
        ocean_data = ocean_data.drop_duplicates(subset=['timestamp'])
        
        # Sort by timestamp
        ocean_data = ocean_data.sort_values('timestamp')
        
        # Fill missing values
        ocean_data = ocean_data.ffill().bfill()
        
        return ocean_data
    
    async def process_combined_data(self, weather_data: Dict, satellite_data: Dict, 
                                  sensor_data: Dict) -> Dict:
        """
        Process and combine data from all sources
        """
        try:
            combined_data = {
                'timestamp': datetime.now(),
                'weather': weather_data,
                'satellite': satellite_data,
                'sensors': sensor_data,
                'processed': True
            }
            
            # Add derived metrics
            combined_data['derived_metrics'] = await self.calculate_derived_metrics(
                weather_data, satellite_data, sensor_data
            )
            
            return combined_data
            
        except Exception as e:
            logger.error(f"Data processing failed: {e}")
            raise
    
    async def calculate_derived_metrics(self, weather_data: Dict, satellite_data: Dict, 
                                      sensor_data: Dict) -> Dict:
        """
        Calculate derived environmental metrics
        """
        try:
            derived_metrics = {}
            
            # Calculate drought indices
            if 'precipitation' in weather_data and 'temperature' in weather_data:
                derived_metrics['spi'] = self.calculate_spi(weather_data['precipitation'])
                derived_metrics['spei'] = self.calculate_spei(
                    weather_data['precipitation'], weather_data['temperature']
                )
            
            # Calculate vegetation indices
            if 'satellite_bands' in satellite_data:
                derived_metrics['ndvi'] = self.calculate_ndvi(satellite_data['satellite_bands'])
                derived_metrics['evi'] = self.calculate_evi(satellite_data['satellite_bands'])
            
            # Calculate flood risk indicators
            if 'water_level' in sensor_data and 'rainfall' in weather_data:
                derived_metrics['flood_risk'] = self.calculate_flood_risk(
                    sensor_data['water_level'], weather_data['rainfall']
                )
            
            return derived_metrics
            
        except Exception as e:
            logger.error(f"Derived metrics calculation failed: {e}")
            return {}
    
    def calculate_spi(self, precipitation: List[float]) -> float:
        """
        Calculate Standardized Precipitation Index
        """
        try:
            precip_series = pd.Series(precipitation)
            rolling_sum = precip_series.rolling(window=30).sum()
            mean_val = rolling_sum.mean()
            std_val = rolling_sum.std()
            
            if std_val > 0:
                spi = (rolling_sum.iloc[-1] - mean_val) / std_val
                return float(spi)
            else:
                return 0.0
        except Exception as e:
            logger.error(f"SPI calculation failed: {e}")
            return 0.0
    
    def calculate_spei(self, precipitation: List[float], temperature: List[float]) -> float:
        """
        Calculate Standardized Precipitation Evapotranspiration Index
        """
        try:
            precip_series = pd.Series(precipitation)
            temp_series = pd.Series(temperature)
            
            # Simplified PET calculation
            pet = 0.0023 * (temp_series + 17.8) * temp_series ** 0.5
            
            # Water balance
            water_balance = precip_series - pet
            mean_wb = water_balance.mean()
            std_wb = water_balance.std()
            
            if std_wb > 0:
                spei = (water_balance.iloc[-1] - mean_wb) / std_wb
                return float(spei)
            else:
                return 0.0
        except Exception as e:
            logger.error(f"SPEI calculation failed: {e}")
            return 0.0
    
    def calculate_ndvi(self, satellite_bands: Dict) -> float:
        """
        Calculate Normalized Difference Vegetation Index
        """
        try:
            if 'nir' in satellite_bands and 'red' in satellite_bands:
                nir = satellite_bands['nir']
                red = satellite_bands['red']
                
                if nir + red > 0:
                    ndvi = (nir - red) / (nir + red)
                    return float(ndvi)
                else:
                    return 0.0
            else:
                return 0.0
        except Exception as e:
            logger.error(f"NDVI calculation failed: {e}")
            return 0.0
    
    def calculate_evi(self, satellite_bands: Dict) -> float:
        """
        Calculate Enhanced Vegetation Index
        """
        try:
            if all(band in satellite_bands for band in ['nir', 'red', 'blue']):
                nir = satellite_bands['nir']
                red = satellite_bands['red']
                blue = satellite_bands['blue']
                
                denominator = nir + 6 * red - 7.5 * blue + 1
                if denominator > 0:
                    evi = 2.5 * (nir - red) / denominator
                    return float(evi)
                else:
                    return 0.0
            else:
                return 0.0
        except Exception as e:
            logger.error(f"EVI calculation failed: {e}")
            return 0.0
    
    def calculate_flood_risk(self, water_level: float, rainfall: float) -> float:
        """
        Calculate flood risk based on water level and rainfall
        """
        try:
            # Simplified flood risk calculation
            # In production, use more sophisticated models
            
            # Normalize water level (assuming 0-5m range)
            normalized_water = min(water_level / 5.0, 1.0)
            
            # Normalize rainfall (assuming 0-100mm range)
            normalized_rainfall = min(rainfall / 100.0, 1.0)
            
            # Calculate risk as weighted combination
            flood_risk = 0.6 * normalized_water + 0.4 * normalized_rainfall
            
            return float(flood_risk)
        except Exception as e:
            logger.error(f"Flood risk calculation failed: {e}")
            return 0.0
    
    async def store_collected_data(self, data: Dict):
        """
        Store collected data in database
        """
        try:
            # In production, implement actual database storage
            # For now, just log the data
            logger.info(f"Storing collected data: {len(str(data))} characters")
            
            # Save to file for debugging
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"data_collection_{timestamp}.json"
            
            with open(filename, 'w') as f:
                json.dump(data, f, default=str, indent=2)
                
        except Exception as e:
            logger.error(f"Data storage failed: {e}")
            raise 