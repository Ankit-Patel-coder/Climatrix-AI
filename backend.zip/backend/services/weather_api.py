"""
Weather API Service
Integrates with multiple weather data providers:
- OpenWeatherMap API
- NOAA Weather API
- National Weather Service API
"""

import aiohttp
import pandas as pd
from typing import Dict, List, Optional
from datetime import datetime, timedelta
import logging
import os
import json
import numpy as np

logger = logging.getLogger(__name__)

class WeatherAPIService:
    """
    Weather data collection service
    """
    
    def __init__(self):
        self.openweather_api_key = os.getenv("OPENWEATHER_API_KEY", "")
        self.noaa_api_key = os.getenv("NOAA_API_KEY", "")
        self.base_urls = {
            "openweather": "https://api.openweathermap.org/data/2.5",
            "noaa": "https://api.weather.gov",
            "nws": "https://api.weather.gov"
        }
        self.session = None
    
    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
    
    async def collect_weather_data(self) -> Dict:
        """
        Collect weather data from all sources
        """
        try:
            weather_data = {}
            
            # Collect from OpenWeatherMap
            if self.openweather_api_key:
                openweather_data = await self.get_openweather_data()
                weather_data["openweather"] = openweather_data
            
            # Collect from NOAA
            noaa_data = await self.get_noaa_data()
            weather_data["noaa"] = noaa_data
            
            # Collect from National Weather Service
            nws_data = await self.get_nws_data()
            weather_data["nws"] = nws_data
            
            return weather_data
            
        except Exception as e:
            logger.error(f"Weather data collection failed: {e}")
            return {}
    
    async def get_location_weather(self, latitude: float, longitude: float, 
                                 radius_km: float = 50.0) -> pd.DataFrame:
        """
        Get weather data for a specific location
        """
        try:
            weather_data = []
            
            # Get current weather
            current_weather = await self.get_current_weather(latitude, longitude)
            if current_weather:
                weather_data.append(current_weather)
            
            # Get forecast
            forecast = await self.get_weather_forecast(latitude, longitude)
            if forecast:
                weather_data.extend(forecast)
            
            # Get historical data
            historical = await self.get_historical_weather(latitude, longitude)
            if historical:
                weather_data.extend(historical)
            
            if weather_data:
                df = pd.DataFrame(weather_data)
                df = df.sort_values('timestamp')
                return df
            else:
                # Return default weather data structure
                return pd.DataFrame({
                    'timestamp': [datetime.now()],
                    'temperature': [20.0],
                    'humidity': [50.0],
                    'pressure': [1013.25],
                    'wind_speed': [0.0],
                    'wind_direction': [0.0],
                    'precipitation': [0.0],
                    'visibility': [10.0]
                })
                
        except Exception as e:
            logger.error(f"Location weather data collection failed: {e}")
            return pd.DataFrame()
    
    async def get_current_weather(self, latitude: float, longitude: float) -> Optional[Dict]:
        """
        Get current weather conditions
        """
        try:
            if self.openweather_api_key:
                url = f"{self.base_urls['openweather']}/weather"
                params = {
                    'lat': latitude,
                    'lon': longitude,
                    'appid': self.openweather_api_key,
                    'units': 'metric'
                }
                
                async with aiohttp.ClientSession() as session:
                    async with session.get(url, params=params) as response:
                        if response.status == 200:
                            data = await response.json()
                            return self.parse_openweather_current(data)
            
            # Fallback to NOAA
            return await self.get_noaa_current_weather(latitude, longitude)
            
        except Exception as e:
            logger.error(f"Current weather collection failed: {e}")
            return None
    
    async def get_weather_forecast(self, latitude: float, longitude: float) -> List[Dict]:
        """
        Get weather forecast
        """
        try:
            forecast_data = []
            
            if self.openweather_api_key:
                url = f"{self.base_urls['openweather']}/forecast"
                params = {
                    'lat': latitude,
                    'lon': longitude,
                    'appid': self.openweather_api_key,
                    'units': 'metric'
                }
                
                async with aiohttp.ClientSession() as session:
                    async with session.get(url, params=params) as response:
                        if response.status == 200:
                            data = await response.json()
                            forecast_data.extend(self.parse_openweather_forecast(data))
            
            return forecast_data
            
        except Exception as e:
            logger.error(f"Weather forecast collection failed: {e}")
            return []
    
    async def get_historical_weather(self, latitude: float, longitude: float) -> List[Dict]:
        """
        Get historical weather data
        """
        try:
            # Get data for the last 30 days
            end_date = datetime.now()
            start_date = end_date - timedelta(days=30)
            
            historical_data = []
            
            if self.openweather_api_key:
                # OpenWeatherMap historical data (requires paid plan)
                # For demo, we'll simulate historical data
                historical_data = self.generate_historical_data(start_date, end_date)
            
            return historical_data
            
        except Exception as e:
            logger.error(f"Historical weather collection failed: {e}")
            return []
    
    async def get_atmospheric_data(self, latitude: float, longitude: float) -> Optional[pd.DataFrame]:
        """
        Get atmospheric data (pressure, wind, etc.)
        """
        try:
            atmospheric_data = []
            
            # Get current atmospheric conditions
            current = await self.get_current_weather(latitude, longitude)
            if current:
                atmospheric_data.append(current)
            
            # Get upper atmosphere data from NOAA
            noaa_atmospheric = await self.get_noaa_atmospheric_data(latitude, longitude)
            if noaa_atmospheric:
                atmospheric_data.extend(noaa_atmospheric)
            
            if atmospheric_data:
                df = pd.DataFrame(atmospheric_data)
                return df
            else:
                return pd.DataFrame()
                
        except Exception as e:
            logger.error(f"Atmospheric data collection failed: {e}")
            return pd.DataFrame()
    
    async def get_openweather_data(self) -> Dict:
        """
        Get data from OpenWeatherMap API
        """
        try:
            # For demo purposes, return simulated data
            return {
                "current": {
                    "temperature": 22.5,
                    "humidity": 65,
                    "pressure": 1013.25,
                    "wind_speed": 5.2,
                    "wind_direction": 180,
                    "description": "Partly cloudy"
                },
                "forecast": [
                    {
                        "timestamp": datetime.now() + timedelta(hours=i),
                        "temperature": 20 + i * 0.5,
                        "humidity": 60 + i * 2,
                        "precipitation": max(0, i - 10) * 0.1
                    }
                    for i in range(24)
                ]
            }
        except Exception as e:
            logger.error(f"OpenWeatherMap data collection failed: {e}")
            return {}
    
    async def get_noaa_data(self) -> Dict:
        """
        Get data from NOAA API
        """
        try:
            # For demo purposes, return simulated data
            return {
                "current": {
                    "temperature": 23.1,
                    "humidity": 62,
                    "pressure": 1012.8,
                    "wind_speed": 4.8,
                    "wind_direction": 175,
                    "visibility": 10.0
                },
                "forecast": [
                    {
                        "timestamp": datetime.now() + timedelta(hours=i),
                        "temperature": 21 + i * 0.3,
                        "humidity": 58 + i * 1.5,
                        "precipitation": max(0, i - 8) * 0.15
                    }
                    for i in range(24)
                ]
            }
        except Exception as e:
            logger.error(f"NOAA data collection failed: {e}")
            return {}
    
    async def get_nws_data(self) -> Dict:
        """
        Get data from National Weather Service API
        """
        try:
            # For demo purposes, return simulated data
            return {
                "current": {
                    "temperature": 21.8,
                    "humidity": 68,
                    "pressure": 1014.2,
                    "wind_speed": 6.1,
                    "wind_direction": 185,
                    "conditions": "Mostly cloudy"
                },
                "forecast": [
                    {
                        "timestamp": datetime.now() + timedelta(hours=i),
                        "temperature": 19 + i * 0.4,
                        "humidity": 65 + i * 1.8,
                        "precipitation": max(0, i - 12) * 0.12
                    }
                    for i in range(24)
                ]
            }
        except Exception as e:
            logger.error(f"NWS data collection failed: {e}")
            return {}
    
    async def get_noaa_current_weather(self, latitude: float, longitude: float) -> Optional[Dict]:
        """
        Get current weather from NOAA
        """
        try:
            # For demo purposes, return simulated data
            return {
                'timestamp': datetime.now(),
                'temperature': 22.5,
                'humidity': 65.0,
                'pressure': 1013.25,
                'wind_speed': 5.2,
                'wind_direction': 180.0,
                'precipitation': 0.0,
                'visibility': 10.0,
                'source': 'noaa'
            }
        except Exception as e:
            logger.error(f"NOAA current weather failed: {e}")
            return None
    
    async def get_noaa_atmospheric_data(self, latitude: float, longitude: float) -> List[Dict]:
        """
        Get atmospheric data from NOAA
        """
        try:
            # For demo purposes, return simulated data
            return [
                {
                    'timestamp': datetime.now() + timedelta(hours=i),
                    'pressure': 1013.25 + i * 0.1,
                    'wind_speed': 5.2 + i * 0.2,
                    'wind_direction': 180.0 + i * 5,
                    'vorticity': 0.00001 * (i - 12),
                    'divergence': 0.000005 * (i - 12),
                    'source': 'noaa'
                }
                for i in range(24)
            ]
        except Exception as e:
            logger.error(f"NOAA atmospheric data failed: {e}")
            return []
    
    def parse_openweather_current(self, data: Dict) -> Dict:
        """
        Parse OpenWeatherMap current weather data
        """
        try:
            return {
                'timestamp': datetime.fromtimestamp(data['dt']),
                'temperature': data['main']['temp'],
                'humidity': data['main']['humidity'],
                'pressure': data['main']['pressure'],
                'wind_speed': data['wind']['speed'],
                'wind_direction': data['wind'].get('deg', 0),
                'precipitation': data.get('rain', {}).get('1h', 0),
                'visibility': data.get('visibility', 10000) / 1000,  # Convert to km
                'description': data['weather'][0]['description'],
                'source': 'openweather'
            }
        except Exception as e:
            logger.error(f"OpenWeatherMap parsing failed: {e}")
            return {}
    
    def parse_openweather_forecast(self, data: Dict) -> List[Dict]:
        """
        Parse OpenWeatherMap forecast data
        """
        try:
            forecast_data = []
            for item in data['list']:
                forecast_data.append({
                    'timestamp': datetime.fromtimestamp(item['dt']),
                    'temperature': item['main']['temp'],
                    'humidity': item['main']['humidity'],
                    'pressure': item['main']['pressure'],
                    'wind_speed': item['wind']['speed'],
                    'wind_direction': item['wind'].get('deg', 0),
                    'precipitation': item.get('rain', {}).get('3h', 0),
                    'description': item['weather'][0]['description'],
                    'source': 'openweather'
                })
            return forecast_data
        except Exception as e:
            logger.error(f"OpenWeatherMap forecast parsing failed: {e}")
            return []
    
    def generate_historical_data(self, start_date: datetime, end_date: datetime) -> List[Dict]:
        """
        Generate simulated historical weather data
        """
        try:
            historical_data = []
            current_date = start_date
            
            while current_date <= end_date:
                # Generate realistic weather patterns
                base_temp = 20 + 10 * np.sin(2 * np.pi * current_date.hour / 24)
                temp_variation = np.random.normal(0, 2)
                
                historical_data.append({
                    'timestamp': current_date,
                    'temperature': base_temp + temp_variation,
                    'humidity': np.random.uniform(40, 80),
                    'pressure': np.random.uniform(1000, 1020),
                    'wind_speed': np.random.uniform(0, 15),
                    'wind_direction': np.random.uniform(0, 360),
                    'precipitation': np.random.exponential(0.5),
                    'source': 'simulated'
                })
                
                current_date += timedelta(hours=1)
            
            return historical_data
            
        except Exception as e:
            logger.error(f"Historical data generation failed: {e}")
            return []
    
    async def check_connection(self) -> bool:
        """
        Check if weather APIs are accessible
        """
        try:
            # Test OpenWeatherMap connection
            if self.openweather_api_key:
                url = f"{self.base_urls['openweather']}/weather"
                params = {
                    'lat': 40.7128,
                    'lon': -74.0060,
                    'appid': self.openweather_api_key
                }
                
                async with aiohttp.ClientSession() as session:
                    async with session.get(url, params=params) as response:
                        if response.status == 200:
                            return True
            
            # Test NOAA connection
            url = f"{self.base_urls['noaa']}/points/40.7128,-74.0060"
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        return True
            
            return False
            
        except Exception as e:
            logger.error(f"Weather API connection check failed: {e}")
            return False 