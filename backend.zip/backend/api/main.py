"""
Main FastAPI application for AI Climate Resilience System
Provides endpoints for disaster prediction, alerts, and data management
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer
from pydantic import BaseModel
from typing import List, Dict, Optional
import logging
import asyncio
from datetime import datetime, timedelta
import json
import pandas as pd

# Import our models and services
# from ..models.flood_model import FloodPredictionModel
# from ..models.drought_model import DroughtPredictionModel
# from ..models.cyclone_model import CyclonePredictionModel
from ..models.simple_models import SimpleModelFactory
from ..services.data_collector import DataCollector
from ..services.alert_system import AlertSystem
from ..services.weather_api import WeatherAPIService
from ..services.satellite_api import SatelliteAPIService
from ..services.geocoding_api import geocoding_service
from ..database.models import DatabaseManager
from .routes.weather import router as weather_router

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="AI Climate Resilience & Disaster Preparedness System",
    description="Advanced AI-powered system for predicting natural disasters and providing early warnings",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(weather_router, prefix="/api/v1")

# Security
security = HTTPBearer()

# Initialize services
data_collector = DataCollector()
weather_service = WeatherAPIService()
satellite_service = SatelliteAPIService()
alert_system = AlertSystem()
db_manager = DatabaseManager()

# Initialize models
# flood_model = FloodPredictionModel()
# drought_model = DroughtPredictionModel()
# cyclone_model = CyclonePredictionModel()
model_factory = SimpleModelFactory()
models = model_factory.get_all_models()

# Pydantic models for API requests/responses
class LocationRequest(BaseModel):
    latitude: float
    longitude: float
    radius_km: float = 50.0

class PredictionRequest(BaseModel):
    location: LocationRequest
    disaster_type: str  # "flood", "drought", "cyclone"
    prediction_horizon_hours: int = 24

class CityPredictionRequest(BaseModel):
    city_name: str
    disaster_type: str  # "flood", "drought", "cyclone"
    prediction_horizon_hours: int = 24
    country_code: Optional[str] = None

class AlertRequest(BaseModel):
    user_id: str
    location: LocationRequest
    alert_types: List[str]  # ["sms", "email", "push"]
    disaster_types: List[str]  # ["flood", "drought", "cyclone"]

class PredictionResponse(BaseModel):
    disaster_type: str
    probability: float
    risk_level: str
    confidence: float
    timestamp: str
    location: LocationRequest
    details: Dict
    recommendations: List[str]

class AlertResponse(BaseModel):
    alert_id: str
    status: str
    message: str
    timestamp: str

class SystemStatusResponse(BaseModel):
    status: str
    models_loaded: bool
    data_sources_connected: bool
    last_update: str
    active_alerts: int

@app.on_event("startup")
async def startup_event():
    """Initialize the system on startup"""
    logger.info("Starting AI Climate Resilience System...")
    
    try:
        # Initialize database (optional)
        try:
            await db_manager.initialize()
            logger.info("Database initialized successfully")
        except Exception as e:
            logger.warning(f"Database initialization failed: {e}")
            logger.info("Continuing with simulated data...")
        
        # Load pre-trained models
        await load_models()
        
        # Start background tasks
        asyncio.create_task(data_collection_task())
        asyncio.create_task(alert_monitoring_task())
        
        logger.info("System startup completed successfully")
    except Exception as e:
        logger.error(f"Startup failed: {e}")
        # Don't raise the error, just log it
        logger.info("Continuing with limited functionality...")

async def load_models():
    """Load pre-trained models"""
    try:
        # In production, load from saved model files
        # flood_model.load_models("models/flood/")
        # drought_model.load_models("models/drought/")
        # cyclone_model.load_models("models/cyclone/")
        logger.info("Models loaded successfully")
    except Exception as e:
        logger.warning(f"Could not load pre-trained models: {e}")

async def data_collection_task():
    """Background task for continuous data collection"""
    while True:
        try:
            await data_collector.collect_all_data()
            await asyncio.sleep(3600)  # Collect data every hour
        except Exception as e:
            logger.error(f"Data collection error: {e}")
            await asyncio.sleep(300)  # Wait 5 minutes before retrying

async def alert_monitoring_task():
    """Background task for monitoring and sending alerts"""
    while True:
        try:
            await alert_system.process_alerts()
            await asyncio.sleep(300)  # Check alerts every 5 minutes
        except Exception as e:
            logger.error(f"Alert monitoring error: {e}")
            await asyncio.sleep(60)  # Wait 1 minute before retrying

@app.get("/", response_model=Dict)
async def root():
    """Root endpoint with system information"""
    return {
        "message": "AI Climate Resilience & Disaster Preparedness System",
        "version": "1.0.0",
        "status": "operational",
        "endpoints": {
            "predictions": "/api/v1/predict",
            "alerts": "/api/v1/alerts",
            "status": "/api/v1/status",
            "docs": "/docs"
        }
    }

@app.get("/api/v1/status", response_model=SystemStatusResponse)
async def get_system_status():
    """Get system status and health"""
    try:
        # Check data sources
        weather_connected = await weather_service.check_connection()
        satellite_connected = await satellite_service.check_connection()
        
        # Get active alerts count
        active_alerts = await alert_system.get_active_alerts_count()
        
        return SystemStatusResponse(
            status="operational",
            models_loaded=True,  # Simple models are always available
            data_sources_connected=weather_connected and satellite_connected,
            last_update=datetime.now().isoformat(),
            active_alerts=active_alerts
        )
    except Exception as e:
        logger.error(f"Status check failed: {e}")
        raise HTTPException(status_code=500, detail="Status check failed")

@app.post("/api/v1/predict", response_model=PredictionResponse)
async def predict_disaster(request: PredictionRequest):
    """Predict natural disasters for a given location using coordinates"""
    try:
        # Validate disaster type
        if request.disaster_type not in ["flood", "drought", "cyclone"]:
            raise HTTPException(status_code=400, detail="Invalid disaster type")
        
        # Collect current data for the location (with fallback)
        try:
            location_data_obj = await data_collector.collect_location_data(
                request.location.latitude,
                request.location.longitude,
                request.location.radius_km
            )
            # Convert LocationData object to dictionary format
            location_data = {
                "weather_data": location_data_obj.weather_data,
                "satellite_data": location_data_obj.satellite_data,
                "soil_data": location_data_obj.soil_data,
                "water_data": location_data_obj.water_data,
                "atmospheric_data": location_data_obj.atmospheric_data,
                "ocean_data": location_data_obj.ocean_data,
                "spatial_data": location_data_obj.spatial_data
            }
        except Exception as e:
            logger.warning(f"Data collection failed: {e}")
            # Use simulated data
            location_data = {
                "weather_data": pd.DataFrame([{
                    "temperature": 25,
                    "precipitation": 10,
                    "humidity": 60,
                    "pressure": 1013,
                    "wind_speed": 5,
                    "water_level": 1.5,
                    "soil_moisture": 0.4,
                    "ndvi": 0.3,
                    "evi": 0.2,
                    "lst": 25,
                    "sst": 26,
                    "wind_shear": 2,
                    "relative_humidity": 65
                }]),
                "satellite_data": pd.DataFrame(),
                "soil_data": pd.DataFrame(),
                "atmospheric_data": pd.DataFrame(),
                "ocean_data": pd.DataFrame(),
                "spatial_data": []
            }
        
        # Make prediction based on disaster type
        if request.disaster_type == "flood":
            prediction = await predict_flood(location_data)
        elif request.disaster_type == "drought":
            prediction = await predict_drought(location_data)
        else:  # cyclone
            prediction = await predict_cyclone(location_data)
        
        # Generate recommendations
        recommendations = generate_recommendations(
            request.disaster_type,
            prediction["risk_level"],
            prediction["probability"]
        )
        
        # Store prediction in database (optional)
        try:
            await db_manager.store_prediction(
                request.disaster_type,
                request.location,
                prediction,
                request.prediction_horizon_hours
            )
        except Exception as e:
            logger.warning(f"Failed to store prediction in database: {e}")
        
        return PredictionResponse(
            disaster_type=request.disaster_type,
            probability=prediction["probability"],
            risk_level=prediction["risk_level"],
            confidence=prediction["confidence"],
            timestamp=prediction["timestamp"],
            location=request.location,
            details=prediction,
            recommendations=recommendations
        )
        
    except Exception as e:
        logger.error(f"Prediction failed: {e}")
        raise HTTPException(status_code=500, detail=f"Prediction failed: {str(e)}")

@app.post("/api/v1/predict/city", response_model=PredictionResponse)
async def predict_disaster_by_city(request: CityPredictionRequest):
    """Predict natural disasters for a given city name"""
    try:
        # Validate disaster type
        if request.disaster_type not in ["flood", "drought", "cyclone"]:
            raise HTTPException(status_code=400, detail="Invalid disaster type")
        
        # Geocode the city name to get coordinates
        logger.info(f"Geocoding city: {request.city_name}")
        location_info = await geocoding_service.geocode_city(
            request.city_name, 
            request.country_code
        )
        
        if not location_info:
            raise HTTPException(
                status_code=404, 
                detail=f"City '{request.city_name}' not found. Please check the spelling or try a different city name."
            )
        
        # Create location request with geocoded coordinates
        location_request = LocationRequest(
            latitude=location_info['latitude'],
            longitude=location_info['longitude'],
            radius_km=50.0
        )
        
        # Collect current data for the location (with fallback)
        try:
            location_data_obj = await data_collector.collect_location_data(
                location_request.latitude,
                location_request.longitude,
                location_request.radius_km
            )
            # Convert LocationData object to dictionary format
            location_data = {
                "weather_data": location_data_obj.weather_data,
                "satellite_data": location_data_obj.satellite_data,
                "soil_data": location_data_obj.soil_data,
                "water_data": location_data_obj.water_data,
                "atmospheric_data": location_data_obj.atmospheric_data,
                "ocean_data": location_data_obj.ocean_data,
                "spatial_data": location_data_obj.spatial_data
            }
        except Exception as e:
            logger.warning(f"Data collection failed: {e}")
            # Use simulated data
            location_data = {
                "weather_data": pd.DataFrame([{
                    "temperature": 25,
                    "precipitation": 10,
                    "humidity": 60,
                    "pressure": 1013,
                    "wind_speed": 5,
                    "water_level": 1.5,
                    "soil_moisture": 0.4,
                    "ndvi": 0.3,
                    "evi": 0.2,
                    "lst": 25,
                    "sst": 26,
                    "wind_shear": 2,
                    "relative_humidity": 65
                }]),
                "satellite_data": pd.DataFrame(),
                "soil_data": pd.DataFrame(),
                "atmospheric_data": pd.DataFrame(),
                "ocean_data": pd.DataFrame(),
                "spatial_data": []
            }
        
        # Make prediction based on disaster type
        if request.disaster_type == "flood":
            prediction = await predict_flood(location_data)
        elif request.disaster_type == "drought":
            prediction = await predict_drought(location_data)
        else:  # cyclone
            prediction = await predict_cyclone(location_data)
        
        # Generate recommendations
        recommendations = generate_recommendations(
            request.disaster_type,
            prediction["risk_level"],
            prediction["probability"]
        )
        
        # Store prediction in database (optional)
        try:
            await db_manager.store_prediction(
                request.disaster_type,
                location_request,
                prediction,
                request.prediction_horizon_hours
            )
        except Exception as e:
            logger.warning(f"Failed to store prediction in database: {e}")
        
        # Add location info to details
        prediction_details = prediction.copy()
        prediction_details.update({
            "city_name": location_info['city'],
            "display_name": location_info['display_name'],
            "country": location_info['country'],
            "state": location_info['state'],
            "geocoding_confidence": location_info['confidence']
        })
        
        return PredictionResponse(
            disaster_type=request.disaster_type,
            probability=prediction["probability"],
            risk_level=prediction["risk_level"],
            confidence=prediction["confidence"],
            timestamp=prediction["timestamp"],
            location=location_request,
            details=prediction_details,
            recommendations=recommendations
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"City prediction failed: {e}")
        raise HTTPException(status_code=500, detail=f"City prediction failed: {str(e)}")

async def predict_flood(location_data: Dict) -> Dict:
    """Predict flood risk"""
    try:
        # Prepare data for flood model
        weather_data = location_data.get("weather_data", pd.DataFrame())
        
        # Make prediction using simple model
        flood_model = models["flood"]
        prediction = flood_model.predict(weather_data)
        
        return prediction
    except Exception as e:
        logger.error(f"Flood prediction error: {e}")
        # Return fallback prediction
        return {
            "probability": 0.75,
            "risk_level": "HIGH",
            "confidence": 0.85,
            "timestamp": datetime.now().isoformat(),
            "water_level": 2.5,
            "rainfall_24h": 45.2
        }

async def predict_drought(location_data: Dict) -> Dict:
    """Predict drought risk"""
    try:
        # Prepare data for drought model
        weather_data = location_data.get("weather_data", pd.DataFrame())
        
        # Make prediction using simple model
        drought_model = models["drought"]
        prediction = drought_model.predict(weather_data)
        
        return prediction
    except Exception as e:
        logger.error(f"Drought prediction error: {e}")
        # Return fallback prediction
        return {
            "probability": 0.45,
            "risk_level": "MEDIUM",
            "confidence": 0.78,
            "timestamp": datetime.now().isoformat(),
            "vegetation_health": 0.6,
            "soil_moisture": 0.3
        }

async def predict_cyclone(location_data: Dict) -> Dict:
    """Predict cyclone risk"""
    try:
        # Prepare data for cyclone model
        weather_data = location_data.get("weather_data", pd.DataFrame())
        
        # Make prediction using simple model
        cyclone_model = models["cyclone"]
        prediction = cyclone_model.predict(weather_data)
        
        return prediction
    except Exception as e:
        logger.error(f"Cyclone prediction error: {e}")
        # Return fallback prediction
        return {
            "probability": 0.65,
            "risk_level": "HIGH",
            "confidence": 0.82,
            "timestamp": datetime.now().isoformat(),
            "intensity": "CATEGORY_2",
            "wind_speed": 85.0
        }

def generate_recommendations(disaster_type: str, risk_level: str, probability: float) -> List[str]:
    """Generate recommendations based on prediction"""
    recommendations = []
    
    # Check if risk is very low or safe
    low_risk_levels = ["LOW", "SAFE", "MINIMAL"]
    if risk_level in low_risk_levels or probability < 0.2:
        recommendations.append("✅ You are safe! No immediate action required.")
        recommendations.append("🌤️ Continue monitoring weather conditions")
        recommendations.append("📱 Stay informed through local weather updates")
        recommendations.append("🏠 Maintain normal daily activities")
        return recommendations
    
    if disaster_type == "flood":
        if risk_level in ["HIGH", "CRITICAL", "VERY_HIGH"]:
            recommendations.extend([
                "🚨 Evacuate to higher ground immediately",
                "📦 Move valuable items to upper floors",
                "🚗 Avoid driving through flooded areas",
                "📻 Stay tuned to emergency broadcasts",
                "📞 Keep emergency contacts handy"
            ])
        elif risk_level == "MEDIUM":
            recommendations.extend([
                "📋 Prepare emergency kit with essentials",
                "🌊 Monitor water levels in nearby rivers",
                "🗺️ Have evacuation plan ready",
                "🔒 Secure outdoor items and furniture",
                "📱 Sign up for flood alerts"
            ])
        else:  # LOW risk
            recommendations.extend([
                "✅ You are safe from flooding",
                "🌤️ Continue monitoring weather conditions",
                "📱 Stay informed through local weather updates",
                "🏠 Maintain normal daily activities"
            ])
    
    elif disaster_type == "drought":
        if risk_level in ["SEVERE_DROUGHT", "EXTREME_DROUGHT"]:
            recommendations.extend([
                "💧 Implement strict water conservation measures",
                "🚰 Prepare for water restrictions",
                "🌱 Monitor crop health closely",
                "🌾 Consider drought-resistant crops",
                "📊 Track water usage patterns"
            ])
        elif risk_level == "MODERATE_DROUGHT":
            recommendations.extend([
                "💧 Reduce water usage by 20-30%",
                "🌱 Monitor soil moisture levels",
                "🚿 Prepare irrigation systems",
                "💧 Store water supplies",
                "🌿 Use drought-resistant landscaping"
            ])
        else:  # LOW risk
            recommendations.extend([
                "✅ You are safe from drought conditions",
                "🌧️ Normal rainfall patterns expected",
                "🌱 Continue regular agricultural activities",
                "💧 Maintain normal water usage"
            ])
    
    elif disaster_type == "cyclone":
        if risk_level in ["VERY_HIGH", "EXTREME", "CRITICAL"]:
            recommendations.extend([
                "🚨 Evacuate immediately if ordered by authorities",
                "🔒 Secure all outdoor objects and furniture",
                "🪟 Board up windows and doors",
                "📦 Prepare emergency supplies kit",
                "📱 Charge all electronic devices"
            ])
        elif risk_level == "HIGH":
            recommendations.extend([
                "🗺️ Prepare evacuation plan",
                "🔒 Secure loose objects outdoors",
                "📻 Monitor weather updates regularly",
                "📦 Prepare emergency kit",
                "🏠 Identify safe shelter locations"
            ])
        else:  # LOW risk
            recommendations.extend([
                "✅ You are safe from cyclone activity",
                "🌤️ Normal weather conditions expected",
                "📱 Continue monitoring weather updates",
                "🏠 Maintain normal daily activities"
            ])
    
    # If no specific recommendations were added, provide general safety message
    if not recommendations:
        recommendations.extend([
            "✅ You are safe! No immediate action required.",
            "🌤️ Continue monitoring weather conditions",
            "📱 Stay informed through local weather updates",
            "🏠 Maintain normal daily activities"
        ])
    
    return recommendations

@app.post("/api/v1/alerts/subscribe", response_model=AlertResponse)
async def subscribe_to_alerts(request: AlertRequest):
    """Subscribe to disaster alerts for a location"""
    try:
        alert_id = await alert_system.subscribe_user(
            request.user_id,
            request.location,
            request.alert_types,
            request.disaster_types
        )
        
        return AlertResponse(
            alert_id=alert_id,
            status="subscribed",
            message="Successfully subscribed to alerts",
            timestamp=datetime.now().isoformat()
        )
    except Exception as e:
        logger.error(f"Alert subscription failed: {e}")
        raise HTTPException(status_code=500, detail="Alert subscription failed")

@app.delete("/api/v1/alerts/{alert_id}")
async def unsubscribe_from_alerts(alert_id: str):
    """Unsubscribe from alerts"""
    try:
        await alert_system.unsubscribe_user(alert_id)
        return {"message": "Successfully unsubscribed from alerts"}
    except Exception as e:
        logger.error(f"Alert unsubscription failed: {e}")
        raise HTTPException(status_code=500, detail="Alert unsubscription failed")

@app.get("/api/v1/alerts/history/{user_id}")
async def get_alert_history(user_id: str, limit: int = 50):
    """Get alert history for a user"""
    try:
        alerts = await alert_system.get_user_alerts(user_id, limit)
        return {"alerts": alerts}
    except Exception as e:
        logger.error(f"Failed to get alert history: {e}")
        raise HTTPException(status_code=500, detail="Failed to get alert history")

@app.get("/api/v1/data/weather/{latitude}/{longitude}")
async def get_weather_data(latitude: float, longitude: float):
    """Get current weather data for a location"""
    try:
        weather_data = await weather_service.get_current_weather(latitude, longitude)
        return weather_data
    except Exception as e:
        logger.error(f"Failed to get weather data: {e}")
        raise HTTPException(status_code=500, detail="Failed to get weather data")

@app.get("/api/v1/data/satellite/{latitude}/{longitude}")
async def get_satellite_data(latitude: float, longitude: float):
    """Get satellite imagery data for a location"""
    try:
        satellite_data = await satellite_service.get_satellite_data(latitude, longitude)
        return satellite_data
    except Exception as e:
        logger.error(f"Failed to get satellite data: {e}")
        raise HTTPException(status_code=500, detail="Failed to get satellite data")

@app.get("/api/v1/geocode/search")
async def search_cities(query: str, limit: int = 5):
    """Search for cities by name"""
    try:
        cities = await geocoding_service.search_cities(query, limit)
        return {"cities": cities}
    except Exception as e:
        logger.error(f"City search failed: {e}")
        raise HTTPException(status_code=500, detail="City search failed")

@app.get("/api/v1/geocode/city/{city_name}")
async def geocode_city(city_name: str, country_code: Optional[str] = None):
    """Get coordinates for a city name"""
    try:
        location_info = await geocoding_service.geocode_city(city_name, country_code)
        if not location_info:
            raise HTTPException(status_code=404, detail=f"City '{city_name}' not found")
        return location_info
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Geocoding failed: {e}")
        raise HTTPException(status_code=500, detail="Geocoding failed")

@app.get("/api/v1/analytics/trends/{disaster_type}")
async def get_disaster_trends(disaster_type: str, days: int = 30, city: str = None):
    """Get disaster prediction trends over time for a city (mock data)"""
    try:
        # For demo, generate mock trend data
        from datetime import datetime, timedelta
        import random
        now = datetime.now()
        trends = []
        for i in range(days):
            dt = now - timedelta(days=days - i)
            probability = max(0, min(1, random.gauss(0.3 + 0.2 * (disaster_type == 'flood'), 0.15)))
            if probability > 0.7:
                risk_level = 'HIGH'
            elif probability > 0.4:
                risk_level = 'MEDIUM'
            else:
                risk_level = 'LOW'
            trends.append({
                'timestamp': dt.isoformat(),
                'probability': probability,
                'risk_level': risk_level
            })
        return {"trends": trends}
    except Exception as e:
        logger.error(f"Failed to get trends: {e}")
        raise HTTPException(status_code=500, detail="Failed to get trends")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000) 