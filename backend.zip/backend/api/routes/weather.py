"""
Weather API Routes for Globe Visualization
Provides live weather data including cyclones, drought areas, and rainfall
"""

from fastapi import APIRouter, HTTPException
from typing import List, Dict, Any
import asyncio
from datetime import datetime, timedelta
import random
import math

router = APIRouter(prefix="/weather", tags=["weather"])

# Simulated weather data for demo
SIMULATED_CYCLONES = [
    {
        "id": "AL012023",
        "name": "Hurricane Ian",
        "lat": 25.0,
        "lon": -80.0,
        "intensity": 4,
        "category": "Category 4",
        "wind_speed": 130,
        "pressure": 950,
        "movement": "NW",
        "speed": 12,
        "timestamp": datetime.now().isoformat()
    },
    {
        "id": "WP012023",
        "name": "Typhoon Noru",
        "lat": 15.0,
        "lon": 120.0,
        "intensity": 3,
        "category": "Category 3",
        "wind_speed": 115,
        "pressure": 965,
        "movement": "W",
        "speed": 15,
        "timestamp": datetime.now().isoformat()
    },
    {
        "id": "SH012023",
        "name": "Cyclone Yasi",
        "lat": -20.0,
        "lon": 150.0,
        "intensity": 2,
        "category": "Category 2",
        "wind_speed": 95,
        "pressure": 980,
        "movement": "SE",
        "speed": 8,
        "timestamp": datetime.now().isoformat()
    }
]

SIMULATED_DROUGHT_AREAS = [
    {
        "id": "drought_001",
        "region": "Texas, USA",
        "lat": 35.0,
        "lon": -100.0,
        "severity": 0.8,
        "level": "Extreme",
        "affected_area_km2": 250000,
        "population_affected": 15000000,
        "duration_days": 180,
        "timestamp": datetime.now().isoformat()
    },
    {
        "id": "drought_002",
        "region": "North Africa",
        "lat": 30.0,
        "lon": 20.0,
        "severity": 0.7,
        "level": "Severe",
        "affected_area_km2": 500000,
        "population_affected": 25000000,
        "duration_days": 365,
        "timestamp": datetime.now().isoformat()
    },
    {
        "id": "drought_003",
        "region": "South Africa",
        "lat": -30.0,
        "lon": 25.0,
        "severity": 0.6,
        "level": "Moderate",
        "affected_area_km2": 300000,
        "population_affected": 12000000,
        "duration_days": 120,
        "timestamp": datetime.now().isoformat()
    },
    {
        "id": "drought_004",
        "region": "Central Asia",
        "lat": 40.0,
        "lon": 100.0,
        "severity": 0.5,
        "level": "Mild",
        "affected_area_km2": 150000,
        "population_affected": 8000000,
        "duration_days": 90,
        "timestamp": datetime.now().isoformat()
    }
]

SIMULATED_RAINFALL_DATA = [
    {
        "region": "Southeast Asia",
        "lat_range": (5, 25),
        "lon_range": (90, 130),
        "intensity": "Heavy",
        "amount_mm": 150,
        "duration_hours": 24,
        "flood_risk": "High"
    },
    {
        "region": "Eastern USA",
        "lat_range": (25, 45),
        "lon_range": (-85, -65),
        "intensity": "Medium",
        "amount_mm": 75,
        "duration_hours": 12,
        "flood_risk": "Medium"
    },
    {
        "region": "Western Europe",
        "lat_range": (40, 60),
        "lon_range": (-10, 20),
        "intensity": "Light",
        "amount_mm": 25,
        "duration_hours": 6,
        "flood_risk": "Low"
    }
]

@router.get("/current")
async def get_current_weather() -> Dict[str, Any]:
    """
    Get current weather data for globe visualization
    Returns cyclones, drought areas, and rainfall data
    """
    try:
        # Simulate some data variation
        current_time = datetime.now()
        
        # Update cyclone positions slightly
        updated_cyclones = []
        for cyclone in SIMULATED_CYCLONES:
            # Add small random movement
            lat_offset = random.uniform(-0.5, 0.5)
            lon_offset = random.uniform(-0.5, 0.5)
            
            updated_cyclone = cyclone.copy()
            updated_cyclone["lat"] += lat_offset
            updated_cyclone["lon"] += lon_offset
            updated_cyclone["timestamp"] = current_time.isoformat()
            updated_cyclones.append(updated_cyclone)
        
        # Update drought severity slightly
        updated_droughts = []
        for drought in SIMULATED_DROUGHT_AREAS:
            severity_change = random.uniform(-0.05, 0.05)
            updated_drought = drought.copy()
            updated_drought["severity"] = max(0.1, min(1.0, drought["severity"] + severity_change))
            updated_drought["timestamp"] = current_time.isoformat()
            updated_droughts.append(updated_drought)
        
        return {
            "timestamp": current_time.isoformat(),
            "cyclones": updated_cyclones,
            "drought_areas": updated_droughts,
            "rainfall": SIMULATED_RAINFALL_DATA,
            "summary": {
                "total_cyclones": len(updated_cyclones),
                "total_drought_areas": len(updated_droughts),
                "active_rainfall_regions": len(SIMULATED_RAINFALL_DATA),
                "data_source": "simulated"
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get weather data: {str(e)}")

@router.get("/cyclones")
async def get_cyclones() -> List[Dict[str, Any]]:
    """
    Get current cyclone data
    """
    try:
        current_time = datetime.now()
        updated_cyclones = []
        
        for cyclone in SIMULATED_CYCLONES:
            # Add small random movement
            lat_offset = random.uniform(-0.5, 0.5)
            lon_offset = random.uniform(-0.5, 0.5)
            
            updated_cyclone = cyclone.copy()
            updated_cyclone["lat"] += lat_offset
            updated_cyclone["lon"] += lon_offset
            updated_cyclone["timestamp"] = current_time.isoformat()
            updated_cyclones.append(updated_cyclone)
        
        return updated_cyclones
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get cyclone data: {str(e)}")

@router.get("/drought")
async def get_drought_areas() -> List[Dict[str, Any]]:
    """
    Get current drought area data
    """
    try:
        current_time = datetime.now()
        updated_droughts = []
        
        for drought in SIMULATED_DROUGHT_AREAS:
            severity_change = random.uniform(-0.05, 0.05)
            updated_drought = drought.copy()
            updated_drought["severity"] = max(0.1, min(1.0, drought["severity"] + severity_change))
            updated_drought["timestamp"] = current_time.isoformat()
            updated_droughts.append(updated_drought)
        
        return updated_droughts
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get drought data: {str(e)}")

@router.get("/rainfall")
async def get_rainfall_data() -> List[Dict[str, Any]]:
    """
    Get current rainfall data
    """
    try:
        return SIMULATED_RAINFALL_DATA
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get rainfall data: {str(e)}")

@router.get("/forecast/{hours}")
async def get_weather_forecast(hours: int = 24) -> Dict[str, Any]:
    """
    Get weather forecast for specified hours
    """
    try:
        if hours > 168:  # Max 7 days
            hours = 168
        
        current_time = datetime.now()
        forecast_data = []
        
        for hour in range(0, hours + 1, 6):  # Every 6 hours
            forecast_time = current_time + timedelta(hours=hour)
            
            # Simulate forecast data
            forecast_entry = {
                "timestamp": forecast_time.isoformat(),
                "cyclones": len(SIMULATED_CYCLONES),
                "drought_areas": len(SIMULATED_DROUGHT_AREAS),
                "rainfall_intensity": random.choice(["Light", "Medium", "Heavy"]),
                "global_risk_level": random.choice(["Low", "Medium", "High"])
            }
            forecast_data.append(forecast_entry)
        
        return {
            "forecast_hours": hours,
            "data": forecast_data,
            "generated_at": current_time.isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get forecast: {str(e)}")

@router.get("/stats")
async def get_weather_stats() -> Dict[str, Any]:
    """
    Get weather statistics
    """
    try:
        current_time = datetime.now()
        
        return {
            "total_cyclones": len(SIMULATED_CYCLONES),
            "total_drought_areas": len(SIMULATED_DROUGHT_AREAS),
            "active_rainfall_regions": len(SIMULATED_RAINFALL_DATA),
            "highest_cyclone_intensity": max(cyclone["intensity"] for cyclone in SIMULATED_CYCLONES),
            "most_severe_drought": max(drought["severity"] for drought in SIMULATED_DROUGHT_AREAS),
            "data_last_updated": current_time.isoformat(),
            "data_source": "simulated"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get weather stats: {str(e)}") 